# Topology T1：恢复修复与独立双卡提交

2026-10-16。用途：修复失败的四卡入口，把 A/B 拆成两个可独立排队的双卡任务。用户在 AIStation 手动提交；本次修复未启动 GPU 训练。

## 提交命令

分别创建两个任务，每个任务 Worker=1、2张 A100 80GB。两张卡必须位于同一个 Worker。使用之前已测试的镜像，将持久目录挂载为 `/guohaoran`，保留容器内绝对路径。入口保持前台，不加 `&` 或 `nohup`。

A：

```bash
bash /guohaoran/nexus_topology_flow_overfit50_20261015/preflight_20261015/tools/launch_aistation.sh --run A_fresh
```

B：

```bash
bash /guohaoran/nexus_topology_flow_overfit50_20261015/preflight_20261015/tools/launch_aistation.sh --run B_s0warm
```

| 项目 | A | B |
|---|---|---|
| 平台日志路径字段 | `/guohaoran/nexus_topology_flow_overfit50_20261015/pair_resume_20261016/platform_logs/A_fresh` | `/guohaoran/nexus_topology_flow_overfit50_20261015/pair_resume_20261016/platform_logs/B_s0warm` |
| 启动日志 | 上述目录内 `launcher.log` | 上述目录内 `launcher.log` |
| 训练日志 | `/guohaoran/nexus_topology_flow_overfit50_20261015/pair_resume_20261016/A_fresh.log` | `/guohaoran/nexus_topology_flow_overfit50_20261015/pair_resume_20261016/B_s0warm.log` |
| 新恢复点目录 | `/guohaoran/nexus_topology_flow_overfit50_20261015/pair_resume_20261016/A_fresh` | `/guohaoran/nexus_topology_flow_overfit50_20261015/pair_resume_20261016/B_s0warm` |

单独检查时，在对应命令末尾加 `--dry-run`。漏写 `--run` 会提前拒绝，避免误用旧四卡命令。两组可错峰启动，也可同时运行；各自使用所在容器分配的 GPU 0/1，账本与锁相互独立。

## 失败原因与修复

失败任务容器为 `pytorch-84289dd2-lhlfv`。2026-10-16 09:20:29（新加坡时间）启动 A/B，约8秒后都因 `FileExistsError: output is nonempty without a verified latest.json` 退出。旧单卡训练保存的是 `latest.pt`，新分布式入口只认 `latest.json` 提交指针；原启动器没有提前拒绝这一格式不兼容。失败的四卡尝试没有产生新的有效更新。

新增显式迁移清单，绑定父检查点、原配置、源码、50 UID顺序和下一步游标；逐项验证 Adam、EMA、模型和训练参数。旧目录不作为新输出目录。首次运行先原子提交1386步的原生分布式恢复点、校验 SHA，再执行1387步。后续沿用同一命令恢复。

## 保留的实验身份

- 研究源码 commit：`72c993772a91482a3660faa7c83993bfd566cbfe`。研究目录源码和冻结 AE/VAE 未修改。
- 同一固定50条，52,820个顶点；`001825`仍为已批准的1277点版本。
- A 为原 fresh 组的续训；B 为原 S0 初始化组的续训，不会重新加载 S0 覆盖1386步权重。
- 两组均从1386继续，下一次有效更新为1387，累计上限仍为10000。每次有效更新仍覆盖全50条，warmup与学习率进度保留。
- 模型2,333,965,312参数；原 BF16、FlashAttention、前30个 Flow block 重计算设置保留。
- 冻结 VAE SHA：`e89b8078b7abb0ca7b0c2c44f9f20382ec5b742f2aee948f209d642852714d15`。

| 父检查点 | 字节数 | SHA256 |
|---|---:|---|
| `/guohaoran/nexus_topology_flow_overfit50_20261015/A_fresh/latest.pt` | 37344847980 | `e25eba577961f9cf3f41fac31cf8911970b3d6ef86e0c4ed2ae8ab27db6a5897` |
| `/guohaoran/nexus_topology_flow_overfit50_20261015/B_s0warm/latest.pt` | 37344848044 | `57070c38e9a99366374cc910ffd0cb48797bf7bc10d0f170b442aa77df598c25` |

旧检查点没有历史全局 RNG 快照，不能声称恢复了该快照。原 T1 的批次由 seed/update 专用生成器决定；时间、后验噪声和 Flow 噪声依次使用这一生成器。迁移保持原输入流；当前训练没有随机 dropout 或其他全局 RNG 消费。新分布式恢复点开始保存各 rank 的真实 RNG。跨并行度允许浮点归约差异，不承诺与单卡逐位相同。

## 验证、预算与空间

CPU 已通过：18项启动器测试、8类迁移校验测试、原有双 rank 恢复门，以及新增的单卡旧格式→双 rank→保存恢复门。新增测试实际执行两步 TINY 训练后迁移；迁移下一步与单卡参考在容差内，双 rank 中断恢复与连续训练的模型/Adam/EMA/RNG/游标严格相同。1386→1387另行验证输入和 LR 边界，没有伪造1386步合成训练。

两份真实父检查点均通过完整SHA及严格模型加载核验；两条提交命令的dry-run均以0退出，确认各自只有一条双rank训练队列、45 GPU小时预算，且没有启动GPU工作。漏写 `--run` 的旧命令以2退出。证据见同目录 `parent_validation.json`、`dry-run-A.log`、`dry-run-B.log`、`missing-run.log`。当前维护实例只有一张GPU，本次修复使用CPU验证；修复后的真实双卡训练尚未启动。

每组45 GPU小时，合计不增加原90 GPU小时上限。每组先扣旧单卡运行12453.028秒，以及失败四卡任务总计174.277 GPU秒的一半，即已计入约3.48338 GPU小时；每组剩余约41.51662 GPU小时。按每个任务实际分配2张卡的墙钟时间计费，包含启动、训练、评价和保存。累计10000步、达标早停、30秒单步上限和预算停止仍有效。

原两份父检查点保留。单份完整恢复点约37.345 GB；两份父检查点加两份当前恢复点约149.379 GB，同时保存两份临时副本时峰值约224.069 GB，另加 VAE 和日志。已确认 `/guohaoran` 为 GPFS 持久挂载；个人配额未知，不创建占位文件、不清理其他实验。新恢复点的真实落盘在用户启动任务后、首个新更新之前完成。

启动环境仍要求 Python 3.10.15、PyTorch `2.3.0a0+6ddf5cf85e.nv24.04`、CUDA 12.4、FlashAttention 2.4.2；`/guohaoran/envs/nexus-algo/bin/python` 依赖镜像内已有库。入口核验版本，不自动安装或更换环境。

修复前执行文件及配置备份在服务器 `repair_20261016/before/`。CPU测试日志在服务器 `repair_20261016/tests/`。本次交付是恢复修复与启动准备，未产生新的 Flow 生成成绩。
