# Topology T1：独立四卡A与四卡B

2026-10-16。两个新增任务分别使用4张GPU，从原A/B的1386步检查点继续。原双卡A/B保留。本次负责部署和启动前验证，正式训练由用户在AIStation手动提交。

## AIStation提交

创建两个任务，每个任务 **Worker=1、同一Worker内4张A100 80GB**。两组同时运行需要8张卡；加上原两组双卡全部并行共12张。持久目录挂载为 `/guohaoran`，使用之前已测试的相同镜像。参考资源：每任务256GB内存、32核CPU、32GB共享内存。命令保持前台，不加 `&` 或 `nohup`。

四卡A命令：

```bash
bash /guohaoran/nexus_topology_flow_overfit50_20261015/quad_resume_20261016/tools/launch_aistation.sh --run A_fresh
```

四卡A日志路径字段：

```text
/guohaoran/nexus_topology_flow_overfit50_20261015/quad_resume_20261016/platform_logs/A_fresh
```

四卡B命令：

```bash
bash /guohaoran/nexus_topology_flow_overfit50_20261015/quad_resume_20261016/tools/launch_aistation.sh --run B_s0warm
```

四卡B日志路径字段：

```text
/guohaoran/nexus_topology_flow_overfit50_20261015/quad_resume_20261016/platform_logs/B_s0warm
```

启动日志为上述各目录的 `launcher.log`。训练日志分别为新根目录下的 `A_fresh.log`、`B_s0warm.log`；恢复点和逐步指标在新根目录下各自的 `A_fresh/`、`B_s0warm/`。同一命令再次提交恢复对应新任务，账本不会清零。只检查时加 `--dry-run`。

## 隔离和恢复

新根目录为 `/guohaoran/nexus_topology_flow_overfit50_20261015/quad_resume_20261016`。执行代码、研究源码副本、配置、manifest、锁、STOP文件、日志、评价、采样扫描和恢复点均位于该目录内。A/B端口分别29661/29662，避开旧双卡29651/29652。已完成VAE基线的结果文件按原SHA复制到新目录，只读复用。

共享只读输入为固定50条cache、冻结VAE、S0和旧1386步父检查点；不复制大权重以制造额外占用。每次启动校验来源SHA。研究源码内容仍对应commit `72c993772a91482a3660faa7c83993bfd566cbfe`，冻结AE/VAE未变。

| 项目 | 四卡A | 四卡B |
|---|---|---|
| 父检查点 | 原 `A_fresh/latest.pt` | 原 `B_s0warm/latest.pt` |
| 原初始化组别 | fresh组 | S0初始化组 |
| 恢复更新 | 1386 | 1386 |
| 下一次有效更新 | 1387 | 1387 |
| 累计更新上限 | 10000 | 10000 |
| 每次更新 | 四rank合计固定50条、52820顶点 | 同左 |
| 本次新增预算 | 45 GPU小时 | 45 GPU小时 |

A父SHA：`e25eba577961f9cf3f41fac31cf8911970b3d6ef86e0c4ed2ae8ab27db6a5897`；B父SHA：`57070c38e9a99366374cc910ffd0cb48797bf7bc10d0f170b442aa77df598c25`。各约37.345GB。

恢复model、EMA、Adam及seed/update数据游标，保留warmup和LR进度。B不会重新加载S0覆盖已训练权重。首次启动先提交带4份rank RNG的原生1386步恢复点，再执行1387步。旧程序没有保存历史全局RNG；原输入由seed/update专用生成器确定，迁移保持该输入流。旧历史快照不可恢复，不作此声明。分布式浮点归约允许数值差异，不保证与单卡或双卡逐位相同。

## 验证和性能边界

- 四rank CPU迁移门：实际执行旧格式TINY两步，再迁移至四rank第3步；与单卡参考在容差内。四rank中断恢复第4步与连续训练的model/Adam/EMA/RNG/游标严格一致。
- 分片检查：50条及全部token恰好覆盖一次；rank RNG共有4份。
- 原恢复门在world=4通过，含科学配方拒绝、SHA拒绝、STOP、完成保护、早停恢复和超时保存。
- 9项迁移校验、18项启动器测试通过；shell环境和解析检查通过。
- 两份真实父检查点均通过完整SHA、906份Adam状态和严格模型加载核验；A/B最终dry-run均以0退出，确认各只有一条四rank训练队列、45 GPU小时独立新增预算、全部输出位于新目录，且没有启动GPU工作。记录为 `parent_validation.json`、`dry-run-A.log`、`dry-run-B.log`、`dry_run_result.json`。
- 原双卡执行代码、配置、manifest和迁移清单共21个文件的前后SHA完全一致，见 `isolation_result.json`。

保持2,333,965,312参数、BF16、FlashAttention和前30个Flow block重计算。历史 `four_gpu_ckpt` 使用全层重计算，12次完整更新、丢弃前3次，实测中位2.5049秒/更新，峰值allocated49.066GiB/卡；这是历史短测，不是本次partial30四卡速度或生产结果。本次精确四卡配置尚未实测，恢复后的有效更新会记录时间及显存，超过30秒会保存并停止，不清零重跑。当前维护实例仅一张GPU，本次准备没有GPU训练。

## 预算与存储

用户明确批准四卡A/B **新增合计90 GPU小时**，每组45；原双卡预算照旧。新账本初始新增消耗为0，父阶段用量单独记来源，不将原90小时重复当作新增授权。分配的4张卡按启动器墙钟时间计费，包含启动、评价、保存及退出预留；每组最多11.25小时四卡占用。即使评价只用1张卡，仍按分配4张卡计时。

新增四卡目录两份最新完整恢复点约74.690GB，同时原子保存时约149.379GB。若父检查点、原双卡和新增四卡都保留，稳态共6份约224.069GB；四个任务同时保存的总峰值约10份373.448GB，另加VAE、代码与日志。`/guohaoran`为GPFS持久挂载；个人配额未知，不预留占位空间、不删除其他实验。真实新检查点会在用户提交后的首个新更新之前写入、刷盘、SHA校验并提交指针。

环境要求沿用已测试镜像：Python3.10.15，PyTorch `2.3.0a0+6ddf5cf85e.nv24.04`，CUDA12.4，FlashAttention2.4.2。入口设置 `PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION=python`、`OMP_NUM_THREADS=8` 并核验版本，不自动修改环境。
