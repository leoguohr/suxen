#!/usr/bin/env bash
set -euo pipefail
export PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION=python OMP_NUM_THREADS=8

ROOT=/guohaoran/nexus_topology_flow_overfit50_20261015/quad_resume_20261016
PY=/guohaoran/envs/nexus-algo/bin/python
RUN=
ARGS=("$@")
for ((i=0; i<${#ARGS[@]}; i++)); do
    case "${ARGS[i]}" in
        --run)
            [[ -z "$RUN" && $((i+1)) -lt ${#ARGS[@]} ]] || { echo 'Specify --run exactly once.' >&2; exit 2; }
            RUN="${ARGS[i+1]}"
            i=$((i+1))
            ;;
        --run=*)
            [[ -z "$RUN" ]] || { echo 'Specify --run exactly once.' >&2; exit 2; }
            RUN="${ARGS[i]#--run=}"
            ;;
    esac
done
case "$RUN" in
    A_fresh|B_s0warm) ;;
    *) echo 'Required: --run A_fresh or --run B_s0warm.' >&2; exit 2 ;;
esac
LOG_DIR="$ROOT/platform_logs/$RUN"
mkdir -p "$LOG_DIR"
exec "$PY" -u "$ROOT/tools/launch_aistation.py" "$@" > >(tee -a "$LOG_DIR/launcher.log") 2>&1
