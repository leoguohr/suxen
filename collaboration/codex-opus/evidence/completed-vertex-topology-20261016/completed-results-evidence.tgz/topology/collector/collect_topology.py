from pathlib import Path
import os, json, hashlib, datetime, tarfile
ROOT=Path("/guohaoran/nexus_topology_flow_overfit50_20261015")
OUT=Path("/guohaoran/tmp/nexus_completion_handoff_20261016/topology")
EVID=OUT/"evidence"
EVID.mkdir(parents=True, exist_ok=True)
if (EVID/"REPORT.md").exists(): raise RuntimeError("Evidence already exists; refusing overwrite")
captured=datetime.datetime.now(datetime.timezone.utc).isoformat()
manifest=[]
def sha(b): return hashlib.sha256(b).hexdigest()
def save(src, relative=None, tail=None):
    src=Path(src)
    if not src.is_file():return None
    if src.suffix in [".pt",".npz",".pyc"] or any(x in src.parts for x in ["predictions","__pycache__"]):raise ValueError(str(src))
    with src.open("rb") as f:
        st=os.fstat(f.fileno())
        data=f.read(st.st_size)
    original=data
    if src.suffix in [".jsonl",".log"] and data and not data.endswith(b"\n"):
        data=data[:data.rfind(b"\n")+1]
    complete_bytes=len(data)
    if tail is not None:data=b"".join(data.splitlines(keepends=True)[-tail:])
    rel=relative or str(src.relative_to(ROOT))
    dst=EVID/rel
    dst.parent.mkdir(parents=True,exist_ok=True)
    dst.write_bytes(data)
    manifest.append({"path":rel,"source":str(src),"bytes":len(data),"sha256":sha(data),
          "source_snapshot_bytes":st.st_size,"source_snapshot_sha256":sha(original),
          "complete_line_boundary_bytes":complete_bytes,"source_mtime_ns":st.st_mtime_ns,
          "capture_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"tail_lines":tail})
    return dst
def generated(name,obj):
    data=(json.dumps(obj,indent=2,ensure_ascii=False)+"\n").encode() if not isinstance(obj,str) else obj.encode()
    (EVID/name).write_bytes(data)
    manifest.append({"path":name,"source":"generated from collected evidence","bytes":len(data),"sha256":sha(data)})
pair={}
for name in ["A_fresh","B_s0warm"]:
    run=ROOT/"pair_resume_20261016"/name
    for p in sorted(run.rglob("*")):
        if p.is_file() and p.suffix in [".json",".jsonl",".log",".md"] and not any(t in p.parts for t in ["predictions","__pycache__"]):save(p)
    for p in sorted((ROOT/"pair_resume_20261016/platform_logs"/name).rglob("*")):
        if p.is_file() and p.suffix in [".json",".jsonl",".log",".md"]:save(p)
    for p in sorted((ROOT/"pair_resume_20261016").glob(name+"*.log")):save(p)
    ev=EVID/"pair_resume_20261016"/name
    status=json.loads((ev/"status.json").read_text())
    final=json.loads((ev/"final.json").read_text())
    f=run/final["file"]
    evals=[json.loads(x) for x in (ev/"evals.jsonl").read_text().splitlines() if x]
    sweeps={}
    for sweep in ["sweep_ema","sweep_raw","sweep_ema_fp32"]:
        d=json.loads((ev/sweep/"results.json").read_text())["results"]
        sweeps[sweep]={"cases":len(d),"objects_per_case":sorted({x["objects"] for x in d.values()}),
            "overflow_count":sum(len(x["overflow_objects"]) for x in d.values()),
            "lower_bound_cases":sum(bool(x["lower_bound"]) for x in d.values())}
    ledger=json.loads((ev.parent/"platform_logs"/name/"budget_ledger.json").read_text())
    pair[name]={"state":status,"final_checkpoint_record":final,
        "checkpoint_exists":f.exists(),"checkpoint_bytes_match_manifest":f.exists() and f.stat().st_size==final["bytes"],
        "checkpoint_sha256_note":"Recorded committed SHA only; not rehashed or loaded in this CPU handoff.",
        "milestone_rows":evals,"sweeps":sweeps,
        "segments":[{k:v.get(k) for k in ["name","status","returncode","started_at","ended_at"]} for v in ledger.get("segments",[])]}
quad={}
for name in ["A_fresh","B_s0warm"]:
    run=ROOT/"quad_resume_20261016"/name
    q={"directory_exists":run.exists(),"state":"not_final_snapshot"}
    if run.exists():
        q["directory_entries"]=[p.name for p in sorted(run.iterdir())]
        for p in sorted(run.glob("*.json")):save(p)
        for p in sorted(run.glob("*.jsonl")):save(p,tail=50 if p.name=="train.jsonl" else None)
        ev=run/"evals"
        if ev.exists():
            for p in sorted(ev.rglob("*")):
                if p.is_file() and p.suffix in [".json",".jsonl"] and "predictions" not in p.parts:save(p)
        train=EVID/"quad_resume_20261016"/name/"train.jsonl"
        q["last_train_row"]=json.loads(train.read_text().splitlines()[-1]) if train.exists() else None
        q["final_pointer_present"]=(run/"final.json").exists()
    save(ROOT/"quad_resume_20261016"/(name+".log"),tail=100)
    for fn in ["launcher.log","budget_ledger.json"]:
        save(ROOT/"quad_resume_20261016/platform_logs"/name/fn,tail=80 if fn.endswith(".log") else None)
    q["interpretation"]="Training log progressed during current read-only checks; this is not a final result." if q.get("last_train_row") else "Prepared migration/dry-run exists; no training log or START was observed at capture. Submission/queue status is not inferred."
    quad[name]=q
for relative in [
 "repair_20261016/README.md","repair_20261016/launch_config.json","repair_20261016/launch_manifest.json",
 "repair_20261016/SHA256SUMS.json","repair_20261016/train_distributed.diff","repair_20261016/launch_aistation.diff",
 "repair_20261016/parent_validation.json",
 "quad_resume_20261016/README.md","quad_resume_20261016/launch_config.json","quad_resume_20261016/launch_manifest.json",
 "preflight_20261015/tools/SOURCE_FILES.json","preflight_20261015/tools/train_distributed.py",
 "preflight_20261015/tools/launch_aistation.py","preflight_20261015/tools/launch_aistation.sh",
 "preflight_20261015/tools/single_gpu_migration.py","preflight_20261015/tools/checkpoint_policy.py",
 "quad_resume_20261016/tools/train_distributed.py","quad_resume_20261016/tools/launch_aistation.py",
 "quad_resume_20261016/tools/launch_aistation.sh"]:save(ROOT/relative)
source=ROOT/"preflight_20261015/source/topology/flow_overfit50_20261015"
for p in sorted(source.iterdir()):
    if p.is_file() and p.suffix in [".py",".md"]:save(p)
for base in ["eval_mu","tolerance"]:save(ROOT/"preflight_20261015"/base/"results.json")
status={"captured_utc":captured,"captured_singapore":datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),
 "research_source_commit":"72c993772a91482a3660faa7c83993bfd566cbfe",
 "execution_code":"Separate distributed/migration wrappers are included and hashed; these wrappers differ from original single-GPU repository code.",
 "scope":"CPU/file-only evidence collection; no GPU, training, restart, checkpoint read/hash or original-folder edits.",
 "pair_completed":pair,"quad_snapshot_only":quad,
 "exclusions":[".pt",".npz","predictions","raw training data","credentials"]}
generated("STATUS.json",status)
qstep=(quad["A_fresh"].get("last_train_row") or {}).get("update","not observed")
report=f"""# Topology T1: completed two-GPU A/B and separate four-GPU snapshot

Captured: {captured} (UTC). Source research commit: 72c993772a91482a3660faa7c83993bfd566cbfe.

## Completed experiments

pair_resume_20261016/A_fresh and B_s0warm each resumed from cumulative update 1386, performed 2614 additional updates, and completed at cumulative update **4000**. Each has JOB_COMPLETE, status=complete, a committed final checkpoint pointer, an existing checkpoint with matching recorded byte size, and a launcher that exited successfully after all post-training evaluation stages.

The configured upper limit was 10000. The existing stop_at_pass rule stopped both at 4000 because **raw weights** passed the predefined aggregate Face F1 >= 0.99 criterion for both seeds. This is not a 100/100 strict reconstruction claim, and EMA did not pass.

| Fixed 50 objects; Euler 20; seeds 0 / 1 | A fresh | B S0 warm |
|---|---:|---:|
| Raw Face micro F1 | 0.9942495103 / 0.9942024360 | 0.9950446658 / 0.9950491456 |
| Raw Edge micro F1 | 0.9989200411 / 0.9988943437 | 0.9993002370 / 0.9992679993 |
| Raw joint strict | 8/50 + 7/50 = 15/100 | 11/50 + 9/50 = 20/100 |
| EMA Face micro F1 | 0.9103483791 / 0.9114379942 | 0.9396169054 / 0.9381436110 |
| EMA joint strict | 0/100 | 0/100 |

A and B are separate initialization branches, not sequential training stages. The completed versions here each used two GPUs per update. Their original single-GPU update-1386 parent folders remain separate.

## Completed evaluation coverage

For **each** completed branch:
- Milestones u2000 and u4000: raw and EMA, both seeds, 50 objects per seed.
- Final EMA: Euler and DPM2M, each at 10/20/50 steps, both seeds = 12 cases.
- Final raw: Euler 20, both seeds = 2 cases.
- Final EMA FP32: Euler 20, both seeds = 2 cases.
- Every final case covers 50 objects. No candidate overflow and no lower-bound-only summaries.
- Full per-object objects.jsonl / seed*_objects.jsonl and all summaries are included; this evaluator does not use an evaluation.json filename.
- Training and all three post-training evaluator processes exited 0.

The complete train/probe logs, raw/EMA milestone summaries, exact launch commands, execution wrappers, recipe/config/source hashes, final pointer records and per-object evaluations are included. Full checkpoints and prediction arrays remain on the server.

## Separate four-GPU versions: snapshot, not completion

quad_resume_20261016 is an independently launched version from the old 1386 parents. Do not merge its updates with the completed two-GPU trajectories.
- A: last complete captured training row is update **{qstep}**; logs progressed during the read-only inspection. Its u2000 raw Face F1 is 0.9871294400 / 0.9861867779; joint strict 4/50 + 4/50. No final result is claimed.
- B: at capture, only migration and dry-run preparation evidence exists; no train log, final pointer or actual START is observed. We cannot infer the scheduler queue state.
- Quad logs are bounded snapshots. FILE_MANIFEST.json records source size, complete-line truncation boundary, capture time, source mtime, full bounded-source SHA, and copied-tail SHA. No claim of a live PID on this separate maintenance container is made.

## Provenance and limits

Evidence source root: /guohaoran/nexus_topology_flow_overfit50_20261015.
The scientific source snapshot corresponds to the commit above. Additional distributed execution and migration wrappers are archived separately; their hashes identify the effective execution code.

Recorded checkpoint SHAs are copied from the completed atomic-commit metadata. This handoff checks file existence and size only; it does not reload or rehash 37 GB checkpoint files.

The former root-level four-GPU attempt exited without new valid updates because legacy latest.pt lacked the required verified latest.json pointer. The repair and successful pair_resume_20261016 runs are distinct from that failed attempt.

No GPU work, new training, restarts, deletions, source edits, or result recomputation was performed to collect this handoff.
"""
generated("REPORT.md",report)
collector=OUT/"collect_topology.py"
if collector.exists():save(collector,"collector/collect_topology.py")
(EVID/"FILE_MANIFEST.json").write_text(json.dumps({"capture_utc":captured,"files":manifest},indent=2)+"\n")
archive=OUT/"topology_t1_completed_and_snapshot.tgz"
with tarfile.open(archive,"w:gz",compresslevel=6) as tf:
    for p in sorted(EVID.rglob("*")):
        if p.is_file():tf.add(p,arcname="topology/"+str(p.relative_to(EVID)))
print(json.dumps({"evidence":str(EVID),"archive":str(archive),"archive_bytes":archive.stat().st_size,
 "archive_sha256":sha(archive.read_bytes()),"files":len(manifest)+1,"quad_a_snapshot_update":qstep},indent=2))
