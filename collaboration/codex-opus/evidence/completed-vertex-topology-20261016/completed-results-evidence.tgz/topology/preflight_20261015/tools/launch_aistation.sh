#!/usr/bin/env bash
set -euo pipefail
ROOT=/guohaoran/nexus_topology_flow_overfit50_20261015
PY=/guohaoran/envs/nexus-algo/bin/python
export PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION=python OMP_NUM_THREADS=8
LOG_DIR="$ROOT/platform_logs"
ARGS=("$@")
for ((i=0; i<${#ARGS[@]}; i++)); do
  if [[ "${ARGS[i]}" == "--run" ]]; then
    case "${ARGS[i+1]:-}" in
      A_fresh|B_s0warm) LOG_DIR="$ROOT/pair_resume_20261016/platform_logs/${ARGS[i+1]}" ;;
      *) echo "--run must be A_fresh or B_s0warm" >&2; exit 2 ;;
    esac
  fi
done
mkdir -p "$LOG_DIR"
# Stay in the foreground: AIStation owns this process and its allocation lifetime.
exec "$PY" -u "$ROOT/preflight_20261015/tools/launch_aistation.py" "$@" \
  > >(tee -a "$LOG_DIR/launcher.log") 2>&1
