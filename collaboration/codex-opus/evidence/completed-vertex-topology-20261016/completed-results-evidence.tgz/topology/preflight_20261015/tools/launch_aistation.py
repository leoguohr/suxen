#!/usr/bin/env python3
"""AIStation foreground entry for T1. No training starts without explicit invocation.

Use --dry-run to hash inputs and check runtime imports without launching GPU work.
The original T1 science is selected by the pinned source. This wrapper owns only process lifetime,
logs, a cumulative GPU-time ledger and the original post-training evaluation commands.
"""
from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shlex
import signal
import socket
import subprocess
import sys
import time

ROOT = Path('/guohaoran/nexus_topology_flow_overfit50_20261015')
DEFAULTS = dict(
    source=str(ROOT / 'preflight_20261015/source/topology/flow_overfit50_20261015'),
    cache='/guohaoran/nexus_fast_track/diagnostics/topology_flow_user50_continue_20261006/cache',
    vae=str(ROOT / 'inputs/vae-1000.pt'),
    s0='/guohaoran/tmp/nexus_vertex_arch_sweep_recovery_20261007/runs/S0/checkpoint-034000.pt',
    python='/guohaoran/envs/nexus-algo/bin/python',
    manifest=str(ROOT / 'preflight_20261015/launch_manifest.json'),
    mode='two-pairs', gpus=['0', '1', '2', '3'], chunk_tokens=0, attention='auto',
    checkpoint_activations=1, max_updates=10000, budget_gpu_hours=90,
    initial_gpu_seconds=0, shutdown_grace_seconds=1200,
    outputs_root=None,
    eval_mu_output=str(ROOT / 'preflight_20261015/eval_mu'),
    tolerance_output=str(ROOT / 'preflight_20261015/tolerance'),
)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def write_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    with temp.open('w') as stream:
        json.dump(data, stream, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temp, path)
    fd = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def read_json(path):
    return json.loads(Path(path).read_text())


def log(message):
    print(time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), message, flush=True)


def outputs_root(cfg):
    return Path(cfg.get('outputs_root') or ROOT)


def ledger_dir(cfg):
    if cfg.get('run'):
        return outputs_root(cfg) / 'platform_logs' / cfg['run']
    return ROOT / 'platform_logs'


def command_jobs(cfg):
    source, py = Path(cfg['source']), cfg['python']
    count = 2
    common = ['--cache', cfg['cache'], '--vae', cfg['vae']]
    queues = []
    for index, name in enumerate(('A_fresh', 'B_s0warm')):
        if cfg.get('run') and cfg['run'] != name:
            continue
        cards = list(map(str, cfg['gpus'] if cfg.get('run') else
                         cfg['gpus'][index * count:(index + 1) * count]))
        out = outputs_root(cfg) / name
        tasks = []
        if index == 1:
            for mode, output, extra in (
                ('mu', Path(cfg['eval_mu_output']), []),
                ('noise', Path(cfg['tolerance_output']), ['--alphas', '0,0.02,0.05,0.1,0.2,0.3,0.5', '--seeds', '0']),
            ):
                tasks.append(dict(name=mode, kind='eval', output=str(output), gpus=cards[:1],
                                  command=[py, '-u', str(source / 'evaluate.py'), '--mode', mode,
                                           *common, '--output', str(output), *extra]))
        command = [py, '-m', 'torch.distributed.run', '--nnodes=1', '--nproc_per_node=2',
                   '--rdzv_backend=static', '--master_addr=127.0.0.1',
                   f'--master_port={29651 + index}',
                   str(ROOT / 'preflight_20261015/tools/train_distributed.py'), '--source', str(source)]
        command += [*common, '--output', str(out), '--max-updates', str(cfg['max_updates']),
                    '--chunk-tokens', str(cfg['chunk_tokens']), '--attention', cfg['attention'],
                    '--checkpoint-activations', str(cfg['checkpoint_activations'])]
        if cfg.get('checkpoint_flow_layers') is not None:
            command += ['--checkpoint-flow-layers', str(cfg['checkpoint_flow_layers'])]
        if index == 1:
            command += ['--init-vertex', cfg['s0']]
        tasks.append(dict(name=name, kind='train', output=str(out), gpus=cards, command=command))
        for suffix, weights, steps, samplers, dtype in (
            ('sweep_ema', 'ema', '10,20,50', 'euler,dpm2m', 'bf16'),
            ('sweep_raw', 'raw', '20', 'euler', 'bf16'),
            ('sweep_ema_fp32', 'ema', '20', 'euler', 'fp32'),
        ):
            output = out / suffix
            tasks.append(dict(name=f'{name}_{suffix}', kind='eval', output=str(output), gpus=cards[:1],
                              command=[py, '-u', str(source / 'evaluate.py'), '--mode', 'flow', *common,
                                       '--checkpoint', str(out / 'FINAL_CHECKPOINT_FROM_MANIFEST'), '--weights', weights,
                                       '--seeds', '0,1', '--steps', steps, '--samplers', samplers,
                                       '--dtype', dtype, '--attention', 'sdpa' if dtype == 'fp32' else cfg['attention'],
                                       '--output', str(output)]))
        queues.append(tasks)
    return queues


def verify(cfg):
    if cfg['mode'] != 'two-pairs':
        raise ValueError('this tested entry requires the two-pairs recipe')
    if cfg.get('run') not in (None, 'A_fresh', 'B_s0warm'):
        raise ValueError('unknown selected run')
    count = 2 if cfg.get('run') else 4
    if len(cfg['gpus']) != count or len(set(map(str, cfg['gpus']))) != count:
        raise ValueError(f'{cfg["mode"]} requires exactly {count} distinct GPUs')
    if cfg['max_updates'] != 10000:
        raise ValueError('T1 has a fixed maximum of 10000 updates; early pass remains enabled')
    if cfg['initial_gpu_seconds'] is None or cfg['initial_gpu_seconds'] < 0:
        raise ValueError('initial_gpu_seconds must be nonnegative; preflight is reported separately')
    max_budget = 45 if cfg.get('run') else 90
    if not (0 < cfg['budget_gpu_hours'] <= max_budget):
        raise ValueError(f'budget_gpu_hours must be in (0, {max_budget}]')
    verified_outputs = verify_training_outputs(command_jobs(cfg))
    manifest = read_json(cfg['manifest'])
    records = {str(Path(row['path']).resolve()): row for row in manifest['files']}
    required = [Path(cfg['source']) / 'train.py', Path(cfg['source']) / 'evaluate.py',
                Path(cfg['cache']) / 'manifest.json', Path(cfg['vae']), Path(cfg['s0'])]
    required.append(ROOT / 'preflight_20261015/tools/train_distributed.py')
    for path in required:
        if str(path.resolve()) not in records:
            raise ValueError(f'manifest has no SHA256 for required input: {path}')
    for path, row in records.items():
        file = Path(path)
        if not file.is_file() or file.stat().st_size != row['bytes'] or sha(file) != row['sha256']:
            raise ValueError(f'file missing, size or SHA256 mismatch: {path}')
    for key, marker in [('cpu_gate_log', 'CPU_GATE_OK'), ('cache_check_log', 'CACHE_OK')]:
        if not cfg.get(key) or marker not in Path(cfg[key]).read_text():
            raise ValueError(f'{key} must exist and contain {marker}')
    speed = read_json(cfg['speed_report'])
    seconds = speed.get('seconds_per_update_median')
    if seconds is None or not 0 < seconds <= 30:
        raise ValueError('speed gate requires measured seconds_per_update_median in (0, 30]')
    if not Path(cfg['python']).is_file():
        raise ValueError(f'Python missing: {cfg["python"]}')
    if not os.path.ismount('/guohaoran'):
        raise ValueError('/guohaoran is not a visible mount; configure the persistent directory in AIStation')
    check = (
        'import json,sys,importlib.metadata,torch; '
        'from flash_attn import flash_attn_varlen_func; '
        'assert callable(flash_attn_varlen_func); '
        'assert not torch.cuda.is_initialized(); '
        'print(json.dumps(dict(torch_version=torch.__version__,torch_cuda=torch.version.cuda,'
        'flash_attn_version=importlib.metadata.version("flash-attn"),python_version=sys.version.split()[0])))'
    )
    env = dict(os.environ, CUDA_VISIBLE_DEVICES='', PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION='python',
               OMP_NUM_THREADS='8')
    actual = json.loads(subprocess.check_output([cfg['python'], '-c', check], env=env, text=True, timeout=60))
    expected = cfg.get('runtime_expected', {})
    if not {'torch_version', 'flash_attn_version'} <= expected.keys():
        raise ValueError('runtime_expected must pin torch_version and flash_attn_version from the measured image')
    if any(actual.get(key) != value for key, value in expected.items()):
        raise ValueError(f'AIStation image/runtime differs from measured environment: {actual}')
    log('RUNTIME_OK ' + json.dumps(actual))
    log(f'CPU_VERIFY_OK source_commit={manifest.get("source_commit", manifest.get("commit"))} files={len(records)}')
    return verified_outputs


def process_birth(pid):
    try:
        return Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()[19]
    except (FileNotFoundError, ProcessLookupError):
        return None


def visible_cards_free(cfg):
    raw = subprocess.check_output(['nvidia-smi', '--query-gpu=index,uuid', '--format=csv,noheader'], text=True)
    mapping = dict(line.strip().split(', ') for line in raw.splitlines() if line.strip())
    chosen = {mapping.get(str(i), str(i)) for i in cfg['gpus']}
    if not chosen <= set(mapping.values()):
        raise ValueError('requested GPUs are not present in this task allocation')
    raw = subprocess.check_output(['nvidia-smi', '--query-compute-apps=gpu_uuid,pid', '--format=csv,noheader'], text=True)
    occupied = [line for line in raw.splitlines() if line.split(',')[0].strip() in chosen]
    if occupied:
        raise RuntimeError('requested GPUs already have processes; nothing was started: ' + '; '.join(occupied))
    ports = {'A_fresh': (29651,), 'B_s0warm': (29652,)}.get(cfg.get('run'), (29651, 29652))
    for port in ports:
        with socket.socket() as check:
            check.bind(('127.0.0.1', port))


def complete(task):
    output = Path(task['output'])
    if task['kind'] == 'train':
        status = output / 'status.json'
        return status.exists() and read_json(status).get('state') == 'complete' and (output / 'final.json').is_file()
    result = output / 'results.json'
    if not result.exists():
        return False
    data = read_json(result)
    expected = 7 if task['name'] == 'noise' else (12 if task['name'].endswith('sweep_ema') else 2)
    if task['name'] == 'mu':
        expected = 1
    return len(data.get('results', {})) == expected


def verified_checkpoint(output, name):
    manifest = output / f'{name}.json'
    if not manifest.exists():
        return None
    record = read_json(manifest)
    file = Path(record['file'])
    if not file.is_absolute():
        file = output / file
    if file.resolve().parent != output.resolve():
        raise RuntimeError(f'checkpoint pointer escaped its run directory: {file}')
    if file.stat().st_size != record['bytes'] or sha(file) != record['sha256']:
        raise RuntimeError(f'checkpoint SHA256 mismatch: {file}')
    return file


def verify_training_outputs(queues):
    """Reject incompatible run directories before starting any queued GPU task."""
    verified = {}
    for task in (task for queue in queues for task in queue if task['kind'] == 'train'):
        output = Path(task['output'])
        if not output.exists() or not any(output.iterdir()):
            verified[str(output)] = {}
            continue
        for name in ('final', 'latest'):
            if (output / f'{name}.json').exists():
                verified[str(output)] = {name: verified_checkpoint(output, name)}
                break
        else:
            if not (output / 'migration.json').is_file():
                raise FileExistsError(f'output is nonempty without a verified latest.json, final.json '
                                      f'or migration.json; no GPU process started: {output}')
            from single_gpu_migration import verify_migration
            verified[str(output)] = {'migration': verify_migration(output, sha)}
    return verified


def allocated_gpu_seconds(ledger):
    return ledger['initial_gpu_seconds'] + sum(
        session.get('gpu_seconds', max(0, time.time() - session['started_at']) * session['gpu_count'])
        for session in ledger['allocation_sessions'])


def open_allocation(cfg, started_at=None):
    path = ledger_dir(cfg) / 'budget_ledger.json'
    ledger = read_json(path) if path.exists() else dict(
        version=2, initial_gpu_seconds=cfg['initial_gpu_seconds'], allocation_sessions=[], segments=[], events=[])
    if ledger['version'] != 2:
        raise ValueError('unsupported budget ledger version; refusing to reset historical accounting')
    if ledger['initial_gpu_seconds'] != cfg['initial_gpu_seconds']:
        raise ValueError('initial_gpu_seconds changed after ledger creation; refusing a budget reset')
    hostname, now = socket.gethostname(), time.time()
    for seg in ledger['segments']:
        if seg.get('ended_at') is None:
            birth = process_birth(seg['pid']) if seg['hostname'] == hostname else None
            if birth is not None and birth == seg['process_birth']:
                raise RuntimeError(f'prior owned process still alive, refusing duplicate launch: {seg["pid"]}')
            seg.update(ended_at=now, status='prior_process_no_longer_present')
    for session in ledger['allocation_sessions']:
        if session.get('ended_at') is None:
            session.update(ended_at=now, status='unclosed_interval_charged_conservatively',
                           gpu_seconds=max(0, now - session['started_at']) * session['gpu_count'])
    ledger['budget_gpu_hours'] = cfg['budget_gpu_hours']
    ledger['allocation_sessions'].append(dict(started_at=now if started_at is None else started_at,
        ended_at=None, gpu_count=len(cfg['gpus']), hostname=hostname, pid=os.getpid(), status='active'))
    write_json(path, ledger)
    return ledger


def close_allocation(ledger, cfg):
    session = ledger['allocation_sessions'][-1]
    now = time.time()
    session.update(ended_at=now, status='closed',
                   gpu_seconds=max(0, now - session['started_at']) * session['gpu_count'])
    write_json(ledger_dir(cfg) / 'budget_ledger.json', ledger)


def remaining_shutdown_seconds(cfg, ledger):
    return min(cfg['shutdown_grace_seconds'],
               max(0, cfg['budget_gpu_hours'] * 3600 - allocated_gpu_seconds(ledger)) / len(cfg['gpus']))


def run(cfg, queues, ledger, verified_outputs=None):
    ledger_path = ledger_dir(cfg) / 'budget_ledger.json'
    hostname = socket.gethostname()
    if verified_outputs is None:
        verified_outputs = verify_training_outputs(queues)
    final_checkpoints = {output: record['final'] for output, record in verified_outputs.items()
                         if 'final' in record}
    visible_cards_free(cfg)
    outputs_root(cfg).mkdir(parents=True, exist_ok=True)
    active, finished, stopping, stop_at = {}, set(), None, None
    limit = cfg['budget_gpu_hours'] * 3600
    shutdown_grace = cfg['shutdown_grace_seconds']

    def used():
        return allocated_gpu_seconds(ledger)

    def request_stop(reason):
        nonlocal stopping, stop_at
        if stopping:
            return
        stopping, stop_at = reason, time.monotonic()
        ledger['events'].append(dict(time=time.time(), event='stop_requested', reason=reason))
        log('STOP_REQUESTED ' + reason)
        for process, task, _, _ in active.values():
            if task['kind'] == 'train':
                output = Path(task['output'])
                output.mkdir(parents=True, exist_ok=True)
                (output / 'STOP').write_text(reason + '\n')
            else:
                process.send_signal(signal.SIGTERM)
        write_json(ledger_path, ledger)

    signal.signal(signal.SIGTERM, lambda *_: request_stop('AIStation SIGTERM'))
    signal.signal(signal.SIGINT, lambda *_: request_stop('operator SIGINT'))
    try:
        while len(finished) != len(queues) or active:
            if not stopping:
                reserve = len(cfg['gpus']) * shutdown_grace
                if used() >= limit - reserve:
                    request_stop('shared GPU-hour budget; shutdown reserve entered')
            for index, tasks in enumerate(queues):
                if index in active or index in finished or stopping:
                    continue
                while tasks and complete(tasks[0]):
                    task = tasks.pop(0)
                    log('ALREADY_COMPLETE ' + task['name'])
                if not tasks:
                    finished.add(index)
                    continue
                task = tasks.pop(0)
                if task['kind'] == 'train':
                    output = Path(task['output'])
                    (output / 'STOP').unlink(missing_ok=True)
                for arg_index, argument in enumerate(task['command']):
                    if argument.endswith('/FINAL_CHECKPOINT_FROM_MANIFEST'):
                        output = Path(argument).parent
                        checkpoint = final_checkpoints.get(str(output))
                        if checkpoint is None:
                            checkpoint = verified_checkpoint(output, 'final')
                        if checkpoint is None:
                            raise RuntimeError('sampler sweep requires a committed final checkpoint')
                        final_checkpoints[str(output)] = checkpoint
                        task['command'][arg_index] = str(checkpoint)
                env = dict(os.environ, PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION='python', OMP_NUM_THREADS='8',
                           PYTHONUNBUFFERED='1', CUDA_VISIBLE_DEVICES=','.join(task['gpus']))
                stream = (outputs_root(cfg) / f'{task["name"]}.log').open('a', buffering=1)
                log('START ' + task['name'] + ' ' + shlex.join(task['command']))
                process = subprocess.Popen(task['command'], cwd=cfg['source'], env=env,
                                           stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
                segment = dict(name=task['name'], started_at=time.time(), gpu_count=len(task['gpus']),
                               pid=process.pid, process_birth=process_birth(process.pid), hostname=hostname,
                               command=task['command'], ended_at=None)
                ledger['segments'].append(segment)
                active[index] = (process, task, stream, segment)
                write_json(ledger_path, ledger)
            for index, (process, task, stream, segment) in list(active.items()):
                code = process.poll()
                if code is not None:
                    segment.update(ended_at=time.time(), status='exited', returncode=code,
                                   gpu_seconds=(time.time() - segment['started_at']) * segment['gpu_count'])
                    stream.close()
                    del active[index]
                    write_json(ledger_path, ledger)
                    log(f'EXIT {task["name"]} returncode={code}')
                    if code != 0 and not stopping:
                        request_stop(f'{task["name"]} exited {code}; no automatic retry')
                    elif not stopping and not complete(task):
                        request_stop(f'{task["name"]} returned success without expected complete outputs')
                elif task['kind'] == 'train' and not stopping:
                    path = Path(task['output']) / 'train.jsonl'
                    if path.exists():
                        with path.open('rb') as stream_log:
                            stream_log.seek(max(0, path.stat().st_size - 65536))
                            lines = stream_log.read().splitlines()
                        for line in reversed(lines):
                            try:
                                row = json.loads(line)
                            except (ValueError, UnicodeError):
                                continue
                            if row.get('seconds', 0) > 30:
                                request_stop(f'{task["name"]} update {row.get("update")} exceeded 30 seconds')
                            break
            if stopping:
                if not active:
                    break
                if time.monotonic() - stop_at >= shutdown_grace or used() >= limit:
                    for process, task, _, _ in active.values():
                        log('FORCE_TERMINATE ' + task['name'] + '; previous atomic checkpoint retained')
                        os.killpg(process.pid, signal.SIGKILL)
            write_json(ledger_path, ledger)
            if active or (not stopping and len(finished) != len(queues)):
                time.sleep(2)
        ledger['events'].append(dict(time=time.time(), event='launcher_exit', reason=stopping or 'complete',
                                     gpu_seconds=used()))
        write_json(ledger_path, ledger)
        log(f'LAUNCHER_EXIT reason={stopping or "complete"} cumulative_gpu_hours={used()/3600:.4f}')
        return 1 if stopping else 0
    except BaseException:
        request_stop('launcher exception; saving children before exit')
        deadline = time.monotonic() + remaining_shutdown_seconds(cfg, ledger)
        for process, task, stream, segment in active.values():
            try:
                code = process.wait(timeout=min(max(0, deadline - time.monotonic()),
                                                remaining_shutdown_seconds(cfg, ledger)))
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                code = process.wait()
            segment.update(ended_at=time.time(), status='launcher_exception', returncode=code,
                           gpu_seconds=(time.time() - segment['started_at']) * segment['gpu_count'])
            stream.close()
        write_json(ledger_path, ledger)
        raise


def main():
    invocation_started = time.time()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, default=ROOT / 'preflight_20261015/launch_config.json')
    parser.add_argument('--dry-run', '--prepare-only', '--preflight-dry-run', action='store_true')
    parser.add_argument('--run', choices=('A_fresh', 'B_s0warm'),
                        help='launch one experiment with two GPUs and half the shared budget')
    args = parser.parse_args()
    cfg = {**DEFAULTS, **read_json(args.config)}
    if cfg.get('require_pair_submission') and not args.run:
        parser.error('this configuration requires two separate submissions: --run A_fresh and --run B_s0warm')
    cfg['gpus'] = list(map(str, cfg['gpus']))
    if args.run:
        prior = cfg.get('pair_initial_gpu_seconds', {})
        if args.run not in prior:
            raise ValueError('pair_initial_gpu_seconds must explicitly account for prior work in the selected run')
        cfg.update(run=args.run, gpus=cfg['gpus'][:2],
                   budget_gpu_hours=cfg['budget_gpu_hours'] / 2, initial_gpu_seconds=prior[args.run])
    queues = command_jobs(cfg)
    if args.dry_run:
        verify(cfg)
        print(json.dumps(dict(config=cfg, queues=queues, no_gpu_work_started=True), indent=2))
        return 0
    ledger_dir(cfg).mkdir(parents=True, exist_ok=True)
    lock = (ledger_dir(cfg) / 'launcher.lock').open('a')
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        lock.close()
        log('ALREADY_RUNNING; singleton lock held, no second process started')
        return 0
    ledger = open_allocation(cfg, invocation_started)
    old_alarm_handler = signal.getsignal(signal.SIGALRM)

    def allocation_deadline(*_):
        raise TimeoutError('formal allocation hard GPU-hour budget reached')

    try:
        remaining = (cfg['budget_gpu_hours'] * 3600 - allocated_gpu_seconds(ledger)) / len(cfg['gpus'])
        if remaining <= cfg['shutdown_grace_seconds']:
            raise RuntimeError('formal allocation budget has entered its shutdown reserve; verification not started')
        signal.signal(signal.SIGALRM, allocation_deadline)
        signal.setitimer(signal.ITIMER_REAL, remaining)
        verified_outputs = verify(cfg)
        return run(cfg, queues, ledger, verified_outputs)
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, old_alarm_handler)
        try:
            close_allocation(ledger, cfg)
        finally:
            lock.close()


if __name__ == '__main__':
    raise SystemExit(main())
