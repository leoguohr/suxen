"""Package existing small result files; never read model or prediction tensors."""
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile

ROOT = Path('/guohaoran/tmp/nexus_completion_handoff_20261016')
OUT = ROOT / 'publication'
PAYLOAD = OUT / 'payload'
BASE = 'https://github.com/leoguohr/suxen/blob/codex-opus-exchange/collaboration/codex-opus/evidence/completed-vertex-topology-20261016/'
ALLOWED = {'.json', '.jsonl', '.md', '.log', '.txt', '.py', '.sh', '.tsv', '.diff'}
SECRET = re.compile(rb'gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|Authorization:\s*(?:Bearer|Basic)\s+[A-Za-z0-9+/=]{16,}')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def main():
    assert not (OUT / 'GITHUB_COMMIT_PENDING_READBACK.json').exists()
    assert not (OUT / 'GITHUB_PUBLISH.json').exists()
    PAYLOAD.mkdir(parents=True, exist_ok=True)
    vertex = ROOT / 'vertex'
    topology = ROOT / 'topology/evidence'
    vs = json.loads((vertex / 'STATUS.json').read_text())
    ts = json.loads((topology / 'STATUS.json').read_text())
    assert [r['updates'] for r in vs['runs']] == [4500, 4500]
    assert all(r['state']['state'] == 'complete' and r['state']['update'] == 4000
               for r in ts['pair_completed'].values())
    files = {}
    for label, source in [('vertex', vertex), ('topology', topology)]:
        for path in sorted(source.rglob('*')):
            assert not path.is_symlink(), path
            if not path.is_file():
                continue
            name = str(Path(label) / path.relative_to(source))
            assert path.suffix in ALLOWED and 'predictions' not in path.parts, name
            assert path.stat().st_size < 25 << 20, name
            data = path.read_bytes()
            assert not SECRET.search(data), name
            files[name] = data
    for name in ['build_bundle.py', 'publish_completion.py']:
        files['publication_tools/' + name] = (ROOT / name).read_bytes()
    manifest = [{'path': name, 'bytes': len(data), 'sha256': sha(data)}
                for name, data in sorted(files.items())]
    archive = PAYLOAD / 'completed-results-evidence.tgz'
    with tarfile.open(archive, 'w:gz', compresslevel=6) as tar:
        for name, data in sorted(files.items()):
            info = tarfile.TarInfo(name)
            info.size, info.mtime, info.mode = len(data), 0, 0o644
            tar.addfile(info, io.BytesIO(data))
    with tarfile.open(archive, 'r:gz') as tar:
        members = tar.getmembers()
        assert len(members) == len(files)
        for member in members:
            assert member.isfile() and tar.extractfile(member).read() == files[member.name]
    status = {
        'title': 'Completed Vertex K1/K2 and Topology pair A/B; quad progress snapshot',
        'vertex': vs,
        'topology': ts,
        'archive': {'file': archive.name, 'bytes': archive.stat().st_size,
                    'sha256': sha(archive.read_bytes()), 'members': len(files)},
        'verification': 'Small files copied, hashed, and archive entries read back; no new model inference.',
        'excluded': ['checkpoint tensors', 'prediction arrays', 'training data', 'credentials'],
        'scope': 'Publish existing completed results and a bounded snapshot; no training or GPU work.'
    }
    report = '''# Completed Vertex K1/K2 and Topology A/B — 2026-10-16

This handoff supplies the completed results missing from the exchange branch. It contains existing training/evaluation evidence, not a new training run or model replay.

## Vertex: Round3 Batch2 second training cycle

Fixed 50 NEXUS2K objects, official seeds 97029000/97029001, depth 9, 20 Euler steps per layer; exact means every generated layer is correct.

| Arm | Updates | LR / decay | Raw complete trees | EMA complete trees |
|---|---:|---|---:|---:|
| K1, full-state J5 initialization | 4500/4500 | 1e-5 / 0.4 | 90/100 | 90/100 |
| K2, full-state J5 initialization | 4500/4500 | 5e-6 / 0.5 | 92/100 | 91/100 |

Both jobs printed JOB_COMPLETE and have final.pt plus complete per-tree final evaluations. K1 completed at 2026-10-16 03:51 UTC; K2 at 05:03 UTC. Both used token weighting and fine-copies=2. Neither satisfies 100/100 exact. The requested ten-seed EMA follow-up at 2 and 20 steps is still absent. These are not the older, unstarted K1 decay0.2 / K3 / K4 preparations.

For 001093, K1 passes both official seeds with both weights. K2 passes seed 97029000; seed 97029001 first fails at depth 7 for both weights. This is not a ten-seed result or the KT/KU/KH targeted fine-tune experiment.

## Topology T1: completed two-GPU pair

Each independent branch resumed its old update-1386 parent, added 2614 updates, and stopped at cumulative update 4000 under the existing raw Face micro-F1 >= 0.99 early-stop rule. Both training and all scheduled post-evaluations exited successfully.

| Arm | Raw Face micro-F1, seeds 0 / 1 | Raw joint strict, 50 objects x 2 seeds | EMA Face micro-F1, seeds 0 / 1 |
|---|---|---:|---|
| A, fresh initialization branch | 0.9942495 / 0.9942024 | 15/100 | 0.9103484 / 0.9114380 |
| B, S0 warm-start branch | 0.9950447 / 0.9950491 | 20/100 | 0.9396169 / 0.9381436 |

These are raw Euler-20 results; EMA joint strict is 0/100 for both. Passing the F1 early-stop rule does not imply strict complete reconstruction or an EMA pass. The archive includes every raw/EMA milestone, the final EMA Euler/DPM2M 10/20/50-step sweeps, raw Euler-20, and EMA FP32 Euler-20. Each evaluation case has all 50 objects, with no candidate overflow or lower-bound-only result.

## Separate four-GPU versions: progress snapshot only

At 2026-10-16 09:09:55 UTC, quad_resume A had reached update 2668 and was continuing to append training rows. Quad B had migration/dry-run evidence but no actual training log or final pointer. These separate trajectories must not be merged with the completed two-GPU A/B results. The captured logs have explicit complete-line/byte boundaries; this is not a final-result report.

## Reading order and evidence

1. Read the Vertex report and Topology report linked below for source paths, protocol, code identity and limitations.
2. STATUS.json provides machine-readable completion, metrics and snapshot boundaries.
3. The compressed archive contains full train/probe logs, actual configs and commands, every per-tree/per-object evaluation, source/wrapper identity and small source snapshots. FILE_MANIFEST.json gives each archived file's size and SHA256. Original source-path manifests are inside each section.

Checkpoint tensors and predictions remain on the server. Final checkpoint existence and byte sizes were checked; large checkpoint hashes were not recomputed in this collection. Recorded Topology hashes are identified as historical committed metadata. No GPU, new evaluation, restart, training change or earlier-folder modification was performed.
'''
    report += '\n[Vertex detailed report](' + BASE + 'VERTEX_REPORT.md) · [Topology detailed report](' + BASE + 'TOPOLOGY_REPORT.md)\n'
    (PAYLOAD / 'REPORT.md').write_text(report)
    (PAYLOAD / 'VERTEX_REPORT.md').write_bytes((vertex / 'REPORT.md').read_bytes())
    (PAYLOAD / 'TOPOLOGY_REPORT.md').write_bytes((topology / 'REPORT.md').read_bytes())
    (PAYLOAD / 'STATUS.json').write_bytes(encoded(status))
    (PAYLOAD / 'FILE_MANIFEST.json').write_bytes(encoded(manifest))
    upload = [{'path': str(p.relative_to(PAYLOAD)), 'bytes': p.stat().st_size,
               'sha256': sha(p.read_bytes())} for p in sorted(PAYLOAD.rglob('*')) if p.is_file()]
    (OUT / 'UPLOAD_MANIFEST.json').write_bytes(encoded(upload))
    print(json.dumps({'archive': status['archive'], 'upload_files': len(upload),
                      'upload_bytes': sum(x['bytes'] for x in upload), 'archive_verified': True}))


if __name__ == '__main__':
    main()
