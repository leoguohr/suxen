"""Publish external Topology T1 launch/startup/suspension evidence; token arrives only as stdin JSON."""
import argparse
import base64
from concurrent.futures import ThreadPoolExecutor
import fcntl
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import sys
import tarfile
import time
import urllib.error
import urllib.parse
import urllib.request

API = 'https://api.github.com/repos/leoguohr/suxen'
BRANCH = 'codex-opus-exchange'
PREFIX = 'collaboration/codex-opus/'
NAME = MESSAGE = TITLE = EVIDENCE = ARCHIVE = None


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def api_once(path, token, data=None, method=None):
    request = urllib.request.Request(API + path, data=None if data is None else encoded(data), method=method,
        headers={'Authorization': 'Bearer ' + token, 'Accept': 'application/vnd.github+json',
                 'Content-Type': 'application/json', 'User-Agent': 'nexus-topology-t1-publication'})
    with urllib.request.urlopen(request, timeout=120) as response:
        return json.load(response)


def configure(folder):
    global NAME, MESSAGE, TITLE, EVIDENCE, ARCHIVE
    NAME = 'completed-vertex-topology-20261016'
    MESSAGE = PREFIX + 'messages/20261016-completed-vertex-topology-results.md'
    TITLE = 'Completed Vertex K1/K2 and Topology pair A/B; quad progress snapshot'
    EVIDENCE = PREFIX + 'evidence/' + NAME + '/'
    ARCHIVE = 'completed-results-evidence.tgz'


FORBIDDEN = re.compile(rb'gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|Authorization:\s*(?:Bearer|Basic)\s+[A-Za-z0-9+/=]{16,}')


def network_retry(call):
    for attempt in range(4):
        try:
            return call()
        except urllib.error.HTTPError as error:
            if error.code not in (429, 500, 502, 503, 504) or attempt == 3:
                raise
        except (urllib.error.URLError, OSError):
            if attempt == 3:
                raise
        time.sleep(2 ** attempt)


HTTP_DIAGNOSTICS = None


def api(*args, **kwargs):
    def request():
        try:
            return api_once(*args, **kwargs)
        except urllib.error.HTTPError as error:
            body = error.read(8192).decode('utf-8', errors='replace')
            body = body.replace(args[1], '[REDACTED]')
            body = re.sub(r'gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}', '[REDACTED]', body)
            record = {'path': args[0], 'status': error.code, 'response_body': body, 'time_unix': time.time()}
            if HTTP_DIAGNOSTICS is not None:
                with HTTP_DIAGNOSTICS.open('a') as stream:
                    stream.write(json.dumps(record) + '\n')
            print('HTTP_DIAGNOSTIC', json.dumps(record), file=sys.stderr, flush=True)
            raise
    return network_retry(request)


def scan(content, token, compressed=False):
    with gzip.GzipFile(fileobj=io.BytesIO(content)) if compressed else io.BytesIO(content) as stream:
        tail = b''
        while block := stream.read(1 << 20):
            window = tail + block
            assert token.encode() not in window and not FORBIDDEN.search(window), 'Credential detected in evidence'
            tail = window[-max(4096, len(token)):]


def collect(folder, token):
    root, manifest_path = folder / 'payload', folder / 'UPLOAD_MANIFEST.json'
    assert root.is_dir() and not root.is_symlink()
    assert manifest_path.is_file() and not manifest_path.is_symlink() and manifest_path.stat().st_size < 25 << 20
    manifest_bytes = manifest_path.read_bytes()
    manifest = json.loads(manifest_bytes)
    assert isinstance(manifest, list) and manifest, 'Expected nonempty upload manifest'
    expected = {}
    for row in manifest:
        name = row['path']
        path = PurePosixPath(name)
        assert name and str(path) == name and not path.is_absolute() and '..' not in path.parts and '\\' not in name, 'Unsafe manifest path'
        assert name not in expected and name != 'UPLOAD_MANIFEST.json', 'Duplicate or reserved manifest path'
        assert not {suffix.lower() for suffix in path.suffixes} & {'.pt', '.pth', '.npz'}, 'Model or prediction file is forbidden'
        assert 'predictions' not in path.parts and path.suffix.lower() in ('.json', '.jsonl', '.md', '.log', '.txt', '.py', '.sh', '.tsv', '.diff', '.gz', '.tgz', '.sha256'), 'Disallowed evidence type'
        assert type(row['bytes']) is int and 0 <= row['bytes'] < 25 << 20 and re.fullmatch('[0-9a-f]{64}', row['sha256'])
        expected[name] = row
    actual = []
    for path in root.rglob('*'):
        assert not path.is_symlink(), 'Symlink in payload'
        if not path.is_dir():
            assert path.is_file(), 'Nonregular payload file'
            actual.append(str(path.relative_to(root)))
    assert set(actual) == set(expected), 'Payload files differ from manifest'
    assert {'REPORT.md', 'STATUS.json', 'FILE_MANIFEST.json'} <= set(expected)
    assert sum(row['bytes'] for row in manifest) + len(manifest_bytes) < 80 << 20, 'Upload exceeds 80 MiB'
    files = {'UPLOAD_MANIFEST.json': manifest_bytes}
    for name in sorted(expected):
        path, row = root / name, expected[name]
        assert path.stat().st_size == row['bytes'], 'File size changed'
        content = path.read_bytes()
        assert len(content) == row['bytes'] and sha(content) == row['sha256'], 'File hash changed'
        scan(content, token)
        if name.lower().endswith('.gz'):
            scan(content, token, compressed=True)
        files[name] = content
    validate_archive(files, token)
    scan(manifest_bytes, token)
    return files, sha(manifest_bytes)


def validate_archive(files, token):
    manifest = json.loads(files['FILE_MANIFEST.json'])
    expected = {row['path']: row for row in manifest}
    assert len(expected) == len(manifest) and expected, 'Invalid archive manifest'
    seen = set()
    with tarfile.open(fileobj=io.BytesIO(files[ARCHIVE]), mode='r:gz') as archive:
        for member in archive:
            name, path = member.name, PurePosixPath(member.name)
            assert member.isfile() and name in expected and name not in seen
            assert str(path) == name and not path.is_absolute() and '..' not in path.parts and '\\' not in name
            assert path.suffix.lower() in ('.json', '.jsonl', '.md', '.log', '.txt', '.py', '.sh', '.tsv', '.diff', '.gz') and 'predictions' not in path.parts
            assert not {suffix.lower() for suffix in path.suffixes} & {'.pt', '.pth', '.npz'}
            row = expected[name]
            assert member.size == row['bytes'] and member.size < 25 << 20
            content = archive.extractfile(member).read()
            assert len(content) == row['bytes'] and sha(content) == row['sha256']
            scan(content, token)
            if name.lower().endswith('.gz'):
                scan(content, token, compressed=True)
            seen.add(name)
    assert seen == set(expected), 'Archive files differ from manifest'


def publish(folder, token):
    global HTTP_DIAGNOSTICS
    HTTP_DIAGNOSTICS = folder / 'HTTP_ERRORS.jsonl'
    configure(folder)
    files, manifest_sha = collect(folder, token)
    payload = {EVIDENCE + name: content for name, content in files.items()}
    payload[MESSAGE] = files['REPORT.md'] + f'\n[Compressed evidence](../evidence/{NAME}/{ARCHIVE}) · [Evidence files](../evidence/{NAME}/) · [Upload SHA256 manifest](../evidence/{NAME}/UPLOAD_MANIFEST.json)\n'.encode()
    receipt_path = folder / 'GITHUB_PUBLISH.json'
    pending_path = folder / 'GITHUB_COMMIT_PENDING_READBACK.json'
    prior = receipt_path if receipt_path.exists() else pending_path
    saved_hashes = None
    if prior.exists():
        receipt = json.loads(prior.read_text())
        saved_hashes = receipt['published_sha256']
        assert all(saved_hashes[path] == sha(content) for path, content in payload.items())
        assert receipt['manifest_sha256'] == manifest_sha and receipt['branch'] == BRANCH
        commit, parent = receipt['commit'], receipt['parent']
    else:
        def blob(path, content):
            value = api('/git/blobs', token, {'encoding': 'base64', 'content': base64.b64encode(content).decode()})
            assert value['sha'] == hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\0' + content).hexdigest()
            return {'path': path, 'mode': '100644', 'type': 'blob', 'sha': value['sha']}
        with ThreadPoolExecutor(max_workers=4) as pool:
            entries = list(pool.map(lambda item: blob(*item), payload.items()))
        for attempt in range(4):
            parent = api('/git/ref/heads/' + BRANCH, token)['object']['sha']
            base = api('/git/commits/' + parent, token)
            try:
                existing = api('/contents/' + MESSAGE + '?ref=' + parent, token)
            except urllib.error.HTTPError as error:
                if error.code != 404:
                    raise
            else:
                assert base64.b64decode(existing['content']) == payload[MESSAGE], 'Destination already has a different report'
                commit, parent = parent, None
                break
            readme = base64.b64decode(api('/contents/' + PREFIX + 'README.md?ref=' + parent, token)['content'])
            readme += f'\n- [{TITLE}](messages/{MESSAGE.rsplit("/", 1)[1]})\n'.encode()
            tree = api('/git/trees', token, {'base_tree': base['tree']['sha'], 'tree': entries + [blob(PREFIX + 'README.md', readme)]})
            commit = api('/git/commits', token, {'message': TITLE, 'tree': tree['sha'], 'parents': [parent]})['sha']
            try:
                api('/git/refs/heads/' + BRANCH, token, {'sha': commit, 'force': False}, 'PATCH')
                payload[PREFIX + 'README.md'] = readme
                break
            except urllib.error.HTTPError as error:
                if error.code not in (409, 422) or attempt == 3:
                    raise
    hashes = saved_hashes or {path: sha(content) for path, content in payload.items()}
    pending = {'commit': commit, 'parent': parent, 'branch': BRANCH, 'manifest_sha256': manifest_sha,
               'published_sha256': hashes, 'state': 'committed_pending_public_readback'}
    temporary = pending_path.with_suffix('.tmp')
    temporary.write_bytes(encoded(pending)); temporary.replace(pending_path)
    print('COMMITTED', commit, flush=True)
    # The public Git blob API works on this host while raw.githubusercontent.com times out.
    # Verify immutable commit membership and content without any Authorization header.
    def public_json(path):
        request = urllib.request.Request(API + path, headers={
            'Accept': 'application/vnd.github+json', 'User-Agent': 'nexus-public-readback'})
        with urllib.request.urlopen(request, timeout=45) as response:
            return json.load(response)
    tree = network_retry(lambda: public_json('/git/trees/' + commit + '?recursive=1'))
    assert not tree.get('truncated'), 'Public tree truncated'
    entries = {x['path']: x for x in tree['tree'] if x['type'] == 'blob'}
    def verify(item):
        path, digest = item
        blob_id = entries[path]['sha']
        blob = network_retry(lambda: public_json('/git/blobs/' + blob_id))
        assert blob['encoding'] == 'base64'
        content = base64.b64decode(blob['content'])
        assert hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\0' + content).hexdigest() == blob_id
        assert sha(content) == digest, 'Public immutable readback mismatch'
    with ThreadPoolExecutor(max_workers=4) as pool:
        list(pool.map(verify, hashes.items()))
    receipt = {'commit': commit, 'parent': parent, 'branch': BRANCH, 'manifest_sha256': manifest_sha,
               'public_readback_verified': True, 'readback_method': 'unauthenticated immutable commit tree and Git blob API', 'published_sha256': hashes,
               'message_url': f'https://github.com/leoguohr/suxen/blob/{commit}/{MESSAGE}'}
    temporary = receipt_path.with_suffix('.tmp')
    temporary.write_bytes(encoded(receipt))
    temporary.replace(receipt_path)
    print('PUBLISH_VERIFIED', json.dumps(receipt), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bundle-dir', required=True, type=Path)
    args = parser.parse_args()
    token = json.load(sys.stdin)['token']
    assert isinstance(token, str) and len(token) >= 20 and not any(char.isspace() for char in token)
    folder = args.bundle_dir.resolve(strict=True)
    with (folder / '.publish.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        publish(folder, token)
