#!/usr/bin/env python3
"""Read-only collection of finished Round3 Batch2 K1/K2 small-file evidence."""
from pathlib import Path
import collections, datetime, hashlib, json, re, shutil, subprocess
ROOT = Path("/guohaoran/tmp/nexus_vertex_round3_batch2_20261015")
DEST = Path("/guohaoran/tmp/nexus_completion_handoff_20261016/vertex")
REPO = ROOT / "repo"
CODE = REPO / "vertex/dense_overfit50_20261009"
RUNS = ["K1_J5_lr1e-5_d0.4", "K2_J5_lr5e-6_d0.5"]
DEST.mkdir(parents=True, exist_ok=True)
if (DEST/"STATUS.json").exists():
    raise SystemExit("Existing collected STATUS.json: refusing overwrite")
copied = []
def digest(path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda:f.read(1024*1024), b""): h.update(b)
    return h.hexdigest()
def save_json(path, obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+"\n")
def copy(src, rel):
    if not src.is_file(): return
    assert src.suffix not in (".pt",".npz",".npy")
    assert "predictions" not in src.parts
    assert src.stat().st_size < 32*1024**2
    target=DEST/rel
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists(): raise RuntimeError("Refusing overwrite: "+str(target))
    shutil.copyfile(src,target)
    sha=digest(src)
    assert digest(target)==sha
    copied.append(dict(source=str(src),path=str(rel),bytes=src.stat().st_size,sha256=sha,
                       source_mtime_utc=datetime.datetime.fromtimestamp(src.stat().st_mtime,datetime.timezone.utc).isoformat()))
def git(*args):
    return subprocess.check_output(["git","-C",str(REPO),*args],text=True).strip()
head=git("rev-parse","HEAD")
porcelain=git("status","--porcelain")
assert head=="e7e3a326a65bc550be695104ae69e0d3435bd446"
assert not porcelain
identity=dict(commit=head,working_tree_status_porcelain=porcelain,checked_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              note="Current effective checkout hashes verified; no training or GPU work performed by this collector.")
identity["source_files"]=[]
for rel in git("ls-files").splitlines():
    p=REPO/rel
    if p.suffix in (".py",".sh",".yaml",".yml") and "data" not in p.parts and p.is_file():
        identity["source_files"].append(dict(path=rel,sha256=digest(p),bytes=p.stat().st_size))
save_json(DEST/"CODE_IDENTITY.json",identity)
for name in ["dense_train.py","common.py","packed.py","samplers.py","evaluate.py"]:
    copy(CODE/name,Path("source")/name)
for name in ["commands.txt","README_CN.md","DEPLOYMENT_REPORT.json","PERFORMANCE_STATUS.json","PERFORMANCE_STATUS.md",
             "audit/READY.json","audit/cpu_gate.log","audit/prepare.log",
             "server_audit/performance_launcher_validation.json","server_audit/performance_promotion.json","server_audit/schedule_check.json",
             "jobs/run_batch2.sh","jobs/prepare_batch2.sh","jobs/verify_init.py"]:
    copy(ROOT/name,Path("provenance")/name)
checks=[]
for name in RUNS:
    run=ROOT/"round3_train"/name
    config=json.loads((run/"config.json").read_text())
    status=json.loads((run/"status.json").read_text())
    train=[json.loads(x) for x in (run/"train.jsonl").read_text().splitlines() if x.strip()]
    assert [x["update"] for x in train]==list(range(1,4501))
    assert status["state"]=="complete" and status["update"]==4500
    logs=sorted((ROOT/"job_logs"/name).glob("console*.log"))
    completion=[]
    for p in logs:
        text=p.read_text()
        completion.extend(line for line in text.splitlines() if any(v in line for v in ["TRAINING_COMPLETE","JOB_COMPLETE","EXIT attempt=","START attempt="]))
        copy(p,Path("runs")/name/"job_logs"/p.name)
    assert any("JOB_COMPLETE updates=4500 final=" in line for line in completion)
    for fn in ["train.jsonl","probes.jsonl","config.json","status.json","evals.jsonl"]:
        copy(run/fn,Path("runs")/name/fn)
    copy(ROOT/"job_logs"/name/"command.txt",Path("runs")/name/"job_logs/command.txt")
    evaluations=[]
    for p in sorted(run.rglob("summary.json"))+sorted(run.rglob("evaluation.json")):
        if "predictions" not in p.relative_to(run).parts:
            copy(p,Path("runs")/name/p.relative_to(run))
    for p in sorted(run.rglob("evaluation.json")):
        x=json.loads(p.read_text()); rows=x["rows"]
        actual_pairs={(v["uid"],v["seed"]) for v in rows}
        expected_pairs={(u,s) for u in config["uids"] for s in (97029000,97029001)}
        exact=sum(bool(v["all_levels_exact"]) for v in rows)
        assert len(rows)==100 and actual_pairs==expected_pairs
        assert all(v["status"]=="complete" for v in rows)
        assert exact==x["full_trees_exact"]
        summary=json.loads((p.parent/"summary.json").read_text())
        assert summary["trees"]==100 and summary["full_trees_exact"]==exact
        evaluations.append(dict(path=str(p),weights=x["weights"],update=x["update"],trees=100,unique_uid_seed_pairs=len(actual_pairs),
            exact=exact,all_status_complete=True,seeds=x["seeds"],uids=50,per_depth_exact=[v["full_level_exact"] for v in summary["per_depth"]],
            target_001093=[dict(seed=v["seed"],all_levels_exact=v["all_levels_exact"],first_mismatch_depth=v["first_mismatch_depth"]) for v in rows if v["uid"]=="nexus_2k_001093"]))
    pt=run/"final.pt"; st=pt.stat()
    checkpoint=dict(path=str(pt),exists=True,bytes=st.st_size,mtime_utc=datetime.datetime.fromtimestamp(st.st_mtime,datetime.timezone.utc).isoformat(),
        reported_update=4500,reported_update_evidence="status.json and JOB_COMPLETE",sha256=None,
        tensor_contents_loaded_this_collection=False,limitation="No new checkpoint hash or tensor-content verification; .pt remains on server.")
    save_json(DEST/"runs"/name/"checkpoint_identity_metadata.json",checkpoint)
    checks.append(dict(name=name,source=str(run),updates=4500,budget=4500,training_log_rows=4500,contiguous_updates_verified=True,
        lr=config["lr"],decay_fraction=config["decay_fraction"],eval_steps=config["eval_steps"],checkpoint=checkpoint,
        completion_lines=completion,evaluations=evaluations,additional_10_seed_2_and_20_step_evaluations="Not found under this completed run directory; not executed by this collection."))
status=dict(task="Round3 Batch2 completed K1/K2 handoff",collected_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    source_root=str(ROOT),code_commit=head,runs=checks,collection_scope="Existing CPU-readable small files only; no training, GPU calls, new evaluations, .pt loading or old-folder modifications.",
    caveats=["Training completion is distinct from the 100/100 exact acceptance criterion; neither arm passes.",
             "K1 actually used decay_fraction=0.4. The separately prepared old K1 decay0.2 and K3/K4 are not these runs.",
             "Supplementary final EMA evaluations on ten seeds at 2 and 20 steps are not present in these completed run directories.",
             "Historical deployment/preparation reports say not started; they predate the terminal run logs and are provenance only.",
             "Source J5 SHA/full-state checks are historical evidence in audit/READY.json; final checkpoint SHA/tensors were not independently rechecked now."])
save_json(DEST/"STATUS.json",status)
report="""# Round3 Batch2: completed K1/K2 results

Both arms completed all 4,500 updates and their scheduled final raw/EMA evaluations. Neither reached the strict 100/100 complete-tree criterion.

| Arm | Initialization | LR | Decay fraction | Updates | Raw, 20-step Euler | EMA, 20-step Euler |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| K1_J5_lr1e-5_d0.4 | J5 final, full state | 1e-5 | 0.4 | 4500/4500 | 90/100 | 90/100 |
| K2_J5_lr5e-6_d0.5 | J5 final, full state | 5e-6 | 0.5 | 4500/4500 | 92/100 | 91/100 |

## Completion and integrity evidence

- K1 printed JOB_COMPLETE and exited 0 at 2026-10-16 03:51:51 UTC (11:51:51 Asia/Singapore).
- K2 printed JOB_COMPLETE and exited 0 at 2026-10-16 05:03:19 UTC (13:03:19 Asia/Singapore).
- Each training log contains exactly 4,500 contiguous update records, 1 through 4,500.
- All four final evaluation files contain 100 unique UID/seed pairs: the fixed 50 training UIDs x official seeds 97029000 and 97029001. Every row has status=complete. Recounted all_levels_exact matches its summary.
- All depths 1-5 are exact in all 100 trees for both arms. K1 raw/EMA depth 6-9 exact counts: 97,93,90,90. K2 raw: 100,96,93,92; EMA: 100,95,92,91.
- 001093: K1 raw and EMA pass both official seeds. K2 raw and EMA pass 97029000, but 97029001 first mismatches at depth 7.
- Each final.pt exists and is 37,320,289,539 bytes. Only filesystem metadata was collected now; no new final-checkpoint SHA or tensor verification is claimed.

## Effective recipe and provenance

- Frozen source checkout: e7e3a326a65bc550be695104ae69e0d3435bd446; current git working tree is clean. CODE_IDENTITY.json hashes the tracked effective Python/shell/YAML source without training data.
- J5 source: /guohaoran/tmp/nexus_vertex_dense_round2_20261009/runs/J5_token_fine2/final.pt.
- Recorded source SHA256: 4abd3a09d80bd4ffc6b1557681ef84d2a182b1bf101e429a995e83c959d24f58. Historical audit/READY.json records model/EMA/Adam/full-state inspection; this collection does not repeat that large-file read.
- Common effective settings: token weighting, fine-copies 2, warmup 20, max-updates 4500, eval-every 0, final-evals raw,ema, save-minutes 45, probe-minutes 30, seed 20261015.
- Performance settings actually used: row-tokens 2816, chunk-tokens 2816, checkpoint-activations 0. Commands and validation records are included.
- K1 used decay 0.4. Do not substitute the earlier unstarted K1 decay0.2 prepared directory, or count K3/K4 as completed.
- Preparation reports are timestamped historical evidence; their 'not started' fields precede these completed runs.

## Remaining scope

The requested supplementary final EMA evaluations on all ten seeds at 2 and 20 Euler steps are not found inside either completed run directory. The included results are the scheduled 100-tree official-pair final evaluations, not 500-tree supplementary results. No new training or evaluation was launched.

## Contents and exclusions

This package contains full training/probe logs, actual configs and status, every existing summary/evaluation JSON under the two runs, completion console logs, launch commands, small recipe source files, current code identity, and checkpoint filesystem metadata. MANIFEST.json records original paths and SHA256 for every copied small file. No checkpoint tensors, prediction arrays, training data, credentials, or GPU work are included.
"""
(DEST/"REPORT.md").write_text(report)
save_json(DEST/"MANIFEST.json",dict(source_root=str(ROOT),copied_files=copied,generated_files=["REPORT.md","STATUS.json","CODE_IDENTITY.json","collect_vertex.py","runs/*/checkpoint_identity_metadata.json"],copied_count=len(copied)))
allfiles=[p for p in DEST.rglob("*") if p.is_file()]
assert not any(p.suffix in (".pt",".npz",".npy") for p in allfiles)
print(json.dumps(dict(output=str(DEST),files=len(allfiles),bytes=sum(p.stat().st_size for p in allfiles),copied_files=len(copied),runs=[dict(name=v["name"],evaluations=[(e["weights"],e["exact"],e["trees"]) for e in v["evaluations"]]) for v in checks]),indent=2))
