# Round 3 Batch 2：K1 / K2 训练启动文件

- 当前：已上传服务器，CPU gate 通过，J5 SHA256、model、AdamW、EMA 已核验；未启动训练。
- 本轮只保留新 K1/K2；旧 K1–K4 文件和服务器目录不变。
- 训练源码固定为 `e7e3a326a65bc550be695104ae69e0d3435bd446`，无源码修改。

## 配方

| 项目 | K1 | K2 |
|---|---|---|
| 初始权重 | J5 final，update 9000 | 同左 |
| 初始化 | model + AdamW + EMA | 同左 |
| 新增 updates | 4500 | 4500 |
| loss weighting | token | token |
| fine copies | 2 | 2 |
| 学习率 | 1e-5 | 5e-6 |
| decay fraction | **0.4** | 0.5 |
| warmup | 20 | 20 |
| seed | 20261015 | 20261015 |
| 中途完整树评估 | **关闭：eval-every 0** | 同左 |
| 保存间隔 | 45 分钟 | 45 分钟 |
| 探针间隔 | 30 分钟，保留启动及结束探针 | 同左 |
| 训练器最终评估 | raw、EMA；各 100 树，20 步 Euler | 同左 |

共同初始文件：

```text
/guohaoran/tmp/nexus_vertex_dense_round2_20261009/runs/J5_token_fine2/final.pt
SHA256: 4abd3a09d80bd4ffc6b1557681ef84d2a182b1bf101e429a995e83c959d24f58
```

新周期从本轮 update 0 开始，继承 AdamW 状态并重新预热/衰减。K1 从 update 2701 开始衰减，K2 从 2251 开始；固定上游实现的 update 4500 学习率为 0。

## 部署后使用

`jobs/` 已上传到以下新目录：

```text
/guohaoran/tmp/nexus_vertex_round3_batch2_20261015/jobs/
```

CPU 准备已执行通过，留档命令：

```bash
bash /guohaoran/tmp/nexus_vertex_round3_batch2_20261015/jobs/prepare_batch2.sh
```

- 优先复制此前固定版本的 Git 对象，建立独立新 checkout；原 checkout 只读。
- 检查文件系统至少 150 GiB 剩余；个人存储配额需另核实。
- 执行 CPU gate，只有成功且结尾为 `ALL CPU TESTS PASSED in ...` 才继续。
- 重新核验 J5 SHA256、model、AdamW、EMA、来源 update。
- 生成本批次独立的 `audit/READY.json`。不复用上一批的准备标记。

CPU gate 或权重检查失败立即退出，不启动训练。

## 平台填写

每任务：单机、1 张 A100 80GB、8 核 CPU、建议 128GB 主机内存、16GB shm；沿用 `pytorch2.3-admin:cuda_12.4` 镜像。两组并行需要两张卡。新 A100 短测平均约 12.4 秒/更新；含探针、保存及终验，每组预计 21–23 小时。

| 任务 | 启动命令 |
|---|---|
| Batch2-K1 | `bash /guohaoran/tmp/nexus_vertex_round3_batch2_20261015/jobs/run_batch2.sh K1` |
| Batch2-K2 | `bash /guohaoran/tmp/nexus_vertex_round3_batch2_20261015/jobs/run_batch2.sh K2` |

日志路径：

```text
K1: /guohaoran/tmp/nexus_vertex_round3_batch2_20261015/job_logs/K1_J5_lr1e-5_d0.4
K2: /guohaoran/tmp/nexus_vertex_round3_batch2_20261015/job_logs/K2_J5_lr5e-6_d0.5
```

训练结果：

```text
K1: /guohaoran/tmp/nexus_vertex_round3_batch2_20261015/round3_train/K1_J5_lr1e-5_d0.4
K2: /guohaoran/tmp/nexus_vertex_round3_batch2_20261015/round3_train/K2_J5_lr5e-6_d0.5
```

两个日志目录已在服务器创建并核验；训练输出将写入上述对应目录。

环境变量由脚本设置：`PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION=python`、`OMP_NUM_THREADS=8`。GPU 编号沿用平台分配，每任务必须只看到一张卡。

## 恢复与完成

- 崩溃后用完全相同的命令重试一次；存在本任务 `latest.pt` 时自动恢复。第二次失败退出并保留现场。
- 平台失败重试关闭，避免平台和脚本同时重复启动。
- SIGTERM 转发给训练器，等待退出后返回 143。是否保存成功需查看 `status.json/latest.pt`；重启仍用相同命令。
- 完成需满足 `status=complete`、update 4500、`final.pt` 存在，且 raw/EMA 终点评估记录齐全。

## 交给测评 agent 的边界

- 本包保留训练命令原定的最终 raw/EMA 评估。
- Part A 六种步数、十种子扫描、最佳步数选择、K1/K2 的额外 500 树评估、boundary/cascade 分析和 GitHub 测评发布，由测评 agent 执行。
- 本包不添加上述额外评估命令、定时监控或自动上传。
- 模型规模、数据、优化器、clip、精度保持原样。执行设置采用实测配置：`--row-tokens 2816 --chunk-tokens 2816 --checkpoint-activations 0`。详见 `PERFORMANCE_STATUS.md`。
