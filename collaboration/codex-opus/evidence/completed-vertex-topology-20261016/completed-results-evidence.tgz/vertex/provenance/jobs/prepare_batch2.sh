#!/usr/bin/env bash
# CPU-only preparation; does not submit or start training.
set -euo pipefail
ROOT=/guohaoran/tmp/nexus_vertex_round3_batch2_20261015
PY=/guohaoran/envs/nexus-algo/bin/python
COMMIT=e7e3a326a65bc550be695104ae69e0d3435bd446
BRANCH=vertex-dense-overfit50-20261009
CACHE=/guohaoran/tmp/nexus_vertex_round3_20261015/repo
export PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION=python OMP_NUM_THREADS=8 CUDA_VISIBLE_DEVICES=
mkdir -p "$ROOT/audit" "$ROOT/job_logs" "$ROOT/round3_train"
exec 9>"$ROOT/audit/prepare.lock"
flock -n 9 || { echo 'Preparation is already running'; exit 1; }
[[ ! -f "$ROOT/audit/READY.json" ]] || { echo 'Already prepared; inspect READY.json before repeating'; exit 1; }
exec > >(exec 9>&-; exec tee -a "$ROOT/audit/prepare.log") 2>&1
mkdir -p "$ROOT/job_logs/K1_J5_lr1e-5_d0.4" "$ROOT/job_logs/K2_J5_lr5e-6_d0.5"
df -h "$ROOT"
"$PY" - "$ROOT" <<'PY'
import shutil, sys
free = shutil.disk_usage(sys.argv[1]).free
assert free >= 150 * 1024**3, f'Need about 150 GiB free; filesystem reports {free / 1024**3:.1f} GiB'
print('Filesystem free-space check only; this does not establish per-user GPFS quota.')
PY
if [[ ! -d "$ROOT/repo/.git" ]]; then
  [[ ! -e "$ROOT/repo" ]] || { echo 'Existing non-git repo path; refusing overwrite'; exit 1; }
  if [[ -d "$CACHE/.git" ]] && [[ "$(git -C "$CACHE" rev-parse HEAD)" == "$COMMIT" ]]; then
    # Copy Git objects into a NEW independent checkout; never edit the cache.
    git clone --local --no-hardlinks --no-checkout "$CACHE" "$ROOT/repo"
    git -C "$ROOT/repo" remote set-url origin https://github.com/leoguohr/suxen.git
  else
    git clone --depth 1 --filter=blob:none --no-checkout --single-branch --branch "$BRANCH" \
      https://github.com/leoguohr/suxen.git "$ROOT/repo"
    git -C "$ROOT/repo" fetch --depth 1 origin "$COMMIT"
  fi
  git -C "$ROOT/repo" sparse-checkout set vertex/dense_overfit50_20261009
  git -C "$ROOT/repo" checkout --detach "$COMMIT"
fi
[[ "$(git -C "$ROOT/repo" rev-parse HEAD)" == "$COMMIT" ]]
git -C "$ROOT/repo" diff --quiet HEAD
cd "$ROOT/repo/vertex/dense_overfit50_20261009"
"$PY" tests/test_cpu.py | tee "$ROOT/audit/cpu_gate.log"
[[ "$(tail -n 1 "$ROOT/audit/cpu_gate.log")" == 'ALL CPU TESTS PASSED in '* ]]
"$PY" "$ROOT/jobs/verify_init.py" "$ROOT" "$COMMIT"
mv "$ROOT/audit/init_verified.json" "$ROOT/audit/READY.json"
echo 'PREPARATION_COMPLETE: CPU gate and J5 checks passed; training NOT started.'
