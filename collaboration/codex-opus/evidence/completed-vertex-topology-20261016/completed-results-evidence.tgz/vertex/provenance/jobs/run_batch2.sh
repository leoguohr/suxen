#!/usr/bin/env bash
set -euo pipefail
ROOT=/guohaoran/tmp/nexus_vertex_round3_batch2_20261015
CODE="$ROOT/repo/vertex/dense_overfit50_20261009"
PY=/guohaoran/envs/nexus-algo/bin/python
COMMIT=e7e3a326a65bc550be695104ae69e0d3435bd446
INIT=/guohaoran/tmp/nexus_vertex_dense_round2_20261009/runs/J5_token_fine2/final.pt
INIT_SHA=4abd3a09d80bd4ffc6b1557681ef84d2a182b1bf101e429a995e83c959d24f58
case "${1:-}" in
  K1) RUN=K1_J5_lr1e-5_d0.4; EXTRA=(--lr 1e-5 --decay-fraction 0.4) ;;
  K2) RUN=K2_J5_lr5e-6_d0.5; EXTRA=(--lr 5e-6 --decay-fraction 0.5) ;;
  *) echo 'Usage: run_batch2.sh K1|K2 [--print-command]'; exit 2 ;;
esac
shift
[[ $# == 0 || ( $# == 1 && "$1" == --print-command ) ]] || exit 2
OUT="$ROOT/round3_train/$RUN"
LOG="$ROOT/job_logs/$RUN"
CMD=("$PY" -u dense_train.py --init "$INIT" --init-sha "$INIT_SHA" --init-state full
     --loss-weighting token --fine-copies 2 --warmup 20 --max-updates 4500
     --eval-every 0 --final-evals raw,ema --save-minutes 45 --probe-minutes 30 --seed 20261015
     --row-tokens 2816 --chunk-tokens 2816 --checkpoint-activations 0
     "${EXTRA[@]}" --output "$OUT")
if [[ "${1:-}" == --print-command ]]; then
  printf 'cd %q\n' "$CODE"
  printf '%q ' "${CMD[@]}"; printf '\nLog directory: %s\n' "$LOG"
  exit 0
fi
export PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION=python OMP_NUM_THREADS=8 PYTHONUNBUFFERED=1
mkdir -p "$LOG"
exec 9>"$LOG/job.lock"
flock -n 9 || { echo "$RUN already has an active launcher"; exit 1; }
exec > >(exec 9>&-; trap '' TERM INT; exec tee --output-error=exit-nopipe -a "$LOG/console-$(date -u +%Y%m%dT%H%M%SZ)-$$.log") 2>&1
cd "$CODE"
[[ "$(git rev-parse HEAD)" == "$COMMIT" ]]
git diff --quiet HEAD -- .
[[ -f "$ROOT/audit/READY.json" ]] || { echo 'Run prepare_batch2.sh successfully first'; exit 1; }
"$PY" - "$ROOT/audit/READY.json" "$INIT" "$COMMIT" <<'PY'
import json, sys
from pathlib import Path
report = json.loads(Path(sys.argv[1]).read_text())
assert report['commit'] == sys.argv[3] and report['cpu_gate'] == 'passed'
path = Path(sys.argv[2]); saved = report['checkpoints'][str(path)]; current = path.stat()
assert (current.st_size, current.st_mtime_ns) == (saved['bytes'], saved['mtime_ns']), 'Init changed: rerun preparation'
import torch
assert torch.cuda.is_available() and torch.cuda.device_count() == 1, 'Allocate exactly one visible GPU per job'
assert torch.cuda.get_device_properties(0).total_memory >= 75 * 1024**3, 'Requires an 80GB-class GPU'
print('Allocated GPU:', torch.cuda.get_device_name(0), flush=True)
PY
COMMAND=$(printf '%q ' "${CMD[@]}")
if [[ -f "$LOG/command.txt" ]]; then
  [[ "$(cat "$LOG/command.txt")" == "$COMMAND" ]] || { echo 'Command changed: refusing resume'; exit 1; }
else
  printf '%s\n' "$COMMAND" > "$LOG/command.txt"
fi
printf 'Command: %s\nOutput: %s\n' "$COMMAND" "$OUT"
child=''; interrupted=0
forward_signal() { interrupted=1; if [[ -n "$child" ]]; then kill -TERM "$child" 2>/dev/null || true; fi; }
trap forward_signal TERM INT
for attempt in 1 2; do
  echo "START attempt=$attempt UTC=$(date -u +%FT%TZ)"
  "${CMD[@]}" & child=$!
  if wait "$child"; then rc=0; else rc=$?; fi
  if [[ $interrupted == 1 ]]; then
    # The first wait may have been interrupted before the trainer finishes saving.
    while kill -0 "$child" 2>/dev/null; do wait "$child" || true; done
    echo 'Platform termination received; inspect status.json/latest.pt before resuming.'
    exit 143
  fi
  child=''
  echo "EXIT attempt=$attempt rc=$rc UTC=$(date -u +%FT%TZ)"
  if [[ $rc == 0 ]]; then
    "$PY" - "$OUT" <<'PY'
import json, sys
from pathlib import Path
p = Path(sys.argv[1]); status = json.loads((p / 'status.json').read_text())
assert status['state'] == 'complete' and (p / 'final.pt').is_file()
assert status['update'] == 4500, 'Unexpected terminal update for Batch 2'
rows = [json.loads(x) for x in (p / 'evals.jsonl').read_text().splitlines() if x.strip()]
for weights in ('raw', 'ema'):
    assert any(r['update'] == status['update'] and r['weights'] == weights for r in rows)
print('VERIFIED_JOB_COMPLETE', status['update'])
PY
    exit 0
  fi
  [[ $rc == 143 ]] && exit 143
  [[ $attempt == 1 ]] && echo 'Retrying once with the identical command; latest.pt is used when available.'
done
echo 'Second failure; files preserved. No further automatic retry.'
exit "$rc"
