"""Read the trusted J5 checkpoint on CPU, without constructing the model."""
import hashlib
import json
import sys
from pathlib import Path

import torch

root, commit = Path(sys.argv[1]), sys.argv[2]
source = Path('/guohaoran/tmp/nexus_vertex_dense_round2_20261009/runs')
expected = {
    'J5_token_fine2': '4abd3a09d80bd4ffc6b1557681ef84d2a182b1bf101e429a995e83c959d24f58',
}
report = {'commit': commit, 'cpu_gate': 'passed', 'torch': torch.__version__, 'checkpoints': {}}
for name, digest in expected.items():
    path = source / name / 'final.pt'
    before = path.stat()
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(16 << 20), b''):
            h.update(chunk)
    assert h.hexdigest() == digest, f'SHA256 mismatch: {path}'
    state = torch.load(path, map_location='cpu', mmap=True, weights_only=False)
    assert {'model', 'ema', 'optimizer', 'update'} <= state.keys(), f'Incomplete full init: {path}'
    assert state['update'] == 9000
    assert state['model'].keys() == state['ema'].keys()
    optimizer = state['optimizer']
    ids = [i for group in optimizer['param_groups'] for i in group['params']]
    assert ids and len(ids) == len(set(ids)) and set(ids) == set(optimizer['state'])
    assert all({'step', 'exp_avg', 'exp_avg_sq'} <= value.keys() for value in optimizer['state'].values())
    after = path.stat()
    assert (before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns), 'Init changed during inspection'
    report['checkpoints'][str(path)] = {
        'sha256': digest, 'bytes': after.st_size, 'mtime_ns': after.st_mtime_ns,
        'source_update': state['update'], 'keys': sorted(state),
        'model_tensors': len(state['model']), 'ema_tensors': len(state['ema']),
        'optimizer_states': len(optimizer['state']),
        'optimizer_groups': [{k: v for k, v in g.items() if k != 'params'} for g in optimizer['param_groups']],
    }
    print(f'INIT_VERIFIED {name} update=9000 sha256={digest}', flush=True)
    del state, optimizer
(root / 'audit' / 'init_verified.json').write_text(json.dumps(report, indent=2) + '\n')
