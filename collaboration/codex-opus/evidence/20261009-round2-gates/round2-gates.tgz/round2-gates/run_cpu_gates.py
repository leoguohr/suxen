"""Run the two prescribed CPU gates, in order, without repairing failed checks."""
from pathlib import Path
import json
import os
import subprocess
import time

ROOT = Path('/guohaoran/tmp/nexus_vertex_dense_round2_20261009')
CODE = ROOT / 'repo/vertex/dense_overfit50_20261009'
OUT = ROOT / 'gates_31548'
R1 = Path('/guohaoran/tmp/nexus_vertex_dense_overfit50_20261009')
PY = '/guohaoran/envs/nexus-algo/bin/python'


def main():
    env = os.environ.copy()
    env.update(CUDA_VISIBLE_DEVICES='', PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION='python', OMP_NUM_THREADS='8')
    env.pop('NEXUS_SKIP_COARSE_PROBES', None)
    record = {'scope': 'steps 1-4 only; long J1/J2 submission explicitly deferred by user',
              'state': 'running', 'code_commit': 'c00ebcc984ed354609c7a9e539252402e5329ef3',
              'environment': {k: env[k] for k in ['CUDA_VISIBLE_DEVICES', 'PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION', 'OMP_NUM_THREADS']},
              'steps': []}
    def save():
        p = OUT / 'cpu_gates.json'
        t = p.with_suffix('.tmp')
        t.write_text(json.dumps(record, indent=2) + '\n')
        t.replace(p)
    def run(name, command):
        row = {'name': name, 'command': command, 'cwd': str(CODE), 'started_unix': time.time()}
        record['steps'].append(row)
        save()
        with (OUT / (name + '.log')).open('x') as log:
            process = subprocess.Popen(command, cwd=CODE, env=env, stdout=subprocess.PIPE,
                                       stderr=subprocess.STDOUT, text=True, bufsize=1)
            for line in process.stdout:
                log.write(line)
                log.flush()
                print(line, end='', flush=True)
            row.update(return_code=process.wait(), ended_unix=time.time())
        save()
        if row['return_code'] != 0:
            raise RuntimeError(f'{name} failed with exit {row["return_code"]}; no later gate executed')
    try:
        run('round1_margins', [PY, '-u', 'analyze_margins.py', '--eval-dir', str(R1 / 'A/eval_raw'),
            '--eval-dir', str(R1 / 'D/eval_raw'), '--eval-dir', str(R1 / 'D/eval_ema'),
            '--eval-dir', str(R1 / 'B/eval_raw'), '--output', str(OUT / 'round1_margins.json')])
        margins = json.loads((OUT / 'round1_margins.json').read_text())
        assert len(margins) == 4
        assert [r['trees'] for r in margins] == [100] * 4
        assert [r['exact_trees'] for r in margins] == [35, 26, 28, 18]
        record['margin_cohort_verified'] = True
        save()
        run('test_cpu', [PY, '-u', 'tests/test_cpu.py'])
        assert 'ALL CPU TESTS PASSED' in (OUT / 'test_cpu.log').read_text()
        record['state'] = 'cpu_gates_passed'
        save()
        print('ROUND2_CPU_GATES_PASSED', flush=True)
    except Exception as error:
        record.update(state='failed_stopped', error=repr(error))
        save()
        print('ROUND2_STOPPED', repr(error), flush=True)
        raise


if __name__ == '__main__':
    main()
