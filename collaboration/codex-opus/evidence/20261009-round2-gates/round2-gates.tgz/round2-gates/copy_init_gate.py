"""Copy persistent A checkpoint to an explicitly ephemeral overlay cache; verify both hashes."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

SOURCE = Path('/guohaoran/tmp/nexus_vertex_dense_overfit50_20261009/A/final.pt')
DEST = Path('/ssd/guohaoran/nexus_vertex_dense_round2_20261009/A-final.pt')
RECEIPT = Path('/guohaoran/tmp/nexus_vertex_dense_round2_20261009/gates_31548/init_copy.json')
EXPECTED = '1bd4ced48296b45c80d54386171652a6f9eb9c09e8fc976965caad62899b55f9'
BLOCK = 16 << 20


def fingerprint(path):
    stat = path.stat()
    return [stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns]


def main():
    assert not RECEIPT.exists(), 'preserve existing copy-gate evidence'
    RECEIPT.parent.mkdir(parents=True, exist_ok=True)
    record = {'state': 'running', 'source': str(SOURCE), 'destination': str(DEST),
              'expected_sha256': EXPECTED, 'started_unix': time.time(),
              'destination_role': 'ephemeral overlay fast cache; /ssd is a created directory, not a persistent SSD mount',
              'source_role': 'persistent original; copied read-only and retained',
              'content_metadata_validation': 'performed separately by the caller; this helper verifies byte identity only',
              'timebase': 'server Unix timestamps; durations from monotonic clock'}

    def persist():
        temporary = RECEIPT.with_name(RECEIPT.name + '.tmp')
        with temporary.open('w') as stream:
            json.dump(record, stream, indent=2)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, RECEIPT)

    started = time.monotonic()
    persist()
    try:
        assert SOURCE.is_file() and not DEST.exists(), 'source must exist and destination must be new'
        DEST.parent.mkdir(parents=True, exist_ok=True)
        before = fingerprint(SOURCE)
        record.update(source_identity=before, expected_bytes=before[2],
                      filesystem=subprocess.check_output(['df', '-PT', str(SOURCE), str(DEST.parent)], text=True))
        partial = DEST.with_name(DEST.name + '.partial')
        assert not partial.exists(), 'preserve prior partial file; no implicit retry or deletion'
        digest, copied, last_report = hashlib.sha256(), 0, time.monotonic()
        with SOURCE.open('rb') as incoming, partial.open('xb') as outgoing:
            for block in iter(lambda: incoming.read(BLOCK), b''):
                outgoing.write(block)
                digest.update(block)
                copied += len(block)
                if time.monotonic() - last_report >= 10:
                    record.update(phase='copying', copied_bytes=copied)
                    persist()
                    print('COPY_PROGRESS', copied, before[2], flush=True)
                    last_report = time.monotonic()
            outgoing.flush()
            os.fsync(outgoing.fileno())
        record.update(source_stream_sha256=digest.hexdigest(), bytes=copied, copy_seconds=time.monotonic() - started)
        assert copied == before[2] and fingerprint(SOURCE) == before, 'source changed during copy'
        assert digest.hexdigest() == EXPECTED, 'persistent source SHA256 mismatch; cache not promoted'
        os.replace(partial, DEST)
        directory = os.open(DEST.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
        record.update(phase='readback')
        persist()
        verify_started = time.monotonic()
        checked, digest = 0, hashlib.sha256()
        with DEST.open('rb') as incoming:
            for block in iter(lambda: incoming.read(BLOCK), b''):
                digest.update(block)
                checked += len(block)
        record.update(destination_readback_sha256=digest.hexdigest(), destination_bytes=checked,
                      readback_seconds=time.monotonic() - verify_started)
        assert checked == copied and digest.hexdigest() == EXPECTED, 'cache SHA256 readback mismatch'
        assert fingerprint(SOURCE) == before, 'persistent source changed during cache verification'
        record.update(state='completed', phase='verified', destination_readback_verified=True,
                      source_preserved=True, ended_unix=time.time(), total_seconds=time.monotonic() - started)
        persist()
        print('INIT_COPY_GATE_COMPLETED', json.dumps(record), flush=True)
    except Exception as error:
        record.update(state='failed', error=repr(error), ended_unix=time.time(), total_seconds=time.monotonic() - started)
        persist()
        print('INIT_COPY_GATE_FAILED', repr(error), flush=True)
        raise


if __name__ == '__main__':
    main()
