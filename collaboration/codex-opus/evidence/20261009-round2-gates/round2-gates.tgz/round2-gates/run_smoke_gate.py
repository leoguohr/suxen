"""External interrupt/resume smoke gate; launch only after preceding gates pass."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import signal
import subprocess
import time

PY = '/guohaoran/envs/nexus-algo/bin/python'


def fingerprint(path):
    stat = path.stat()
    return {'bytes': stat.st_size, 'inode': stat.st_ino, 'mtime_ns': stat.st_mtime_ns}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--code', type=Path, required=True)
    parser.add_argument('--init', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--gpu', default=os.environ.get('CUDA_VISIBLE_DEVICES'))
    args = parser.parse_args()
    code, init, output = args.code.resolve(), args.init.resolve(), args.output.resolve()
    smoke, receipt = output / 'smoke', output / 'smoke_gate.json'
    assert code.is_dir() and init.is_file()
    assert args.gpu and args.gpu.startswith('GPU-') and ',' not in args.gpu, 'supply one GPU UUID'
    assert not smoke.exists() and not receipt.exists(), 'smoke output must be new; no deletion or restart'
    assert all(not (output / f'smoke_attempt_{n}.{suffix}').exists()
               for n in (1, 2, 3) for suffix in ('log', 'json'))
    output.mkdir(parents=True, exist_ok=True)
    trainer = code / 'dense_train.py'
    code_hash = hashlib.sha256(trainer.read_bytes()).hexdigest()
    command = [PY, '-u', 'dense_train.py', '--init', str(init), '--init-sha', 'skip',
               '--init-state', 'full', '--lr', '1e-5', '--warmup', '2', '--loss-weighting', 'token',
               '--max-updates', '4', '--decay-fraction', '0.5', '--eval-every', '2', '--eval-steps', '2',
               '--final-evals', 'raw', '--probe-minutes', '0', '--save-minutes', '1000', '--seed', '1',
               '--output', str(smoke)]
    env = os.environ.copy()
    env.update(PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION='python', OMP_NUM_THREADS='8', CUDA_VISIBLE_DEVICES=args.gpu)
    env.pop('NEXUS_SKIP_COARSE_PROBES', None)
    metadata = {'state': 'running', 'command': command, 'shell_command': shlex.join(command),
                'cwd': str(code), 'trainer_sha256': code_hash, 'init': str(init), 'init_bytes': init.stat().st_size,
                'environment': {key: env[key] for key in ('PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION',
                                                         'OMP_NUM_THREADS', 'CUDA_VISIBLE_DEVICES')},
                'unset_environment': ['NEXUS_SKIP_COARSE_PROBES'], 'attempts': [], 'started_unix': time.time()}

    def write_json(path, value):
        temporary = path.with_name(path.name + '.tmp')
        temporary.write_text(json.dumps(value, indent=2) + '\n')
        temporary.replace(path)

    def persist():
        write_json(receipt, metadata)

    def attempt(number, interrupt=False):
        assert hashlib.sha256(trainer.read_bytes()).hexdigest() == code_hash, 'trainer changed between attempts'
        row = {'attempt': number, 'start_unix': time.time(), 'command': command,
               'environment': metadata['environment'], 'unset_environment': metadata['unset_environment'],
               'trainer_sha256': code_hash, 'signal_sent': False}
        metadata['attempts'].append(row)
        write_json(output / f'smoke_attempt_{number}.json', row)
        persist()
        log = output / f'smoke_attempt_{number}.log'
        with log.open('x') as stream:
            process = subprocess.Popen(command, cwd=code, env=env, stdout=subprocess.PIPE,
                                       stderr=subprocess.STDOUT, text=True, bufsize=1, start_new_session=True)
            row.update(pid=process.pid, state='running', log=str(log))
            persist()
            try:
                for line in process.stdout:
                    if interrupt and not row['signal_sent'] and re.match(r'^u3\s', line):
                        process.send_signal(signal.SIGTERM)
                        row.update(signal_sent=True, signal_target_pid=process.pid, signal_unix=time.time(),
                                   signal_trigger=line.rstrip())
                        persist()
                    stream.write(line)
                    stream.flush()
                    print(line, end='', flush=True)
                row.update(return_code=process.wait(), end_unix=time.time(), state='exited')
            except BaseException:
                if process.poll() is None and not row['signal_sent']:
                    process.send_signal(signal.SIGTERM)
                raise
            finally:
                process.stdout.close()
        write_json(output / f'smoke_attempt_{number}.json', row)
        persist()
        return row, log.read_text()

    persist()
    try:
        first, text = attempt(1, interrupt=True)
        interrupted = re.search(r'^INTERRUPTED at update (\d+)\b', text, re.MULTILINE)
        assert first['signal_sent'] and first['return_code'] == 143 and interrupted, 'first attempt must interrupt with rc143'
        update = int(interrupted.group(1))
        assert update in (3, 4), f'unexpected interrupted update {update}'
        status = json.loads((smoke / 'status.json').read_text())
        assert status['state'] == 'interrupted' and status['update'] == update
        assert (smoke / 'latest.pt').is_file() and (smoke / 'latest.pt').stat().st_size > 0
        metadata['interrupted_update'] = update
        persist()
        second, text = attempt(2)
        resumed = re.search(r'^RESUMED .* at update (\d+)\b', text, re.MULTILINE)
        assert second['return_code'] == 0 and resumed and int(resumed.group(1)) == update, 'second attempt must resume at interrupted update'
        assert re.search(r'^JOB_COMPLETE updates=4\b', text, re.MULTILINE), 'second attempt must complete update4'
        final = smoke / 'final.pt'
        assert final.is_file() and final.stat().st_size > 0
        final_stat = fingerprint(final)
        rows = [json.loads(line) for line in (smoke / 'evals.jsonl').read_text().splitlines() if line]
        assert len(rows) == 2 and {(r['update'], r['weights']) for r in rows} == {(2, 'raw'), (4, 'raw')}
        summaries = {}
        for milestone in (2, 4):
            path = smoke / 'evals' / f'u{milestone:06d}_raw' / 'summary.json'
            summary = json.loads(path.read_text())
            assert summary['trees'] == 100, f'{path}: expected100trees'
            summaries[str(milestone)] = {'path': str(path), 'trees': summary['trees'],
                                         'full_trees_exact': summary['full_trees_exact']}
        status = json.loads((smoke / 'status.json').read_text())
        assert status['state'] == 'complete' and status['update'] == 4
        third, text = attempt(3)
        assert third['return_code'] == 0 and re.search(r'^ALREADY_COMPLETE\s', text, re.MULTILINE), 'third attempt must be a no-op'
        assert fingerprint(final) == final_stat, 'third attempt changed final.pt'
        metadata.update(state='completed', ended_unix=time.time(), final=str(final), final_stat=final_stat,
                        evaluations=summaries, eval_rows=rows)
        persist()
        print('SMOKE_GATE_COMPLETED', str(receipt), flush=True)
    except Exception as error:
        metadata.update(state='failed', ended_unix=time.time(), error=repr(error))
        persist()
        print('SMOKE_GATE_FAILED', repr(error), flush=True)
        raise


if __name__ == '__main__':
    main()
