#!/usr/bin/env bash
set -euo pipefail
ROOT=/guohaoran/tmp/nexus_vertex_dense_round2_20261009
CODE="$ROOT/repo/vertex/dense_overfit50_20261009"
PY=/guohaoran/envs/nexus-algo/bin/python
SOURCE=/guohaoran/tmp/nexus_vertex_dense_overfit50_20261009/A/final.pt
SHA=1bd4ced48296b45c80d54386171652a6f9eb9c09e8fc976965caad62899b55f9
case "${1:-}" in
  J1) RUN=J1_item; WEIGHT=item ;;
  J2) RUN=J2_token; WEIGHT=token ;;
  J3) RUN=J3_token_lr5e-6; WEIGHT=token ;;
  J4) RUN=J4_token_copies8; WEIGHT=token ;;
  *) echo 'Expected J1, J2, J3 or J4'; exit 2 ;;
esac
shift
[[ $# == 0 || ( $# == 1 && "$1" == --check-only ) ]] || exit 2
LOG="$ROOT/job_logs/$RUN"
OUT="$ROOT/runs/$RUN"
INIT="/ssd/guohaoran/nexus_vertex_dense_round2_20261009/$RUN/A-final.pt"
mkdir -p "$LOG"
exec 9>"$LOG/.job.lock"
flock -n 9 || { echo "$RUN is already running"; exit 1; }
CONSOLE="$LOG/console-$(date -u +%Y%m%dT%H%M%SZ)-$$.log"
exec > >(trap '' TERM INT; exec tee -a "$CONSOLE") 2>&1
ln -sfn "$(basename "$CONSOLE")" "$LOG/console-latest.log"
export PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION=python OMP_NUM_THREADS=8 PYTHONUNBUFFERED=1
unset NEXUS_SKIP_COARSE_PROBES
cd "$CODE"
[[ "$(git rev-parse HEAD)" == c00ebcc984ed354609c7a9e539252402e5329ef3 ]]
git diff --exit-code HEAD -- .
"$PY" - <<'PY'
import json, os, sys
import numpy, scipy, torch
assert sys.version_info[:2] == (3, 10), sys.version
assert torch.__version__ == '2.3.0a0+6ddf5cf85e.nv24.04', torch.__version__
assert torch.version.cuda == '12.4', torch.version.cuda
assert numpy.__version__ == '1.24.4' and scipy.__version__ == '1.12.0'
print(json.dumps({'python': sys.version, 'torch': torch.__version__, 'cuda': torch.version.cuda,
                  'numpy': numpy.__version__, 'scipy': scipy.__version__,
                  'CUDA_VISIBLE_DEVICES': os.environ.get('CUDA_VISIBLE_DEVICES'),
                  'hostname': os.uname().nodename}))
PY
CMD=("$PY" -u dense_train.py --init "$INIT" --init-sha "$SHA" --init-state full
     --lr 1e-5 --warmup 20 --max-updates 9000 --decay-fraction 0.2
     --eval-every 1800 --final-evals raw,ema --save-minutes 45 --probe-minutes 30
     --seed 20261010 --loss-weighting "$WEIGHT" --output "$OUT")
case "$RUN" in
  J3_token_lr5e-6) CMD+=(--lr 5e-6) ;;
  J4_token_copies8) CMD+=(--coarse-copies 8) ;;
esac
printf 'Exact trainer command:'
printf ' %q' "${CMD[@]}"
printf '\nPersistent output: %s\nConsole: %s\n' "$OUT" "$CONSOLE"
if [[ "${1:-}" == --check-only ]]; then
  [[ -f "$SOURCE" ]]
  echo 'CHECK_ONLY_COMPLETE: no checkpoint copy, GPU work, or training started'
  exit 0
fi
"$PY" - <<'PY'
import torch
assert torch.cuda.is_available() and torch.cuda.device_count() == 1, 'Allocate exactly ONE visible GPU per task'
assert torch.cuda.get_device_properties(0).total_memory >= 75 * 1024**3, 'This protocol requires an 80GB-class GPU'
print('Allocated GPU:', torch.cuda.get_device_name(0))
PY
"$PY" - "$OUT" <<'PY'
import json, sys
from pathlib import Path
p = Path(sys.argv[1])
status = json.loads((p / 'status.json').read_text()) if (p / 'status.json').exists() else {}
if (p / 'final.pt').exists() and not (p / 'latest.pt').exists():
    assert status.get('state') == 'complete', 'Final checkpoint exists but completion was not recorded; stop for inspection, do not restart training'
if status.get('state') == 'complete':
    assert (p / 'final.pt').is_file(), 'Completed status without final checkpoint; stop for inspection'
PY
# This cache is recreated on a new container. All authoritative outputs remain on /guohaoran.
if [[ ! -f "$OUT/latest.pt" && ! -f "$OUT/final.pt" ]]; then
  mkdir -p "$(dirname "$INIT")"
  if [[ ! -f "$INIT" ]]; then
    PARTIAL="$INIT.partial.$$"
    cp "$SOURCE" "$PARTIAL"
    printf '%s  %s\n' "$SHA" "$PARTIAL" | sha256sum -c -
    mv "$PARTIAL" "$INIT"
    printf 'Verified fast init cache: %s\n' "$INIT"
  fi
fi
# Foreground exec preserves the trainer PID, SIGTERM handling and exit status (143/0/error).
# A platform restart must run this same script; failures are never retried in a tight loop.
exec "${CMD[@]}"
