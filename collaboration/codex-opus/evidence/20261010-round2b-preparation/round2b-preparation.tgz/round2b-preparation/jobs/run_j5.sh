#!/usr/bin/env bash
set -euo pipefail
exec bash /guohaoran/tmp/nexus_vertex_dense_round2_20261009/jobs/run_round2b.sh J5 "$@"
