"""Run the prescribed Round2b CPU test or one disposable GPU preflight."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/guohaoran/tmp/nexus_vertex_dense_round2_20261009')
CODE = ROOT / 'repo_round2b/vertex/dense_overfit50_20261009'
OUT = ROOT / 'round2b_gates_20261010'
PY = '/guohaoran/envs/nexus-algo/bin/python'
INIT = Path('/ssd/guohaoran/nexus_vertex_dense_round2_20261009/A-final.pt')
SHA = '1bd4ced48296b45c80d54386171652a6f9eb9c09e8fc976965caad62899b55f9'
COMMIT = '2108acb08c6d5ca1e43c67da2159213f0d36080f'


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--kind', choices=['cpu', 'J5', 'J6'], required=True)
    p.add_argument('--gpu')
    args = p.parse_args()
    folder = OUT if args.kind == 'cpu' else OUT / args.kind
    folder.mkdir(parents=True, exist_ok=True)
    status_path = folder / ('cpu_status.json' if args.kind == 'cpu' else 'gate_status.json')
    assert not status_path.exists(), 'Keep previous gate evidence; do not overwrite or auto-retry'
    started = time.monotonic()
    record = {'kind': args.kind, 'state': 'preparing', 'started_unix': time.time(),
              'hostname': os.uname().nodename, 'gpu_uuid': args.gpu,
              'scope': 'prescribed disposable preflight; no formal job submission'}

    def save():
        temp = status_path.with_suffix('.tmp')
        temp.write_text(json.dumps(record, indent=2) + '\n')
        temp.replace(status_path)

    save()
    try:
        head = subprocess.check_output(['git', '-C', str(CODE), 'rev-parse', 'HEAD'], text=True).strip()
        assert head == COMMIT
        subprocess.run(['git', '-C', str(CODE), 'diff', '--exit-code', 'HEAD', '--', '.'], check=True)
        record['commit'] = head
        record['code_sha256'] = {name: hashlib.sha256((CODE / name).read_bytes()).hexdigest()
                                 for name in ['dense_train.py', 'common.py', 'tests/test_cpu.py', 'analyze_cascade.py']}
        env = os.environ.copy()
        env.update(PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION='python', OMP_NUM_THREADS='8',
                   PYTHONUNBUFFERED='1', CUDA_VISIBLE_DEVICES='' if args.kind == 'cpu' else args.gpu or '')
        env.pop('NEXUS_SKIP_COARSE_PROBES', None)
        if args.kind == 'cpu':
            command = [PY, '-u', 'tests/test_cpu.py']
            log = folder / 'cpu.log'
            marker = 'ALL CPU TESTS PASSED'
        else:
            assert json.loads((OUT / 'cpu_status.json').read_text())['state'] == 'passed'
            assert args.gpu
            active = subprocess.check_output(['nvidia-smi', '-i', args.gpu,
                        '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
            assert not active, 'The allocated preflight GPU must be idle'
            record['state'] = 'checking_init_sha256'
            save()
            digest = hashlib.sha256()
            with INIT.open('rb') as stream:
                for block in iter(lambda: stream.read(16 << 20), b''):
                    digest.update(block)
            assert digest.hexdigest() == SHA
            record['init_sha256'] = digest.hexdigest()
            record['init_bytes'] = INIT.stat().st_size
            extra = ['--fine-copies', '2'] if args.kind == 'J5' else ['--parent-drop', '0.1', '--parent-add', '0.1']
            command = [PY, '-u', 'dense_train.py', '--init', str(INIT), '--init-sha', 'skip',
                       '--init-state', 'full', '--lr', '1e-5', '--loss-weighting', 'token',
                       *extra, '--preflight', '--output', str(folder / 'preflight')]
            log = folder / 'preflight.log'
            marker = 'PREFLIGHT_OK'
        record.update(state='running', command=command, log=str(log), cwd=str(CODE))
        save()
        print('GATE_STARTED', args.kind, flush=True)
        run_started = time.monotonic()
        with log.open('x') as stream:
            result = subprocess.run(command, cwd=CODE, env=env, stdout=stream,
                                    stderr=subprocess.STDOUT, timeout=1800)
        record.update(return_code=result.returncode, command_seconds=time.monotonic() - run_started)
        assert result.returncode == 0, f'{args.kind} failed, see {log}'
        assert marker in log.read_text(), f'Missing required success marker: {marker}'
        if args.kind != 'cpu':
            rows = [json.loads(line) for line in (folder / 'preflight/preflight.jsonl').read_text().splitlines()]
            updates = [row for row in rows if 'loss' in row]
            assert len(updates) == 3
            assert all(math.isfinite(row[k]) for row in updates for k in ['loss', 'grad_norm', 'seconds', 'peak_gib'])
            record['update_seconds'] = [row['seconds'] for row in updates]
            record['peak_allocated_gib'] = max(row['peak_gib'] for row in updates)
            record['measurement_scope'] = 'Three largest-eight-object preflight updates; prescribed defaults, not formal steady-state speed; trainer sync is before EMA'
        record.update(state='passed', ended_unix=time.time(), total_seconds=time.monotonic() - started)
        save()
        print('GATE_PASSED', args.kind, json.dumps(record), flush=True)
    except Exception as error:
        record.update(state='failed_stopped', error=repr(error), ended_unix=time.time(),
                      total_seconds=time.monotonic() - started)
        save()
        raise


if __name__ == '__main__':
    main()
