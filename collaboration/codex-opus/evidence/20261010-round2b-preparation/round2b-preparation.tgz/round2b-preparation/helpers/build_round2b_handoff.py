"""Package Round2b gates and small saved job records on the server only."""
from collections import deque
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import math
import re
import subprocess
import tarfile

ROOT = Path('/guohaoran/tmp/nexus_vertex_dense_round2_20261009')
GATES = ROOT / 'round2b_gates_20261010'
OUT = ROOT / 'opus_round2b_handoff_20261010'
CODE = ROOT / 'repo_round2b/vertex/dense_overfit50_20261009'
COMMIT = '2108acb08c6d5ca1e43c67da2159213f0d36080f'
NAME = 'round2b-preparation'
MESSAGE = '20261010-007-codex-round2b-preparation.md'
RUNS = {'J1': 'J1_item', 'J2': 'J2_token', 'J3': 'J3_token_lr5e-6',
        'J4': 'J4_token_copies8', 'J5': 'J5_token_fine2', 'J6': 'J6_token_selfcorrect'}
FORBIDDEN = re.compile(rb'gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|Authorization:\s*(?:Bearer|Basic)\s+[A-Za-z0-9+/=]{16,}')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text()) if path.is_file() else {}


def main():
    stage = OUT / NAME
    stage.mkdir(parents=True, exist_ok=False)

    def put(name, data):
        path = stage / name
        assert path.suffix not in {'.pt', '.npz'} and 'predictions' not in path.parts
        raw = data if isinstance(data, bytes) else (data if isinstance(data, str) else json.dumps(data, indent=2) + '\n').encode()
        assert not FORBIDDEN.search(raw), 'Secret pattern in ' + name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)

    def copy(source, name):
        assert source.is_file() and not source.is_symlink(), str(source)
        assert source.stat().st_size <= 16 << 20, 'Unexpected large evidence file: ' + str(source)
        raw = source.read_bytes()
        put(name, raw)
        return {'bytes': len(raw), 'sha256': sha(raw), 'mtime_unix': source.stat().st_mtime}

    def lines(source, name, count=None):
        saved = deque(maxlen=count)
        partial = False
        with source.open('rb') as stream:
            for line in stream:
                if line.endswith(b'\n'):
                    json.loads(line)
                    saved.append(line)
                else:
                    partial = True
        raw = b''.join(saved)
        put(name, raw)
        return {'lines': len(saved), 'sha256': sha(raw), 'incomplete_last_line_omitted': partial,
                'last_row': json.loads(saved[-1]) if saved else None}

    identity = {'commit': subprocess.check_output(['git', '-C', str(CODE), 'rev-parse', 'HEAD'], text=True).strip(),
                'tracked_code_clean': subprocess.run(['git', '-C', str(CODE), 'diff', '--quiet', 'HEAD', '--', '.']).returncode == 0,
                'trainer_sha256': sha((CODE / 'dense_train.py').read_bytes())}
    assert identity['commit'] == COMMIT and identity['tracked_code_clean']
    put('source_identity.json', identity)
    for name in ('ROUND2.md', 'CODEX_PROMPT_ROUND2B.md'):
        copy(CODE / name, 'approved/' + name)
    for name in ('run_round2.sh', 'run_round2b.sh') + tuple('run_' + job.lower() + '.sh' for job in RUNS):
        copy(ROOT / 'jobs' / name, 'jobs/' + name)
    for name in ('build_round2b_handoff.py', 'publish_round2b_handoff.py'):
        if (ROOT / name).is_file():
            copy(ROOT / name, 'helpers/' + name)
    copy(ROOT / 'run_round2b_gate.py', 'helpers/run_round2b_gate.py')
    assert GATES.is_dir(), 'No Round2b gate evidence directory'
    for source in sorted(GATES.rglob('*')):
        if source.is_file() and source.suffix in {'.json', '.jsonl', '.log', '.txt', '.py', '.sh'} and 'predictions' not in source.parts:
            copy(source, 'gates/' + str(source.relative_to(GATES)))
    gate_results = {}
    for job in ('CPU', 'J5', 'J6'):
        folder = GATES if job == 'CPU' else GATES / job
        receipt = read(folder / ('cpu_status.json' if job == 'CPU' else 'gate_status.json'))
        assert not receipt or receipt.get('state') in {'passed', 'completed', 'failed', 'failed_stopped'}, 'Gate not terminal: ' + job
        log = folder / ('cpu.log' if job == 'CPU' else 'preflight.log')
        raw = log.read_bytes() if log.is_file() else b''
        marker = b'ALL CPU TESTS PASSED' if job == 'CPU' else b'PREFLIGHT_OK'
        code = receipt.get('return_code', receipt.get('rc'))
        row = {'receipt': receipt, 'log_present': log.is_file(), 'success_marker_observed': marker in raw,
               'return_code': code, 'passed_from_receipts': receipt.get('state') in {'passed', 'completed'} and code == 0 and marker in raw}
        if job != 'CPU':
            row['preflight_config'] = read(folder / 'preflight/config.json')
            path = folder / 'preflight/preflight.jsonl'
            saved_lines = path.read_bytes().splitlines(keepends=True) if path.is_file() else []
            row['incomplete_preflight_line_omitted'] = any(not line.endswith(b'\n') for line in saved_lines)
            updates = [json.loads(line) for line in saved_lines if line.endswith(b'\n') and line.strip()]
            updates = [entry for entry in updates if 'loss' in entry]
            finite = len(updates) == 3 and all(math.isfinite(entry[key]) for entry in updates for key in ('loss', 'grad_norm', 'seconds', 'peak_gib'))
            row.update(update_rows=updates, three_finite_updates=finite,
                       peak_allocated_gib=max((entry['peak_gib'] for entry in updates), default=None))
            row['passed_from_receipts'] = row['passed_from_receipts'] and finite
        gate_results[job] = row

    snapshots = {}
    for job, run in RUNS.items():
        folder = ROOT / 'runs' / run
        record = {'run': run, 'directory_exists': folder.is_dir(), 'files': {},
                  'scope': 'Saved file snapshot; no check of the formal pod live process.', 'evaluations': [], 'cascade_outputs': []}
        for source in sorted(folder.glob('config*.json')) + [folder / 'status.json']:
            if source.is_file():
                record['files'][source.name] = copy(source, 'snapshots/' + run + '/' + source.name)
                if source.name == 'status.json':
                    record['recorded_status'] = read(stage / 'snapshots' / run / source.name)
        for original, target, count in (('train.jsonl', 'train_last10.jsonl', 10),
                                        ('probes.jsonl', 'probes_tail.jsonl', 10), ('evals.jsonl', 'evals.jsonl', None)):
            if (folder / original).is_file():
                record['files'][target] = lines(folder / original, 'snapshots/' + run + '/' + target, count)
        for evaluation in sorted((folder / 'evals').glob('*')):
            if not evaluation.is_dir():
                continue
            summary = read(evaluation / 'summary.json')
            record['evaluations'].append({'directory': evaluation.name, 'summary_present': bool(summary),
                                          'recorded_trees': summary.get('trees'), 'recorded_full_trees_exact': summary.get('full_trees_exact')})
            for source in sorted(evaluation.glob('*.json')):
                copy(source, 'snapshots/' + run + '/evals/' + evaluation.name + '/' + source.name)
            if job == 'J6' and summary.get('trees') == 100:
                for source in sorted(evaluation.glob('*cascade*')):
                    if source.is_file() and source.suffix in {'.json', '.log', '.txt'}:
                        copy(source, 'snapshots/' + run + '/evals/' + evaluation.name + '/' + source.name)
                        record['cascade_outputs'].append(str(source.relative_to(folder)))
        if job == 'J6':
            for source in sorted(folder.glob('*cascade*')):
                if source.is_file() and source.suffix in {'.json', '.log', '.txt'}:
                    copy(source, 'snapshots/' + run + '/' + source.name)
                    record['cascade_outputs'].append(source.name)
        record['formal_output_records_observed'] = bool(record['files'])
        snapshots[job] = record

    limits = ['J5/J6 are prepared for a later user launch; this preparation workflow submits no formal jobs.',
              'J1-J4 keep their c00ebcc shared wrapper. J5/J6 use isolated repo_round2b pinned to 2108acb.',
              'Formal J5 adds only --fine-copies 2; J6 adds only --parent-drop 0.1 --parent-add 0.1 to J2 COMMON.',
              'Prescribed preflights omit formal schedule flags: defaults seed20261009, warmup50, max-updates1e9, decay0; formal uses seed20261010, warmup20, max-updates9000, decay0.2.',
              'Preflight synchronizes before EMA.update, not after it. Recorded seconds are preflight timings, not fully synchronized train+EMA speed estimates.',
              'Three largest-object updates do not guarantee 9000-update memory peaks, total runtime or completion ETA.',
              'J6 samples a per-item drop probability uniformly in [0,0.1], then Bernoulli-drops parents; realized dropped fraction can exceed 0.1, with at least one kept.',
              'J6 requested spurious-parent count is rounded U[0,0.1]*original-count; bounds, uniqueness and GT filtering can reduce the actual additions.',
              'J6 teaches extra parents to predict no children. Inference is unchanged and cannot recreate a true branch once its parent is absent.',
              'J6 consumes additional RNG draws and changes item shapes. The common seed pairs object order, not actual J2/J6 noise tensors.',
              'Job records are snapshots of saved files, possibly partial or duplicated after resume; they do not prove a current live pod process.',
              'Existing cascade outputs are packaged when present; this builder runs no analysis.',
              'Reporting is configured: active automation nexus-round2 discovers new completed milestones hourly from small saved files for all six jobs, publishes only new completed milestones and J6 CPU cascade analysis, and stays quiet when unchanged. It reports expired SSH access; it performs no continuous GPU monitoring or training changes.']
    result = {'collected_server_utc': datetime.now(timezone.utc).isoformat(), 'source': identity,
              'gates': gate_results, 'all_preparation_gates_passed': all(row['passed_from_receipts'] for row in gate_results.values()),
              'snapshots': snapshots, 'formal_jobs_submitted_by_this_workflow': False,
              'milestone_reporting': {'automation_id': 'nexus-round2', 'state': 'ACTIVE', 'interval': 'hourly',
                  'scope': 'Discover newly completed milestones from six jobs small saved files; publish new evidence and J6 CPU cascade analysis; quiet when unchanged.',
                  'continuous_gpu_monitoring': False, 'training_changes': False,
                  'evidence': 'Coordinator confirmed successful Codex app automation creation.'}, 'limits': limits}
    put('RESULT.json', result)
    message = ['# Codex → Opus: Round2b preparation', '',
               '**J5/J6 are prepared and awaiting the later launch instruction. This workflow has submitted neither job.**', '',
               f'Approved commit: `{COMMIT}`. All preparation gates passed from recorded evidence: `{result["all_preparation_gates_passed"]}`.', '',
               '| Gate | Recorded state | Exit | Success marker | Finite updates | Peak allocated GiB |',
               '|---|---|---:|---|---:|---:|']
    for job, row in gate_results.items():
        message.append(f"| {job} | {row['receipt'].get('state', 'missing')} | {row['return_code']} | {row['success_marker_observed']} | {len(row.get('update_rows', [])) if job != 'CPU' else 'n/a'} | {row.get('peak_allocated_gib', 'n/a')} |")
    message += ['', 'Exact gate commands, environment/identity receipts, elapsed time, exit codes and preflight rows are in the compressed evidence. Failed or absent gates are not treated as passes.', '',
                '| Job | Saved state | Last train-tail update | Evaluation directories observed |',
                '|---|---|---:|---:|']
    for job, record in snapshots.items():
        last = record['files'].get('train_last10.jsonl', {}).get('last_row') or {}
        message.append(f"| {job} | {record.get('recorded_status', {}).get('state', 'unavailable')} | {last.get('update', 'unavailable')} | {len(record['evaluations'])} |")
    message += ['', '## Boundaries and next action', ''] + ['- ' + note for note in limits]
    message += ['', 'After the later authorized launch, report submission identity. Hourly milestone discovery is configured as active automation `nexus-round2`: publish newly completed milestones and J6 CPU cascade results, staying quiet when saved evidence is unchanged.', '',
                'No `.pt`, `.npz`, predictions or credentials are included. Server originals remain in `/guohaoran`; upload transit uses memory only.', '',
                '[Compressed preparation evidence](../evidence/20261010-round2b-preparation/README.md)', '']
    text = '\n'.join(message)
    put('REPORT.md', text)
    (OUT / MESSAGE).write_text(text)
    paths = sorted(path for path in stage.rglob('*') if path.is_file())
    put('SHA256SUMS', ''.join(f'{sha(path.read_bytes())}  {path.relative_to(stage)}\n' for path in paths))
    archive = OUT / (NAME + '.tgz')
    with tarfile.open(archive, 'w:gz') as tar:
        for path in sorted(stage.rglob('*')):
            if path.is_file():
                tar.add(path, arcname=NAME + '/' + str(path.relative_to(stage)), recursive=False)
    package = {'file': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive.read_bytes()),
               'files': len(paths) + 1, 'excluded': ['*.pt', '*.npz', 'predictions/', 'credentials'],
               'all_preparation_gates_passed': result['all_preparation_gates_passed'], 'formal_jobs_submitted_by_this_workflow': False}
    assert package['bytes'] < 90 << 20, 'Package exceeds small GitHub evidence budget'
    (OUT / 'PACKAGE.json').write_text(json.dumps(package, indent=2) + '\n')
    (OUT / 'README.md').write_text('# Round2b preparation evidence\n\n[Compressed records](' + archive.name + ') · [Manifest](PACKAGE.json)\n\n'
        f"SHA256: `{package['sha256']}`\n\nVerify the archive hash, then inner `SHA256SUMS`. J5/J6 await launch; saved job files do not prove live process state. No weights or prediction arrays.\n")
    print(json.dumps(package), flush=True)


if __name__ == '__main__':
    main()
