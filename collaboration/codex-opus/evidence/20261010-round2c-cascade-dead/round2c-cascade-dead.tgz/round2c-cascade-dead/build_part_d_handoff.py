"""Package the CPU Part D results without weights or prediction arrays."""
from pathlib import Path
import hashlib
import json
import shutil
import tarfile

ROOT = Path('/guohaoran/tmp/nexus_vertex_dense_round2c_20261010')
OUT = ROOT / 'handoff013'
NAME = 'round2c-cascade-dead'
MESSAGE = '20261010-013-codex-round2c-cascade-dead.md'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    stage = OUT / NAME
    stage.mkdir(parents=True, exist_ok=False)
    code = ROOT / 'repo_07bd772/vertex/dense_overfit50_20261009'
    sources = [ROOT / 'part_d' / n for n in ('round2_cascade_dead.json', 'round2_cascade_dead.log', 'part_d_receipt.json')]
    sources += [ROOT / n for n in ('run_part_d.py', 'build_part_d_handoff.py', 'STATE.json')]
    sources += [code / n for n in ('analyze_cascade.py', 'CODEX_PROMPT_ROUND2C.md')]
    for source in sources:
        shutil.copyfile(source, stage / source.name)
    receipt = json.loads((stage / 'part_d_receipt.json').read_text())
    reports = json.loads((stage / 'round2_cascade_dead.json').read_text())
    assert len(reports) == len(receipt['inputs']) == 6
    text = ['# Codex → Opus: Round2C Part D dead-parent analysis', '',
            'Ran the unmodified `analyze_cascade.py` at `427498e88912f351ff50b70aef5888999b2af26b` in the same independent checkout. '
            'The exact six Part C evaluations were reused: 600 saved trees, each evaluation with the original 50 UIDs × seeds 97029000/97029001. '
            'Prediction, input JSON and label hashes were verified against the previous Part C receipt. All nine levels have finite saved estimates.', '',
            'CPU only. No model replay, GPU use, regeneration, threshold change, prediction repair, or training changes. '
            'The trainer, evaluator and common-code hashes still match Part C.', '',
            '## Depth 9 summary', '',
            '| Evaluation | All-depth tree exact | Dead real parents | FN under dead parents / local FN | Strongest bit hits GT / dead | Max estimate ≥0.25 / dead |',
            '|---|---:|---:|---:|---:|---:|']
    def fraction(a, b):
        return f'{a}/{b} ({a / b:.1%})' if b else '0/0 (n/a)'
    for item, result in zip(receipt['inputs'], reports):
        assert result['eval_dir'] == item['eval_dir'] and result['trees'] == 100
        s = result['per_depth']['9']
        text.append(f"| {item['run']} u{item['update']} raw | {item['full_trees_exact']}/100 | {s['dead_parents']} | "
                    f"{fraction(s['fn_in_dead_parents'], s['local_fn'])} | {fraction(s['dead_parents_argmax_hit'], s['dead_parents'])} | "
                    f"{fraction(s['dead_parents_max_estimate_ge_0.25'], s['dead_parents'])} |")
    text += ['', '## Interpretation boundaries', '',
             '- A dead real parent was generated and belongs to GT, but all eight predicted occupancy bits are empty. It is different from an extra wrong parent disappearing.',
             '- The FN share counts direct GT children at the reported depth, not final D9 vertices lost at all later depths. Counts aggregate parents across objects and seeds; they are not object-level success rates.',
             '- A correct argmax only indicates ordering of the saved continuous estimates. It does not establish that changing a threshold or forcing a child would fix generation.',
             '- The 0.25 field is descriptive. The original 0.5 occupancy threshold remains unchanged.',
             '- Local plus inherited FN/FP were checked against the original per-depth evaluation totals. Dead-parent and sibling counts passed bounds checks. The full depth1–9 tables are in the log and JSON.', '',
             f"Analyzer and post-run verification time: {receipt['seconds']:.2f} seconds. Exact command and SHA256 provenance are in `part_d_receipt.json`.", '',
             '## Manual follow-up only', '',
             'The user explicitly cancelled all scheduled tasks. No hourly follow-up, timer, background scanner or automatic GPU dispatch is enabled.',
             '- When the final raw/EMA evaluations exist, rerun both boundary and dead-parent cascade analysis on those outputs.',
             '- When each Part B 1-step/50-step raw/EMA evaluation completes, run the same two CPU analyses and publish the complete results.',
             '- User-facing checkpoints: ask again on 2026-10-11 after 08:00 UTC+8 for J3/J1/J2, and on 2026-10-12 after 08:00 UTC+8 for J5. These are suggested contact times, not timers or guaranteed completion dates.',
             '- GPU work remains separately gated on JOB_COMPLETE, final.pt, complete final raw/EMA results, and verified exclusive access to the corresponding released GPU. This Part D request did not launch Part B.', '',
             '[Compressed JSON, log and provenance](../evidence/20261010-round2c-cascade-dead/README.md)', '']
    report = '\n'.join(text)
    (stage / 'REPORT.md').write_text(report)
    (OUT / MESSAGE).write_text(report)
    files = sorted(p for p in stage.iterdir() if p.is_file())
    assert all(p.suffix not in {'.pt', '.npz'} for p in files)
    (stage / 'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.name}\n' for p in files))
    archive = OUT / (NAME + '.tgz')
    with tarfile.open(archive, 'w:gz') as tar:
        for path in sorted(stage.iterdir()):
            tar.add(path, arcname=NAME + '/' + path.name, recursive=False)
    package = {'file': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive),
               'files': len(files) + 1, 'evaluations': 6, 'trees': 600, 'commit': receipt['commit'],
               'excluded': ['*.pt', '*.npz', 'predictions/', 'credentials']}
    (OUT / 'PACKAGE.json').write_text(json.dumps(package, indent=2) + '\n')
    (OUT / 'README.md').write_text('# Round2C dead-parent evidence\n\n[Compressed records](' + archive.name +
                                 ') · [Manifest](PACKAGE.json)\n\nSHA256: `' + package['sha256'] + '`\n')
    print('PACKAGE_READY', json.dumps(package), flush=True)


if __name__ == '__main__':
    main()
