"""Run the requested Part D analyzer on unchanged Part C inputs, CPU only."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
from datetime import datetime, timezone
import numpy as np

ROOT = Path('/guohaoran/tmp/nexus_vertex_dense_round2c_20261010')
CODE = ROOT / 'repo_07bd772/vertex/dense_overfit50_20261009'
OUT = ROOT / 'part_d'
COMMIT = '427498e88912f351ff50b70aef5888999b2af26b'
PY = '/guohaoran/envs/nexus-algo/bin/python'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert subprocess.check_output(['git', '-C', str(CODE), 'rev-parse', 'HEAD'], text=True).strip() == COMMIT
    subprocess.run(['git', '-C', str(CODE), 'diff', '--exit-code', 'HEAD', '--', '.'], check=True)
    prior_path = ROOT / 'part_c/part_c_receipt.json'
    prior = json.loads(prior_path.read_text())
    inputs = prior['inputs']
    assert [(r['run'], r['update']) for r in inputs] == [
        ('J1_item', 5400), ('J2_token', 5400), ('J3_token_lr5e-6', 5400),
        ('J5_token_fine2', 3600), ('J6_token_selfcorrect', 5400), ('J3_token_lr5e-6', 3600)]
    for name in ('dense_train.py', 'common.py', 'evaluate.py'):
        assert sha(CODE / name) == prior['source_hashes'][name], name
    assert sha(CODE / 'data/prepared_d9/manifest.json') == prior['manifest_sha256']
    for name, digest in prior['label_hashes'].items():
        assert sha(CODE / name) == digest, name
    for item in inputs:
        folder = Path(item['eval_dir'])
        for name, digest in item['json_hashes'].items():
            assert sha(folder / name) == digest, str(folder / name)
        assert len(item['prediction_hashes_verified']) == 100
        for row in item['prediction_hashes_verified']:
            path = folder / 'predictions' / f"seed-{row['seed']}_{row['uid']}.npz"
            assert sha(path) == row['sha256'], str(path)
            with np.load(path, allow_pickle=False) as arrays:
                for depth in range(1, 10):
                    parents = arrays[f'depth{depth}_parents'].reshape(-1, 3)
                    occupancy = arrays[f'depth{depth}_occupancy'].astype(bool).reshape(len(parents), 8)
                    estimate = arrays[f'depth{depth}_estimate'].reshape(len(parents), 8)
                    assert np.isfinite(estimate).all(), str(path)
                    assert (estimate[~occupancy.any(axis=1)] < 0.5).all(), str(path)
        assert len(list((folder / 'predictions').glob('*.npz'))) == 100
        print('UNCHANGED_INPUT_VERIFIED', item['run'], item['update'], '100 trees', flush=True)
    OUT.mkdir(exist_ok=True)
    output = OUT / 'round2_cascade_dead.json'
    log = OUT / 'round2_cascade_dead.log'
    assert not output.exists() and not log.exists(), 'Preserve prior outputs'
    command = [PY, str(CODE / 'analyze_cascade.py')]
    for item in inputs:
        command += ['--eval-dir', item['eval_dir']]
    command += ['--output', str(output)]
    env = dict(os.environ, CUDA_VISIBLE_DEVICES='', PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION='python', OMP_NUM_THREADS='8')
    started = time.monotonic()
    with log.open('x') as stream:
        subprocess.run(command, env=env, stdout=stream, stderr=subprocess.STDOUT, check=True)
    reports = json.loads(output.read_text())
    assert len(reports) == 6
    for item, report in zip(inputs, reports):
        assert report['eval_dir'] == item['eval_dir'] and report['trees'] == 100
        evaluation = json.loads((Path(item['eval_dir']) / 'evaluation.json').read_text())
        assert set(report['per_depth']) == set(map(str, range(1, 10)))
        for depth, stats in report['per_depth'].items():
            assert 0 <= stats['dead_parents'] <= stats['correct_parents']
            assert stats['dead_parents'] <= stats['fn_in_dead_parents'] <= min(stats['local_fn'], 8 * stats['dead_parents'])
            assert 0 <= stats['dead_parents_argmax_hit'] <= stats['dead_parents']
            assert 0 <= stats['dead_parents_max_estimate_ge_0.25'] <= stats['dead_parents']
            assert stats['first_loss_cells'] == stats['local_fn']
            assert stats['local_fn_with_sibling_fp'] <= stats['local_fn'] - stats['fn_in_dead_parents']
            original = evaluation['per_depth'][int(depth) - 1]
            assert stats['local_fn'] + stats['inherited_fn'] == original['global_cells_fn']
            assert stats['local_fp'] + stats['inherited_fp'] == original['global_cells_fp']
    receipt = {'completed_utc': datetime.now(timezone.utc).isoformat(), 'command': command,
               'commit': COMMIT, 'analyzer_sha256': sha(CODE / 'analyze_cascade.py'),
               'part_c_receipt_sha256': sha(prior_path), 'inputs': inputs,
               'manifest_sha256': prior['manifest_sha256'], 'label_hashes': prior['label_hashes'],
               'unchanged_training_source_hashes': {n: sha(CODE / n) for n in ('dense_train.py', 'common.py', 'evaluate.py')},
               'return_code': 0, 'seconds': time.monotonic() - started,
               'CUDA_VISIBLE_DEVICES': '', 'OMP_NUM_THREADS': '8',
               'outputs': {p.name: sha(p) for p in (output, log)},
               'scope': 'CPU analysis of 600 saved trees; no model/GPU work or prediction repair; manual follow-up only.'}
    (OUT / 'part_d_receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print('PART_D_COMPLETE', json.dumps({'trees': 600, 'seconds': receipt['seconds'], 'output': str(OUT)}), flush=True)


if __name__ == '__main__':
    main()
