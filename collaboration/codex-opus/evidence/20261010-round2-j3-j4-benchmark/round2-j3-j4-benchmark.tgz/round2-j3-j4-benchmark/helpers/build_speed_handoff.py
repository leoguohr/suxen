"""Build small benchmark evidence on the server; never read model checkpoints."""
from collections import deque
from datetime import datetime, timezone
from pathlib import Path
import difflib
import hashlib
import json
import math
import re
import tarfile

ROOT = Path('/guohaoran/tmp/nexus_vertex_dense_round2_20261009')
OUT = ROOT / 'opus_speed_handoff_20261010'
NAME = 'round2-j3-j4-benchmark'
MESSAGE = '20261010-006-codex-round2-j3-j4-benchmark.md'
COMMIT = 'c00ebcc984ed354609c7a9e539252402e5329ef3'
INIT_SHA = '1bd4ced48296b45c80d54386171652a6f9eb9c09e8fc976965caad62899b55f9'
RUNS = {'J1': 'J1_item', 'J2': 'J2_token', 'J3': 'J3_token_lr5e-6', 'J4': 'J4_token_copies8'}
FORBIDDEN = re.compile(rb'gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|Authorization:\s*(?:Bearer|Basic)\s+[A-Za-z0-9+/=]{16,}')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text())


def main():
    stage = OUT / NAME
    stage.mkdir(parents=True, exist_ok=False)

    def put(name, data):
        path = stage / name
        assert path.suffix not in {'.pt', '.npz'} and 'predictions' not in path.parts
        raw = data if isinstance(data, bytes) else (data if isinstance(data, str) else json.dumps(data, indent=2) + '\n').encode()
        assert not FORBIDDEN.search(raw), 'Secret pattern in ' + name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)

    def copy(source, name):
        assert source.is_file() and not source.is_symlink(), str(source)
        assert source.stat().st_size <= 16 << 20, 'Unexpected large small-evidence file: ' + str(source)
        put(name, source.read_bytes())

    for name in ('benchmark_update.py', 'run_benchmark_suite.py', 'build_speed_handoff.py', 'publish_speed_handoff.py'):
        source = ROOT / name
        if source.exists():
            copy(source, 'helpers/' + name)
    for name in ('run_round2.sh', 'run_j1.sh', 'run_j2.sh', 'run_j3.sh', 'run_j4.sh'):
        copy(ROOT / 'jobs' / name, 'jobs/' + name)
    optional = []
    for source in sorted((ROOT / 'jobs').glob('*')):
        if source.is_file() and (source.suffix in {'.bak', '.orig', '.patch', '.diff'} or source.name == 'run_round2.pre_j3_j4.sh'):
            copy(source, 'jobs/prior_evidence/' + source.name)
            optional.append(str(source.relative_to(ROOT)))
    prior = ROOT / 'jobs/run_round2.pre_j3_j4.sh'
    if prior.is_file():
        patch = ''.join(difflib.unified_diff(prior.read_text().splitlines(True),
            (ROOT / 'jobs/run_round2.sh').read_text().splitlines(True),
            fromfile='jobs/run_round2.pre_j3_j4.sh', tofile='jobs/run_round2.sh'))
        put('jobs/deployment.patch', patch)
    receipt = ROOT / 'speed_benchmark_20261010/J4_init_copy.json'
    if receipt.is_file():
        copy(receipt, 'benchmark/J4_init_copy.json')
    checked = []
    for folder in (ROOT / 'jobs', ROOT / 'job_logs'):
        for source in sorted(folder.rglob('*.log')):
            if source.is_file() and not source.is_symlink() and source.stat().st_size <= 2 << 20:
                raw = source.read_bytes()
                if b'CHECK_ONLY_COMPLETE' in raw:
                    put('check_only/' + str(source.relative_to(ROOT)), raw)
                    checked.append(str(source.relative_to(ROOT)))

    recipes = {}
    for recipe in ('J3', 'J4'):
        folder = ROOT / 'speed_benchmark_20261010' / recipe
        assert folder.is_dir(), 'Missing recipe evidence: ' + str(folder)
        suite = read(folder / 'status.json')
        assert suite['state'] in ('completed', 'failed_stopped'), 'Recipe suite is still active: ' + recipe
        for source in sorted(folder.rglob('*')):
            if source.is_file() and source.suffix in {'.json', '.jsonl', '.log', '.txt'} and 'predictions' not in source.parts:
                copy(source, 'benchmark/' + recipe + '/' + str(source.relative_to(folder)))
        candidates = []
        pairings = []
        for case in suite.get('cases', []):
            case_dir = folder / case['name']
            row = {'case': case['name'], 'return_code': case.get('return_code'),
                   'summary': case.get('summary'), 'state': 'not_completed'}
            if (case_dir / 'status.json').exists():
                row['state'] = read(case_dir / 'status.json')['state']
            if (case_dir / 'summary.json').exists():
                row['summary'] = read(case_dir / 'summary.json')
            if row['return_code'] == 0 and row['state'] == 'completed' and row['summary']:
                config = read(case_dir / 'config.json')
                assert config['code_commit'] == COMMIT
                assert config['init_sha256'] == INIT_SHA
                settings = config['settings']
                assert settings['max_updates'] == 9000 and settings['warmup'] == 20 and settings['decay_fraction'] == 0.2
                assert settings['loss_weighting'] == 'token'
                assert settings['lr'] == (5e-6 if recipe == 'J3' else 1e-5)
                assert settings['coarse_copies'] == (4 if recipe == 'J3' else 8)
                assert math.isfinite(row['summary']['median_seconds']) and row['summary']['median_seconds'] > 0
                assert all(math.isfinite(row['summary'][key]) for key in ('peak_allocated_gib', 'peak_reserved_gib', 'stress_seconds'))
                timings = [json.loads(line) for line in (case_dir / 'timings.jsonl').read_text().splitlines()]
                assert [item['update'] for item in timings] == list(range(1, 7))
                pairings.append([item['noise_time_uid_sha256'] for item in timings])
                row['completed_measurement'] = True
            candidates.append(row)
        assert all(item == pairings[0] for item in pairings), 'Reconstructed input pairing mismatch: ' + recipe
        completed = [row for row in candidates if row.get('completed_measurement')]
        fastest = min(completed, key=lambda row: row['summary']['median_seconds']) if completed else None
        recipes[recipe] = {'suite_state': suite['state'], 'suite_error': suite.get('error'),
                           'hostname': suite.get('hostname'), 'gpu_uuid': suite.get('gpu_uuid'),
                           'init_sha256': suite.get('init_sha256'), 'cases': candidates,
                           'fastest_completed_measurement': fastest,
                           'reconstructed_input_pairing_verified': bool(pairings),
                           'comparison_file_present': (folder / 'comparison.json').exists()}
        if completed:
            assert suite.get('init_sha256') == INIT_SHA

    snapshots = {}
    for job, run in RUNS.items():
        folder = ROOT / 'runs' / run
        record = {'run': run, 'directory_exists': folder.exists(), 'files': {},
                  'scope': 'File snapshot only; does not prove that a live process is running.',
                  'user_reported_submitted': job in ('J1', 'J2')}
        for name in ('config.json', 'status.json'):
            path = folder / name
            if path.is_file():
                raw = path.read_bytes()
                put('formal_snapshots/' + run + '/' + name, raw)
                record['files'][name] = {'bytes': len(raw), 'sha256': sha(raw), 'mtime_unix': path.stat().st_mtime}
                if name == 'status.json':
                    record['recorded_status'] = json.loads(raw)
        train = folder / 'train.jsonl'
        if train.is_file():
            tail = deque(maxlen=20)
            skipped = False
            with train.open('rb') as stream:
                for line in stream:
                    if line.endswith(b'\n'):
                        json.loads(line)
                        tail.append(line)
                    else:
                        skipped = True
            raw = b''.join(tail)
            put('formal_snapshots/' + run + '/train_last20.jsonl', raw)
            record['files']['train_last20.jsonl'] = {'lines': len(tail), 'sha256': sha(raw), 'incomplete_last_line_omitted': skipped}
            record['last_recorded_update'] = json.loads(tail[-1])['update'] if tail else None
        record['formal_output_records_observed'] = bool(record['files'])
        record['checkpoint_files_observed'] = [name for name in ('latest.pt', 'final.pt') if (folder / name).is_file()]
        record['launcher_prepared'] = (ROOT / 'jobs' / ('run_' + job.lower() + '.sh')).is_file()
        snapshots[job] = record
    result = {'collected_server_utc': datetime.now(timezone.utc).isoformat(), 'code_commit': COMMIT,
              'recipes': recipes, 'formal_snapshots': snapshots, 'check_only_logs': checked,
              'optional_prior_script_evidence': optional, 'formal_commands_changed_by_benchmark': False,
              'limits': ['u2-5 timings are within the prescribed 20-update LR warmup, not steady-state estimates.',
                         'Each case restores full A model/AdamW/EMA and discards all six updates; no model checkpoint is saved.',
                         'UID/noise/time hashes reconstruct deterministic inputs after timing; they are not live captured tensors.',
                         'Largest-eight stress update6 and six updates total do not bound all 9000-update peaks.',
                         'Short benchmark timings do not guarantee the full 9000-update runtime or completion ETA.',
                         'Allocated/reserved CUDA peaks are reported; no explicit VRAM headroom threshold is implemented by this harness.',
                         'Failure/timeout/OOM stops that recipe suite. Completed measurements can still be reported from a failed suite.',
                         'Candidate settings are for reporting only; no candidate is automatically promoted to a formal command.',
                         'J1/J2 are user-submitted jobs; collected files are partial snapshots, not completed scientific results.',
                         'Collection timestamps are server wall time; timing durations use monotonic time and CUDA synchronization.']}
    put('RESULT.json', result)
    lines = ['# Codex → Opus: Round 2 J3/J4 performance tests', '',
             'The benchmarks run independently on two idle A100 allocations, one recipe per host. Formal J1/J2 were submitted separately by the user.', '',
             f'Approved trainer commit: `{COMMIT}`. Full A init SHA256: `{INIT_SHA}`.', '',
             '| Recipe | Suite state | Case | Median u2–5 seconds | Peak allocated GiB | Peak reserved GiB | Exit |',
             '|---|---|---|---:|---:|---:|---:|']
    for recipe, info in recipes.items():
        for case in info['cases']:
            summary = case['summary'] or {}
            lines.append(f"| {recipe} | {info['suite_state']} | {case['case']} | {summary.get('median_seconds', 'unavailable')} | {summary.get('peak_allocated_gib', 'unavailable')} | {summary.get('peak_reserved_gib', 'unavailable')} | {case['return_code']} |")
        best = info['fastest_completed_measurement']
        lines += ['', f"{recipe}: fastest completed measurement is `{best['case']}`." if best else f'{recipe}: no completed measurement is available.']
        if info['suite_error']:
            lines.append(f"Suite error: `{info['suite_error']}`. Preserve partial logs; this is not an all-cases pass.")
    lines += ['', '## Formal recipes and current evidence', '',
              '- Keep the approved 8192-token / activation-checkpointing configuration for formal J3/J4. Larger chunks showed no material speed gain. Disabling recomputation reached about 76.6 GiB allocated on J3 and OOM on J4; that candidate is not recommended for formal launch.',
              '- J1/J2 retain their original COMMON and ordering; only loss weighting differs (item/token).',
              '- J3 retains COMMON + token weighting, then appends only `--lr 5e-6`.',
              '- J4 retains COMMON + token weighting, then appends only `--coarse-copies 8`.',
              '- Formal chunk-tokens remains 8192, checkpoint-activations 1 and row-tokens 4096. Benchmark candidates do not change these commands.',
              '- All five launcher files, available check-only logs and optional prior-script evidence are included. No live remote-script diff is implied.', '']
    for job, snapshot in snapshots.items():
        lines.append(f"- {job}: launcher prepared `{snapshot['launcher_prepared']}`; formal output records observed `{snapshot['formal_output_records_observed']}`; last recorded update `{snapshot.get('last_recorded_update', 'unavailable')}`; recorded state `{snapshot.get('recorded_status', {}).get('state', 'unavailable')}`.")
    lines += ['', '## Measurement boundaries', ''] + ['- ' + note for note in result['limits']]
    lines += ['', 'No weights, prediction arrays, credentials or local result downloads are included. Original A and formal results remain on persistent `/guohaoran`; `/ssd/guohaoran` is a recreated ephemeral init cache.', '',
              '[Compressed evidence and checksum](../evidence/20261010-round2-j3-j4-benchmark/README.md)', '']
    message = '\n'.join(lines)
    (OUT / MESSAGE).write_text(message)
    put('REPORT.md', message)
    paths = sorted(path for path in stage.rglob('*') if path.is_file())
    put('SHA256SUMS', ''.join(f'{sha(path.read_bytes())}  {path.relative_to(stage)}\n' for path in paths))
    archive = OUT / (NAME + '.tgz')
    with tarfile.open(archive, 'w:gz') as tar:
        for path in sorted(stage.rglob('*')):
            if path.is_file():
                tar.add(path, arcname=NAME + '/' + str(path.relative_to(stage)), recursive=False)
    package = {'file': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive.read_bytes()),
               'files': len(paths) + 1, 'excluded': ['*.pt', '*.npz', 'predictions/', 'credentials'],
               'suite_states': {recipe: info['suite_state'] for recipe, info in recipes.items()}}
    assert package['bytes'] < 90 << 20, 'Package exceeds small GitHub evidence budget'
    (OUT / 'PACKAGE.json').write_text(json.dumps(package, indent=2) + '\n')
    (OUT / 'README.md').write_text('# Round 2 J3/J4 benchmark evidence\n\n'
        '[Compressed records](' + archive.name + ') · [Manifest](PACKAGE.json)\n\n'
        f"SHA256: `{package['sha256']}`\n\nVerify the archive hash, extract, then run `sha256sum -c SHA256SUMS` inside `{NAME}/`.\n\n"
        'Measured candidates are reports only. Failure logs and partial records are retained. No weights or predictions are included.\n')
    print(json.dumps(package), flush=True)


if __name__ == '__main__':
    main()
