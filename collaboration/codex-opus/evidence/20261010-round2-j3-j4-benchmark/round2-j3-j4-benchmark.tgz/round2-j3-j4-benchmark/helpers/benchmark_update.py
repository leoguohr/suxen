"""Isolated timing harness. Discards all updates; never saves a model checkpoint."""
import argparse
import gc
import hashlib
import json
import os
from pathlib import Path
import statistics
import struct
import subprocess
import sys
import time
import traceback
from types import SimpleNamespace

os.environ['PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION'] = 'python'
os.environ['OMP_NUM_THREADS'] = '8'
ROOT = Path('/guohaoran/tmp/nexus_vertex_dense_round2_20261009')
CODE = ROOT / 'repo/vertex/dense_overfit50_20261009'
INIT = Path('/ssd/guohaoran/nexus_vertex_dense_round2_20261009/A-final.pt')
sys.path.insert(0, str(CODE))
import torch
import dense_train as train
from common import build_model, load_data, cache_fixed_features, write_json, append_jsonl


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--recipe', choices=['J3', 'J4'], required=True)
    parser.add_argument('--chunk-tokens', type=int, required=True)
    parser.add_argument('--checkpoint-activations', type=int, choices=[0, 1], required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    status = {'state': 'initializing', 'started_unix': time.time(), 'recipe': args.recipe,
              'output': str(args.output), 'scope': 'discarded performance updates; not formal training or generation evaluation'}
    write_json(args.output / 'status.json', status)
    try:
        assert torch.cuda.is_available() and torch.cuda.device_count() == 1
        torch.set_num_threads(8)
        device = torch.device('cuda:0')
        manifest, conditions, leaves, levels, raw_gt = load_data(device)
        state = torch.load(INIT, map_location='cpu', mmap=True, weights_only=False)
        assert {'model', 'optimizer', 'ema'}.issubset(state)
        model = build_model(state['model'], device)
        model.train().requires_grad_(True)
        model.flow.use_checkpoint = False
        model.condition_encoder.use_checkpoint = False
        cache_fixed_features(model, conditions)
        optimizer = torch.optim.AdamW(model.parameters(), lr=1e-5, betas=(0.9, 0.999),
                                     eps=1e-8, weight_decay=0.0, fused=True)
        optimizer.load_state_dict(state['optimizer'])
        ema = train.EMA(model, 0.995)
        train.load_ema_into(ema, model, state['ema'], device)
        source_update = int(state['update'])
        del state
        gc.collect()
        settings = SimpleNamespace(lr=5e-6 if args.recipe == 'J3' else 1e-5,
            warmup=20, max_updates=9000, decay_fraction=0.2, min_lr=0.0,
            objects_per_update=8, coarse_depths=5, coarse_copies=8 if args.recipe == 'J4' else 4,
            row_tokens=4096, chunk_tokens=args.chunk_tokens,
            checkpoint_activations=args.checkpoint_activations, loss_weighting='token', clip=1.0,
            seed=20261010, ema_decay=0.995)
        config = {'settings': vars(settings), 'init': str(INIT), 'source_update': source_update,
                  'init_sha256': '1bd4ced48296b45c80d54386171652a6f9eb9c09e8fc976965caad62899b55f9',
                  'code_commit': subprocess.check_output(['git', '-C', str(CODE), 'rev-parse', 'HEAD'], text=True).strip(),
                  'trainer_sha256': hashlib.sha256((CODE / 'dense_train.py').read_bytes()).hexdigest(),
                  'harness_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  'torch': torch.__version__, 'gpu': torch.cuda.get_device_name(device),
                  'CUDA_VISIBLE_DEVICES': os.environ.get('CUDA_VISIBLE_DEVICES'),
                  'timing': 'CUDA synchronized train_update plus EMA; initialization, probes, saves and generation excluded',
                  'events': 'u1 warmup, u2-5 timed; then one largest-eight stress update at original schedule update6',
                  'probes': 'Not run in isolated performance harness; formal jobs keep their prescribed probes'}
        write_json(args.output / 'config.json', config)
        print('BENCH_READY', args.recipe, vars(settings), flush=True)
        status.update(state='benchmarking', initialization_seconds=time.time() - status['started_unix'])
        write_json(args.output / 'status.json', status)
        rows = []
        for update in range(1, 7):
            if update == 6:
                sizes = [sum(len(c) for c, _ in lv) for lv in levels]
                largest = sorted(range(len(levels)), key=lambda i: -sizes[i])[:8]
                train.objects_for_update = lambda a, u, n: largest
            torch.cuda.synchronize(device)
            torch.cuda.reset_peak_memory_stats(device)
            start = time.monotonic()
            row = train.train_update(model, optimizer, settings, conditions, levels, update, device)
            ema.update()
            torch.cuda.synchronize(device)
            row.update(update=update, seconds=time.monotonic() - start,
                       phase='largest-eight-stress' if update == 6 else ('warmup' if update == 1 else 'timed'),
                       peak_allocated_gib=torch.cuda.max_memory_allocated(device) / 2**30,
                       peak_reserved_gib=torch.cuda.max_memory_reserved(device) / 2**30,
                       allocated_after_gib=torch.cuda.memory_allocated(device) / 2**30,
                       reserved_after_gib=torch.cuda.memory_reserved(device) / 2**30,
                       uids=[manifest['train_uids'][i] for i in row['objects']],
                       nvidia_smi_after_update=subprocess.check_output(['nvidia-smi', '--query-gpu=uuid,memory.used,utilization.gpu', '--format=csv,noheader'], text=True).strip())
            # Rebuild deterministic inputs after timing to verify cross-case pairing without saving arrays.
            signature = hashlib.sha256()
            signature.update(json.dumps(row['uids']).encode())
            paired_items = train.build_items(settings, row['objects'], levels, update, device)
            for item in paired_items:
                signature.update(struct.pack('<id', item.depth, item.time))
                signature.update(item.noise.detach().cpu().numpy().tobytes())
            del item, paired_items
            row['noise_time_uid_sha256'] = signature.hexdigest()
            append_jsonl(args.output / 'timings.jsonl', row)
            rows.append(row)
            print('BENCH_UPDATE', json.dumps(row), flush=True)
        summary = {'recipe': args.recipe, 'chunk_tokens': args.chunk_tokens,
                   'checkpoint_activations': args.checkpoint_activations,
                   'timed_updates': [2, 3, 4, 5], 'median_seconds': statistics.median(r['seconds'] for r in rows[1:5]),
                   'peak_allocated_gib': max(r['peak_allocated_gib'] for r in rows),
                   'peak_reserved_gib': max(r['peak_reserved_gib'] for r in rows),
                   'stress_seconds': rows[-1]['seconds'], 'stress_peak_allocated_gib': rows[-1]['peak_allocated_gib'],
                   'formal_checkpoint_saved': False, 'limit': 'Six isolated updates do not bound all 9000-update memory peaks'}
        write_json(args.output / 'summary.json', summary)
        status.update(state='completed', ended_unix=time.time(), summary=summary)
        write_json(args.output / 'status.json', status)
        print('BENCH_COMPLETE', json.dumps(summary), flush=True)
    except Exception as error:
        status.update(state='failed', error=repr(error), traceback=traceback.format_exc(), ended_unix=time.time())
        write_json(args.output / 'status.json', status)
        raise


if __name__ == '__main__':
    main()
