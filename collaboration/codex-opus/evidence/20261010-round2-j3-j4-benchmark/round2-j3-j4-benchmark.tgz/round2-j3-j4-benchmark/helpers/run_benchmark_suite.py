"""Run three isolated performance cases for one recipe; stop on any failure."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import time

ROOT = Path('/guohaoran/tmp/nexus_vertex_dense_round2_20261009')
INIT = Path('/ssd/guohaoran/nexus_vertex_dense_round2_20261009/A-final.pt')
PY = '/guohaoran/envs/nexus-algo/bin/python'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--recipe', choices=['J3', 'J4'], required=True)
    parser.add_argument('--gpu', required=True)
    args = parser.parse_args()
    OUT = ROOT / 'speed_benchmark_20261010' / args.recipe
    OUT.mkdir(parents=True, exist_ok=False)
    record = {'state': 'preparing', 'started_unix': time.time(), 'recipe': args.recipe,
              'gpu_uuid': args.gpu, 'hostname': os.uname().nodename,
              'cases': [], 'formal_jobs_modified': False}
    def save():
        p = OUT / 'status.json'
        p.with_suffix('.tmp').write_text(json.dumps(record, indent=2) + '\n')
        p.with_suffix('.tmp').replace(p)
    save()
    try:
        active = subprocess.check_output(['nvidia-smi', '-i', args.gpu, '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
        assert not active, 'benchmark GPU must be idle'
        digest = hashlib.sha256()
        with INIT.open('rb') as stream:
            for block in iter(lambda: stream.read(16 << 20), b''):
                digest.update(block)
        record['init_sha256'] = digest.hexdigest()
        assert digest.hexdigest() == '1bd4ced48296b45c80d54386171652a6f9eb9c09e8fc976965caad62899b55f9'
        env = os.environ.copy()
        env.update(CUDA_VISIBLE_DEVICES=args.gpu, PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION='python', OMP_NUM_THREADS='8')
        env.pop('NEXUS_SKIP_COARSE_PROBES', None)
        for recipe in [args.recipe]:
            for name, chunk, checkpoint in [('baseline', 8192, 1), ('chunk12288', 12288, 1), ('no_recompute4096', 4096, 0)]:
                label = recipe + '_' + name
                command = [PY, '-u', str(ROOT / 'benchmark_update.py'), '--recipe', recipe,
                           '--chunk-tokens', str(chunk), '--checkpoint-activations', str(checkpoint), '--output', str(OUT / label)]
                row = {'name': label, 'command': command, 'started_unix': time.time()}
                record['cases'].append(row)
                record['state'] = 'running'
                save()
                print('CASE_STARTED', label, flush=True)
                with (OUT / (label + '.log')).open('x') as log:
                    process = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=600)
                row.update(return_code=process.returncode, ended_unix=time.time())
                save()
                assert process.returncode == 0, f'{label} failed; suite stopped; preserve log and partial timings'
                row['summary'] = json.loads((OUT / label / 'summary.json').read_text())
                save()
                print('CASE_COMPLETED', label, json.dumps(row['summary']), flush=True)
        comparisons = []
        for recipe in [args.recipe]:
            cases = [r for r in record['cases'] if r['name'].startswith(recipe + '_')]
            baseline = cases[0]['summary']['median_seconds']
            paired = None
            for case in cases:
                timings = [json.loads(x) for x in (OUT / case['name'] / 'timings.jsonl').read_text().splitlines()]
                signatures = [r['noise_time_uid_sha256'] for r in timings]
                if paired is None:
                    paired = signatures
                assert signatures == paired, 'actual noise/time/UID pair mismatch'
                comparisons.append({'case': case['name'], **case['summary'],
                                    'speedup_vs_recipe_baseline': baseline / case['summary']['median_seconds'],
                                    'actual_noise_time_uid_pairing_verified': True})
        (OUT / 'comparison.json').write_text(json.dumps(comparisons, indent=2) + '\n')
        record.update(state='completed', ended_unix=time.time())
        save()
        print('BENCHMARK_SUITE_COMPLETE', flush=True)
    except Exception as error:
        record.update(state='failed_stopped', error=repr(error), ended_unix=time.time())
        save()
        raise


if __name__ == '__main__':
    main()
