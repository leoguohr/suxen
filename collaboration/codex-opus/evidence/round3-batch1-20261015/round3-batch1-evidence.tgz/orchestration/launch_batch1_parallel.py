"""Resume the frozen evaluation list with one or two processes per GPU."""
from pathlib import Path
import argparse
import datetime
import json
import os
import subprocess
import sys
import time
import launch_batch1 as base


def validate(job, uids, logs):
    root = Path(job['output'])
    report = json.loads((root / 'summary.json').read_text())
    evaluation = json.loads((root / 'evaluation.json').read_text())
    rows = evaluation['rows']
    expected = {(uid, seed) for seed in job['seeds'] for uid in uids}
    assert len(rows) == 100 and {(r['uid'], r['seed']) for r in rows} == expected
    exact = sum(bool(r['all_levels_exact']) for r in rows)
    assert report['trees'] == 100 and report['full_trees_exact'] == exact
    assert evaluation['full_trees_exact'] == exact
    assert report['seeds'] == job['seeds'] and report['steps_per_depth'] == job['steps']
    assert report['weights'] == job['weights']
    assert 'EVALUATION_COMPLETE' in (logs / f'{job["id"]}.log').read_text()[-8192:]
    return exact


def analyze(job, work, env):
    root = Path(job['output'])
    codes = job.setdefault('analysis_exit_codes', {})
    for kind, command in zip(('boundary', 'cascade'), job['analysis_commands']):
        target = root / f'{kind}.json'
        if codes.get(kind) == 0 and target.exists():
            json.loads(target.read_text())
            continue
        logpath = root / f'{kind}.log'
        n = 0
        while logpath.exists():
            n += 1
            logpath = root / f'{kind}.retry{n}.log'
        if target.exists():
            # Existing analysis evidence is immutable; retries use distinct files.
            command = command[:-1] + [str(root / f'{kind}.retry{n or 1}.json')]
        with logpath.open('x') as log:
            result = subprocess.run(command, cwd=work, env=env, stdout=log, stderr=subprocess.STDOUT)
        codes[kind] = result.returncode
        job.setdefault('analysis_logs', {})[kind] = str(logpath)
        if result.returncode == 0:
            json.loads(Path(command[-1]).read_text())
            job.setdefault('analysis_json', {})[kind] = command[-1]
    job['status'] = 'complete' if all(v == 0 for v in codes.values()) else 'evaluation_complete_analysis_failed'
    job['ended_utc'] = base.now()


class AdoptedProcess:
    """A live child of the stopped queue; its eventual wait status is unavailable here."""
    def __init__(self, job):
        self.pid = int(job['pid'])
        proc = Path('/proc') / str(self.pid)
        assert self.poll() is None, f'previous evaluation is no longer alive: {self.pid}'
        command = proc.joinpath('cmdline').read_bytes().rstrip(b'\0').split(b'\0')
        assert [x.decode() for x in command] == job['command'], f'PID {self.pid} command differs'
        environment = dict(x.split(b'=', 1) for x in proc.joinpath('environ').read_bytes().split(b'\0') if b'=' in x)
        assert environment.get(b'CUDA_VISIBLE_DEVICES') == str(job['gpu']).encode()
        self.start_ticks = proc.joinpath('stat').read_text().rsplit(') ', 1)[1].split()[19]

    def poll(self):
        try:
            fields = (Path('/proc') / str(self.pid) / 'stat').read_text().rsplit(') ', 1)[1].split()
        except FileNotFoundError:
            return 0
        if fields[0] == 'Z':
            return 0
        if hasattr(self, 'start_ticks'):
            assert fields[19] == self.start_ticks, f'PID {self.pid} reused'
        return None


def gpu_with_owned(gpu, owned):
    row = base.output(['nvidia-smi', '-i', str(gpu), '--query-gpu=index,uuid,memory.used,memory.total',
                       '--format=csv,noheader,nounits']).split(',')
    uuid = row[1].strip()
    lines = base.output(['nvidia-smi', '--query-compute-apps=gpu_uuid,pid', '--format=csv,noheader,nounits'])
    active = {int(line.split(',')[1]) for line in lines.splitlines() if line.split(',')[0].strip() == uuid}
    mapping = 'same_pid_namespace'
    if not active <= owned:
        # nvidia-smi exposes host PIDs while /proc in this container exposes namespace PIDs.
        assert len(active) == len(owned) == 1, f'GPU {gpu} has ambiguous PID ownership: {active} vs {owned}'
        mapping = 'single_process_gpu_env_and_count_host_container_mapping'
    if not active:
        assert int(row[2]) < 1024, f'GPU {gpu} has unexpected occupied memory'
    return {'index': gpu, 'uuid': uuid, 'memory_used_mib': int(row[2]), 'host_compute_pids': sorted(active), 'container_owned_pids': sorted(owned), 'pid_mapping': mapping}


def run(args):
    root = args.output
    work = args.source / 'vertex/dense_overfit50_20261009'
    state = json.loads((root / 'status.json').read_text())
    commands = json.loads((root / 'launch_commands.json').read_text())
    assert state['commit'] == commands['commit'] == base.COMMIT
    assert base.output(['git', 'rev-parse', 'HEAD'], cwd=args.source) == base.COMMIT
    assert not base.output(['git', 'status', '--porcelain'], cwd=args.source)
    assert args.cpu_gate.read_text().strip().splitlines()[-1].startswith('ALL CPU TESTS PASSED')
    gpus = [int(x) for x in args.gpus.split(',')]
    assert 1 <= len(gpus) <= 4 and len(gpus) == len(set(gpus))
    original = {j['id']: j for j in commands['jobs']}
    for job in state['jobs']:
        assert job['command'] == original[job['id']]['command']
    uids = json.loads((work / 'data/prepared_d9/manifest.json').read_text())['train_uids']
    assert len(uids) == len(set(uids)) == 50
    env = dict(os.environ, CUDA_VISIBLE_DEVICES='', PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION='python',
               OMP_NUM_THREADS='4', MKL_NUM_THREADS='4')
    logs = root / 'logs'
    state.update(previous_queue_pid=state.get('queue_pid'), queue_pid=os.getpid(),
                 resumed_utc=base.now(), status='running', max_per_gpu=args.max_per_gpu)
    def save():
        base.write_json(root / 'status.json', state)
    save()
    pending = []
    recovered_analysis = []
    active = {g: [] for g in gpus}
    for job in state['jobs']:
        destination = Path(job['output'])
        if (destination / 'summary.json').exists() and (destination / 'evaluation.json').exists():
            job['full_trees_exact'] = validate(job, uids, logs)
            job.update(trees=100, recovered_without_regeneration=True, status='analyzing')
            save()
            recovered_analysis.append(job)
        elif job['status'] == 'evaluating':
            assert job['gpu'] in gpus
            proc = AdoptedProcess(job)
            elapsed = (datetime.datetime.now(datetime.timezone.utc) - datetime.datetime.fromisoformat(job['started_utc'])).total_seconds()
            job.update(adopted_utc=base.now(), adopted_pid=proc.pid, adopted_exit_status_unavailable=True)
            active[job['gpu']].append((proc, job, None, time.monotonic() - max(0, elapsed)))
            save()
        else:
            assert job['status'] == 'pending', f'incomplete previous evaluation: {job["id"]}'
            assert not destination.exists() and not (logs / f'{job["id"]}.log').exists()
            pending.append(job)
    state['resume_gpu_precheck'] = [gpu_with_owned(g, {p.pid for p, _, _, _ in active[g]}) for g in gpus]
    save()
    preferred = {g: records[0][1]['name'] for g, records in active.items() if records}
    failed_slots = {g: 0 for g in gpus}
    control = root.parent / 'concurrency.json'
    while pending or any(active.values()) or recovered_analysis:
        cap = args.max_per_gpu
        if control.exists():
            cap = int(json.loads(control.read_text())['max_per_gpu'])
            assert cap in (1, 2), 'concurrency.json max_per_gpu must be 1 or 2'
        if state['max_per_gpu'] != cap:
            state['max_per_gpu'] = cap
            state.setdefault('concurrency_changes', []).append({'utc': base.now(), 'max_per_gpu': cap})
            save()
        for gpu in gpus:
            for record in list(active[gpu]):
                proc, job, log, started = record
                code = proc.poll()
                if code is None:
                    continue
                if log is not None:
                    log.close()
                active[gpu].remove(record)
                job.update(eval_exit_code=None if isinstance(proc, AdoptedProcess) else code,
                           evaluation_seconds=time.monotonic() - started)
                try:
                    assert code == 0, f'evaluate exited {code}'
                    job['full_trees_exact'] = validate(job, uids, logs)
                    job.update(status='analyzing', trees=100)
                    save()
                    analyze(job, work, env)
                except Exception as exc:
                    job.update(status='failed', error=str(exc), ended_utc=base.now())
                    failed_slots[gpu] += 1
                    state.setdefault('gpu_errors', {})[str(gpu)] = str(exc)
                save()
            while pending and len(active[gpu]) < max(0, cap - failed_slots[gpu]):
                chosen = 0
                if gpu in preferred:
                    chosen = next((i for i, candidate in enumerate(pending)
                                   if candidate.get('name') == preferred[gpu] and candidate['steps'] == 20
                                   and candidate['seeds'] != [97029000, 97029001]), 0)
                    del preferred[gpu]
                job = pending.pop(chosen)
                log = (logs / f'{job["id"]}.log').open('x')
                try:
                    proc = subprocess.Popen(job['command'], cwd=work,
                                            env=dict(env, CUDA_VISIBLE_DEVICES=str(gpu)),
                                            stdout=log, stderr=subprocess.STDOUT)
                except Exception as exc:
                    log.close()
                    job.update(status='failed', error=str(exc), ended_utc=base.now())
                    failed_slots[gpu] += 1
                    save()
                    continue
                job.update(status='evaluating', gpu=gpu, pid=proc.pid, started_utc=base.now(),
                           concurrent_on_gpu_at_start=len(active[gpu]) + 1)
                active[gpu].append((proc, job, log, time.monotonic()))
                save()
                print('START', job['id'], 'GPU', gpu, 'PID', proc.pid, flush=True)
        if recovered_analysis:
            job = recovered_analysis.pop(0)
            try:
                analyze(job, work, env)
            except Exception as exc:
                job.update(status='evaluation_complete_analysis_failed', analysis_error=str(exc))
            save()
        if pending and not any(active.values()) and all(cap - failed_slots[g] <= 0 for g in gpus):
            break
        if pending or any(active.values()):
            time.sleep(2)
    state['ended_utc'] = base.now()
    state['status'] = 'complete' if all(j['status'] == 'complete' for j in state['jobs']) else 'incomplete_or_analysis_failed'
    save()
    print('BATCH1_FINISHED', state['status'], flush=True)
    return 0 if state['status'] == 'complete' else 1


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source', type=Path, required=True)
    p.add_argument('--python', default=sys.executable)
    p.add_argument('--gpus', default='0,1,2,3')
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--cpu-gate', type=Path, required=True)
    p.add_argument('--max-per-gpu', type=int, choices=(1, 2), default=2)
    return run(p.parse_args())


if __name__ == '__main__':
    raise SystemExit(main())
