"""Publish a validated Round3 Batch1 payload; token arrives only as stdin JSON."""
import argparse
import base64
from concurrent.futures import ThreadPoolExecutor
import fcntl
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import sys
import tarfile
import time
import urllib.error
import urllib.parse
import urllib.request

HELPER = Path('/guohaoran/tmp/nexus_vertex_dense_round2c_20261010/jobs')
if not HELPER.is_dir():
    HELPER = Path(__file__).resolve().parents[1] / 'nexus_vertex_dense_round2c_20261010/jobs'
sys.path.insert(0, str(HELPER))
from publish_j3_snapshot_decode import api as api_once, encoded, sha, BRANCH, PREFIX

NAME = 'round3-batch1-20261015'
EVIDENCE = PREFIX + 'evidence/' + NAME + '/'
MESSAGE = PREFIX + 'messages/20261015-round3-batch1.md'
TITLE = 'Round3 Batch1 frozen evaluation — 2026-10-15'
FORBIDDEN = re.compile(rb'gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|Authorization:\s*(?:Bearer|Basic)\s+[A-Za-z0-9+/=]{16,}')


def network_retry(call):
    for attempt in range(4):
        try:
            return call()
        except urllib.error.HTTPError as error:
            if error.code not in (429, 500, 502, 503, 504) or attempt == 3:
                raise
        except (urllib.error.URLError, OSError):
            if attempt == 3:
                raise
        time.sleep(2 ** attempt)


def api(*args, **kwargs):
    return network_retry(lambda: api_once(*args, **kwargs))


def scan(content, token, compressed=False):
    with gzip.GzipFile(fileobj=io.BytesIO(content)) if compressed else io.BytesIO(content) as stream:
        tail = b''
        while block := stream.read(1 << 20):
            window = tail + block
            assert token.encode() not in window and not FORBIDDEN.search(window), 'Credential detected in evidence'
            tail = window[-max(4096, len(token)):]


def collect(folder, token):
    root, manifest_path = folder / 'payload', folder / 'UPLOAD_MANIFEST.json'
    assert root.is_dir() and not root.is_symlink()
    assert manifest_path.is_file() and not manifest_path.is_symlink() and manifest_path.stat().st_size < 25 << 20
    manifest_bytes = manifest_path.read_bytes()
    manifest = json.loads(manifest_bytes)
    assert isinstance(manifest, list) and manifest, 'Expected nonempty upload manifest'
    expected = {}
    for row in manifest:
        name = row['path']
        path = PurePosixPath(name)
        assert name and str(path) == name and not path.is_absolute() and '..' not in path.parts and '\\' not in name, 'Unsafe manifest path'
        assert name not in expected and name != 'UPLOAD_MANIFEST.json', 'Duplicate or reserved manifest path'
        assert not {suffix.lower() for suffix in path.suffixes} & {'.pt', '.pth', '.npz'}, 'Model or prediction file is forbidden'
        assert 'predictions' not in path.parts and path.suffix.lower() in ('.json', '.jsonl', '.md', '.log', '.txt', '.py', '.sh', '.gz', '.tgz', '.sha256'), 'Disallowed evidence type'
        assert type(row['bytes']) is int and 0 <= row['bytes'] < 25 << 20 and re.fullmatch('[0-9a-f]{64}', row['sha256'])
        expected[name] = row
    actual = []
    for path in root.rglob('*'):
        assert not path.is_symlink(), 'Symlink in payload'
        if not path.is_dir():
            assert path.is_file(), 'Nonregular payload file'
            actual.append(str(path.relative_to(root)))
    assert set(actual) == set(expected), 'Payload files differ from manifest'
    assert {'REPORT.md', 'STATUS.json', 'FILE_MANIFEST.json'} <= set(expected)
    assert sum(row['bytes'] for row in manifest) + len(manifest_bytes) < 80 << 20, 'Upload exceeds 80 MiB'
    files = {'UPLOAD_MANIFEST.json': manifest_bytes}
    for name in sorted(expected):
        path, row = root / name, expected[name]
        assert path.stat().st_size == row['bytes'], 'File size changed'
        content = path.read_bytes()
        assert len(content) == row['bytes'] and sha(content) == row['sha256'], 'File hash changed'
        scan(content, token)
        if name.lower().endswith('.gz'):
            scan(content, token, compressed=True)
        files[name] = content
    validate_archive(files, token)
    scan(manifest_bytes, token)
    return files, sha(manifest_bytes)


def validate_archive(files, token):
    manifest = json.loads(files['FILE_MANIFEST.json'])
    expected = {row['path']: row for row in manifest}
    assert len(expected) == len(manifest) and expected, 'Invalid archive manifest'
    seen = set()
    with tarfile.open(fileobj=io.BytesIO(files['round3-batch1-evidence.tgz']), mode='r:gz') as archive:
        for member in archive:
            name, path = member.name, PurePosixPath(member.name)
            assert member.isfile() and name in expected and name not in seen
            assert str(path) == name and not path.is_absolute() and '..' not in path.parts and '\\' not in name
            assert path.suffix.lower() in ('.json', '.jsonl', '.md', '.log', '.txt', '.py', '.sh', '.gz') and 'predictions' not in path.parts
            assert not {suffix.lower() for suffix in path.suffixes} & {'.pt', '.pth', '.npz'}
            row = expected[name]
            assert member.size == row['bytes'] and member.size < 25 << 20
            content = archive.extractfile(member).read()
            assert len(content) == row['bytes'] and sha(content) == row['sha256']
            scan(content, token)
            if name.lower().endswith('.gz'):
                scan(content, token, compressed=True)
            seen.add(name)
    assert seen == set(expected), 'Archive files differ from manifest'


def publish(folder, token):
    files, manifest_sha = collect(folder, token)
    payload = {EVIDENCE + name: content for name, content in files.items()}
    payload[MESSAGE] = files['REPORT.md'] + f'\n[Compressed evidence](../evidence/{NAME}/round3-batch1-evidence.tgz) · [Evidence files](../evidence/{NAME}/) · [Upload SHA256 manifest](../evidence/{NAME}/UPLOAD_MANIFEST.json)\n'.encode()
    receipt_path = folder / 'GITHUB_PUBLISH.json'
    if receipt_path.exists():
        receipt = json.loads(receipt_path.read_text())
        assert receipt['manifest_sha256'] == manifest_sha and receipt['branch'] == BRANCH
        commit, parent = receipt['commit'], receipt['parent']
    else:
        def blob(path, content):
            value = api('/git/blobs', token, {'encoding': 'base64', 'content': base64.b64encode(content).decode()})
            assert value['sha'] == hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\0' + content).hexdigest()
            return {'path': path, 'mode': '100644', 'type': 'blob', 'sha': value['sha']}
        with ThreadPoolExecutor(max_workers=4) as pool:
            entries = list(pool.map(lambda item: blob(*item), payload.items()))
        for attempt in range(4):
            parent = api('/git/ref/heads/' + BRANCH, token)['object']['sha']
            base = api('/git/commits/' + parent, token)
            try:
                existing = api('/contents/' + MESSAGE + '?ref=' + parent, token)
            except urllib.error.HTTPError as error:
                if error.code != 404:
                    raise
            else:
                assert base64.b64decode(existing['content']) == payload[MESSAGE], 'Destination already has a different report'
                commit, parent = parent, None
                break
            readme = base64.b64decode(api('/contents/' + PREFIX + 'README.md?ref=' + parent, token)['content'])
            readme += f'\n- [{TITLE}](messages/20261015-round3-batch1.md)\n'.encode()
            tree = api('/git/trees', token, {'base_tree': base['tree']['sha'], 'tree': entries + [blob(PREFIX + 'README.md', readme)]})
            commit = api('/git/commits', token, {'message': TITLE, 'tree': tree['sha'], 'parents': [parent]})['sha']
            try:
                api('/git/refs/heads/' + BRANCH, token, {'sha': commit, 'force': False}, 'PATCH')
                payload[PREFIX + 'README.md'] = readme
                break
            except urllib.error.HTTPError as error:
                if error.code not in (409, 422) or attempt == 3:
                    raise
    def verify(item):
        path, content = item
        url = f'https://raw.githubusercontent.com/leoguohr/suxen/{commit}/' + urllib.parse.quote(path, safe='/')
        def readback():
            with urllib.request.urlopen(url, timeout=120) as response:
                return response.read()
        assert sha(network_retry(readback)) == sha(content), 'Public immutable readback mismatch'
    with ThreadPoolExecutor(max_workers=4) as pool:
        list(pool.map(verify, payload.items()))
    receipt = {'commit': commit, 'parent': parent, 'branch': BRANCH, 'manifest_sha256': manifest_sha,
               'public_readback_verified': True, 'published_sha256': {path: sha(content) for path, content in payload.items()},
               'message_url': f'https://github.com/leoguohr/suxen/blob/{commit}/{MESSAGE}'}
    temporary = receipt_path.with_suffix('.tmp')
    temporary.write_bytes(encoded(receipt))
    temporary.replace(receipt_path)
    print('PUBLISH_VERIFIED', json.dumps(receipt), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bundle-dir', required=True, type=Path)
    args = parser.parse_args()
    token = json.load(sys.stdin)['token']
    assert isinstance(token, str) and len(token) >= 20 and not any(char.isspace() for char in token)
    folder = args.bundle_dir.resolve(strict=True)
    with (folder / '.publish.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        publish(folder, token)
