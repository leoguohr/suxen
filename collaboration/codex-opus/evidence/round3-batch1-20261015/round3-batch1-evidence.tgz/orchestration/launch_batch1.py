"""Frozen Round 3 Batch 1 evaluation queue; no training and no automatic restart."""
from pathlib import Path
import argparse
import concurrent.futures
import datetime
import hashlib
import json
import os
import queue
import subprocess
import sys
import threading
import time

COMMIT = 'e7e3a326a65bc550be695104ae69e0d3435bd446'
BASE = Path('/guohaoran/tmp/nexus_vertex_dense_round2_20261009/runs')
SWEEP = Path('/guohaoran/tmp/nexus_vertex_arch_sweep_recovery_20261007/runs')
OFFICIAL = '97029000,97029001'


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def write_json(path, value):
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, indent=2) + '\n')
    temp.replace(path)


def output(command, **kwargs):
    return subprocess.check_output(command, text=True, **kwargs).strip()


def gpu_free(index):
    row = output(['nvidia-smi', '-i', str(index), '--query-gpu=index,uuid,memory.used,memory.total',
                  '--format=csv,noheader,nounits']).split(',')
    uuid = row[1].strip()
    active = output(['nvidia-smi', '--query-compute-apps=gpu_uuid,pid', '--format=csv,noheader,nounits'])
    assert not any(line.split(',')[0].strip() == uuid for line in active.splitlines()), f'GPU {index} has another process'
    assert int(row[2]) < 1024, f'GPU {index} has {row[2]} MiB occupied'
    return {'index': index, 'uuid': uuid, 'memory_used_mib': int(row[2]), 'memory_total_mib': int(row[3])}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True, help='NEW git checkout root')
    parser.add_argument('--python', default=sys.executable)
    parser.add_argument('--gpus', default='0,1,2,3')
    parser.add_argument('--output', type=Path, default=Path('/guohaoran/tmp/nexus_round3_eval_20261015/round3_eval'))
    parser.add_argument('--cpu-gate', type=Path, required=True)
    args = parser.parse_args()
    args.source = args.source.resolve()
    args.output = args.output.resolve()
    work = args.source / 'vertex/dense_overfit50_20261009'
    gpus = [int(x) for x in args.gpus.split(',')]
    assert 1 <= len(gpus) <= 4 and len(gpus) == len(set(gpus))
    gate_line = args.cpu_gate.read_text().strip().splitlines()[-1]
    assert gate_line.startswith('ALL CPU TESTS PASSED'), gate_line
    assert output(['git', 'rev-parse', 'HEAD'], cwd=args.source) == COMMIT
    assert not output(['git', 'status', '--porcelain'], cwd=args.source), 'source checkout must be clean'
    cards = [gpu_free(g) for g in gpus]
    assert not (args.output / 'status.json').exists(), 'queue already has a status; do not rerun'
    args.output.mkdir(parents=True, exist_ok=True)
    logs = args.output / 'logs'
    logs.mkdir(exist_ok=True)
    cpu_env = dict(os.environ, CUDA_VISIBLE_DEVICES='', PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION='python')
    paths = {'J5': BASE / 'J5_token_fine2/final.pt', 'J2': BASE / 'J2_token/final.pt',
             'S0': SWEEP / 'S0/checkpoint-034000.pt', 'S1': SWEEP / 'S1/checkpoint-034000.pt'}
    # mmap reads the checkpoint structure without copying the large parameter tensors.
    inspect = '''import json,sys,torch
from pathlib import Path
r={}
for name,p in json.loads(sys.argv[1]).items():
 s=torch.load(p,map_location="cpu",mmap=True,weights_only=False)
 assert isinstance(s.get("model"),dict) and s["model"]
 r[name]={"path":p,"bytes":Path(p).stat().st_size,"mtime_ns":Path(p).stat().st_mtime_ns,
          "keys":list(s),"update":s.get("update"),"step":s.get("step"),
          "has_ema":isinstance(s.get("ema"),dict) and bool(s["ema"]),"sha256_recomputed":False}
 del s
print(json.dumps(r))'''
    identities = json.loads(output([args.python, '-c', inspect, json.dumps({k: str(v) for k, v in paths.items()})], env=cpu_env))
    for name in ('J2', 'J5'):
        assert identities[name]['update'] == 9000 and identities[name]['has_ema'], identities[name]
    for name in ('S0', 'S1'):
        assert identities[name]['step'] == 34000, identities[name]
    jobs = []
    def add(name, weights, steps, seeds, suffix):
        label = f'{name}_{weights}_{suffix}'
        destination = args.output / label
        assert not destination.exists(), f'output exists: {destination}'
        command = [args.python, str(work / 'evaluate.py'), '--checkpoint', str(paths[name]), '--weights', weights,
                   '--output', str(destination), '--steps', str(steps), '--sampler', 'euler', '--seeds', seeds,
                   '--variant', name if name.startswith('S') else 'S0']
        analyses = [[args.python, str(work / f'analyze_{kind}.py'), '--eval-dir', str(destination),
                     '--output', str(destination / f'{kind}.json')] for kind in ('boundary', 'cascade')]
        jobs.append({'id': label, 'name': name, 'output': str(destination), 'command': command,
                     'analysis_commands': analyses, 'seeds': [int(x) for x in seeds.split(',')],
                     'steps': steps, 'weights': weights, 'status': 'pending'})
    for first in (97029002, 97029004, 97029006, 97029008):
        for name in ('J5', 'J2'):
            add(name, 'ema', 20, f'{first},{first+1}', f'euler20_seeds{first}_{first+1}')
    for steps in (5, 10, 15, 30):
        for name in ('J5', 'J2'):
            add(name, 'ema', steps, OFFICIAL, f'euler{steps}_official')
    for name in ('S0', 'S1'):
        add(name, 'raw', 20, OFFICIAL, 'euler20_official')
        if identities[name]['has_ema']:
            add(name, 'ema', 20, OFFICIAL, 'euler20_official')
    state = {'commit': COMMIT, 'started_utc': now(), 'queue_pid': os.getpid(), 'status': 'running',
             'gpu_precheck': cards, 'checkpoint_identity': identities, 'cpu_gate_last_line': gate_line,
             'cpu_gate_sha256': hashlib.sha256(args.cpu_gate.read_bytes()).hexdigest(),
             'sweep_note': '20261007 contains checkpoint files; 20261007b contains recovery evaluation records.',
             'jobs': jobs, 'gpu_errors': {}}
    write_json(args.output / 'launch_commands.json', {'source': str(args.source), 'commit': COMMIT, 'gpus': gpus, 'jobs': jobs})
    lock = threading.Lock()
    def save():
        write_json(args.output / 'status.json', state)
    save()
    pending = queue.Queue()
    for job in jobs:
        pending.put(job)
    def worker(gpu):
        while True:
            try:
                job = pending.get_nowait()
            except queue.Empty:
                return
            try:
                gpu_free(gpu)
                with lock:
                    job.update(status='evaluating', gpu=gpu, started_utc=now())
                    save()
                started = time.monotonic()
                env = dict(cpu_env, CUDA_VISIBLE_DEVICES=str(gpu), OMP_NUM_THREADS='4', MKL_NUM_THREADS='4')
                with (logs / f'{job["id"]}.log').open('x') as log:
                    proc = subprocess.Popen(job['command'], cwd=work, env=env, stdout=log, stderr=subprocess.STDOUT)
                    with lock:
                        job['pid'] = proc.pid
                        save()
                    code = proc.wait()
                with lock:
                    job['eval_exit_code'] = code
                    job['evaluation_seconds'] = time.monotonic() - started
                assert code == 0, f'evaluate exited {code}'
                destination = Path(job['output'])
                summary = json.loads((destination / 'summary.json').read_text())
                evaluation = json.loads((destination / 'evaluation.json').read_text())
                assert summary['trees'] == 100 and len(evaluation['rows']) == 100
                assert sorted(summary['seeds']) == sorted(job['seeds'])
                assert len({(r['uid'], r['seed']) for r in evaluation['rows']}) == 100
                with lock:
                    job.update(status='analyzing', full_trees_exact=summary['full_trees_exact'], trees=100)
                    save()
                with lock:
                    job['analysis_exit_codes'] = {}
                for kind, command in zip(('boundary', 'cascade'), job['analysis_commands']):
                    with (destination / f'{kind}.log').open('x') as log:
                        result = subprocess.run(command, cwd=work, env=cpu_env, stdout=log, stderr=subprocess.STDOUT)
                    with lock:
                        job['analysis_exit_codes'][kind] = result.returncode
                        save()
                    if result.returncode == 0:
                        json.loads((destination / f'{kind}.json').read_text())
                with lock:
                    job['status'] = 'complete' if all(v == 0 for v in job['analysis_exit_codes'].values()) else 'evaluation_complete_analysis_failed'
                    job['ended_utc'] = now()
                    save()
                print(job['id'], job['status'], f"{job['full_trees_exact']}/100", flush=True)
            except Exception as exc:
                with lock:
                    job.update(status='failed', error=str(exc), ended_utc=now())
                    state['gpu_errors'][str(gpu)] = str(exc)
                    save()
                print('GPU worker stopped', gpu, job['id'], str(exc), flush=True)
                return
            finally:
                pending.task_done()
    with concurrent.futures.ThreadPoolExecutor(max_workers=len(gpus)) as pool:
        list(pool.map(worker, gpus))
    state['ended_utc'] = now()
    state['status'] = 'complete' if all(j['status'] == 'complete' for j in jobs) else 'incomplete_or_analysis_failed'
    save()
    print('BATCH1_FINISHED', state['status'], flush=True)
    return 0 if state['status'] == 'complete' else 1


if __name__ == '__main__':
    raise SystemExit(main())
