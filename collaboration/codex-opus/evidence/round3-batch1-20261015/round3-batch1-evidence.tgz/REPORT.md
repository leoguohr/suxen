# Round 3 Batch 1 frozen evaluation

- Queue status: `incomplete_or_analysis_failed`; complete delivery: `True`.
- GPU evaluation complete: `True`; analysis complete after any formatting fallback: `True`. Original queue status is retained.
- Validated complete evaluations: 18/18 scheduled cases. Every reported score has denominator 100.
- Additional seeds estimate fixed-object robustness; they are separate from the official acceptance seed pair.
- This collection validates saved JSON coverage and counts. No model forward, training, or checkpoint hashing was performed.

| Case | Original queue state | Evaluator exit | Full-tree exact | Original analysis exits | Boundary fallback succeeded | Validation issue |
|---|---|---|---|---|---|---|
| J5_ema_euler20_seeds97029002_97029003 | complete | 0 | 86/100 | {'boundary': 0, 'cascade': 0} | False |  |
| J2_ema_euler20_seeds97029002_97029003 | evaluation_complete_analysis_failed | 0 | 79/100 | {'boundary': 1, 'cascade': 0} | True |  |
| J5_ema_euler20_seeds97029004_97029005 | evaluation_complete_analysis_failed | 0 | 87/100 | {'boundary': 1, 'cascade': 0} | True |  |
| J2_ema_euler20_seeds97029004_97029005 | complete | unknown | 76/100 | {'boundary': 0, 'cascade': 0} | False |  |
| J5_ema_euler20_seeds97029006_97029007 | complete | unknown | 86/100 | {'boundary': 0, 'cascade': 0} | False |  |
| J2_ema_euler20_seeds97029006_97029007 | complete | unknown | 75/100 | {'boundary': 0, 'cascade': 0} | False |  |
| J5_ema_euler20_seeds97029008_97029009 | evaluation_complete_analysis_failed | 0 | 87/100 | {'boundary': 1, 'cascade': 0} | True |  |
| J2_ema_euler20_seeds97029008_97029009 | complete | 0 | 83/100 | {'boundary': 0, 'cascade': 0} | False |  |
| J5_ema_euler5_official | complete | 0 | 96/100 | {'boundary': 0, 'cascade': 0} | False |  |
| J2_ema_euler5_official | complete | 0 | 94/100 | {'boundary': 0, 'cascade': 0} | False |  |
| J5_ema_euler10_official | complete | 0 | 92/100 | {'boundary': 0, 'cascade': 0} | False |  |
| J2_ema_euler10_official | evaluation_complete_analysis_failed | 0 | 87/100 | {'boundary': 1, 'cascade': 0} | True |  |
| J5_ema_euler15_official | complete | 0 | 93/100 | {'boundary': 0, 'cascade': 0} | False |  |
| J2_ema_euler15_official | evaluation_complete_analysis_failed | 0 | 87/100 | {'boundary': 1, 'cascade': 0} | True |  |
| J5_ema_euler30_official | complete | 0 | 86/100 | {'boundary': 0, 'cascade': 0} | False |  |
| J2_ema_euler30_official | evaluation_complete_analysis_failed | 0 | 79/100 | {'boundary': 1, 'cascade': 0} | True |  |
| S0_raw_euler20_official | complete | 0 | 7/100 | {'boundary': 0, 'cascade': 0} | False |  |
| S1_raw_euler20_official | complete | 0 | 7/100 | {'boundary': 0, 'cascade': 0} | False |  |

## Evidence

- The compressed archive contains completed evaluation JSON, available analysis and failure logs, exact commands, CPU gate, source files and code/checkpoint identities. Incomplete evaluations are not reported as completed metrics.
- `STATUS.json` records missing evidence and per-case validation errors. A missing launcher status is a failure boundary, not an empty successful batch.
- Recovered/adopted process exits remain unknown when unavailable. Their completed metrics require the original EVALUATION_COMPLETE log marker plus exactly 100 UID/seed pairs and consistent summary counts; no exit code is invented.
- A boundary CLI NoneType formatting failure can be recovered by a separate CPU adapter calling the unchanged frozen calculation functions. Original failure logs and exit codes remain; adapter output and provenance are separate. Such a formatting failure does not mean GPU generation failed.
- Checkpoint identity includes the saved update/step and whether a hash was recomputed; this collector does not strengthen that evidence.
- S0 full training log: https://github.com/leoguohr/suxen/blob/5369c4a56b3d2c2743a032413982a30d8bcae205/collaboration/codex-opus/evidence/architecture-sweep-step34000-20261015/S0/train.jsonl.gz
- S1 full training log: https://github.com/leoguohr/suxen/blob/5369c4a56b3d2c2743a032413982a30d8bcae205/collaboration/codex-opus/evidence/architecture-sweep-step34000-20261015/S1/train.jsonl.gz
- Those logs are already published at immutable commit `5369c4a56b3d2c2743a032413982a30d8bcae205` and are not duplicated here.
