"""Validate four new completed milestones and package saved server evidence."""
from collections import Counter, deque
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import re
import subprocess
import tarfile

ROOT = Path('/guohaoran/tmp/nexus_vertex_dense_round2_20261009')
OUT = ROOT / 'opus_milestones009_handoff_20261010'
NAME = 'round2-milestones009'
MESSAGE = '20261010-009-codex-round2-milestones.md'
PY = '/guohaoran/envs/nexus-algo/bin/python'
RUNS = {'J1': 'J1_item', 'J2': 'J2_token', 'J3': 'J3_token_lr5e-6',
        'J4': 'J4_token_copies8', 'J5': 'J5_token_fine2', 'J6': 'J6_token_selfcorrect'}
TARGETS = {'J1': (3600, 'raw'), 'J2': (3600, 'raw'), 'J3': (3600, 'raw'), 'J5': (1800, 'raw')}
COMMITS = {'repo': 'c00ebcc984ed354609c7a9e539252402e5329ef3',
           'repo_round2b': '2108acb08c6d5ca1e43c67da2159213f0d36080f'}
FORBIDDEN = re.compile(rb'gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|Authorization:\s*(?:Bearer|Basic)\s+[A-Za-z0-9+/=]{16,}')


def read(path):
    return json.loads(path.read_text())


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(16 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def main():
    stage = OUT / NAME
    stage.mkdir(parents=True, exist_ok=False)

    def put(name, data):
        path = stage / name
        assert path.suffix not in {'.pt', '.npz'} and 'predictions' not in path.parts
        raw = data if isinstance(data, bytes) else (data if isinstance(data, str) else json.dumps(data, indent=2) + '\n').encode()
        assert not FORBIDDEN.search(raw), 'Secret pattern in ' + name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)

    def copy(source, name):
        assert source.is_file() and not source.is_symlink() and source.stat().st_size <= 16 << 20, str(source)
        put(name, source.read_bytes())

    def jsonl(source, count=None):
        rows = deque(maxlen=count)
        if source.is_file():
            with source.open() as stream:
                for line in stream:
                    if line.endswith('\n') and line.strip():
                        rows.append(json.loads(line))
        return list(rows)

    identities = {}
    uids = None
    for checkout, commit in COMMITS.items():
        code = ROOT / checkout / 'vertex/dense_overfit50_20261009'
        head = subprocess.check_output(['git', '-C', str(code), 'rev-parse', 'HEAD'], text=True).strip()
        assert head == commit
        assert subprocess.run(['git', '-C', str(code), 'diff', '--quiet', 'HEAD', '--', '.']).returncode == 0
        manifest_path = code / 'data/prepared_d9/manifest.json'
        manifest = read(manifest_path)
        current = manifest['train_uids']
        assert len(current) == len(set(current)) == len(manifest['records']) == 50
        assert current == [record['uid'] for record in manifest['records']]
        if uids is None:
            uids = current
        assert current == uids
        identities[checkout] = {'commit': head, 'tracked_code_clean': True, 'data_manifest_sha256': sha(manifest_path),
            'code_hashes': {name: sha(code / name) for name in ('dense_train.py', 'common.py', 'packed.py', 'evaluate.py', 'analyze_cascade.py') if (code / name).is_file()}}
    put('source_identity.json', identities)
    eta_path = ROOT / 'status_eta_20261010_1240.json'
    if eta_path.is_file():
        copy(eta_path, 'status_eta_20261010_1240.json')
    expected = {(seed, uid) for seed in (97029000, 97029001) for uid in uids}
    snapshots, validated = {}, {}
    for job, run in RUNS.items():
        folder = ROOT / 'runs' / run
        config = read(folder / 'config.json')
        assert config['uids'] == uids and config['seed'] == 20261010 and config['eval_steps'] == 20
        assert config['max_updates'] == 9000
        snapshot = {'run': run, 'status': read(folder / 'status.json'), 'scope': 'Saved-file snapshot, not a live-pod process check.'}
        for source in sorted(folder.glob('config*.json')) + [folder / 'status.json']:
            copy(source, 'snapshots/' + run + '/' + source.name)
        for name, count in (('train.jsonl', 20), ('probes.jsonl', 10), ('evals.jsonl', None)):
            rows = jsonl(folder / name, count)
            target = name if name == 'evals.jsonl' else name.replace('.jsonl', '_tail.jsonl')
            put('snapshots/' + run + '/' + target, ''.join(json.dumps(row) + '\n' for row in rows))
            if name == 'train.jsonl':
                snapshot['last_train'] = rows[-1] if rows else None
            if name == 'evals.jsonl':
                receipts = {(row['update'], row['weights']): row for row in rows}
                snapshot['latest_completed_receipt'] = rows[-1] if rows else None
        console = ROOT / 'job_logs' / run / 'console-latest.log'
        if console.is_file():
            with console.open('rb') as stream:
                tail = deque(stream, maxlen=40)
            put('snapshots/' + run + '/console_tail.log', b''.join(tail))
        snapshots[job] = snapshot
        if job not in TARGETS:
            continue
        key = TARGETS[job]
        update, weights = key
        assert key in receipts, 'Missing completed target receipt: ' + job
        evaluation = folder / 'evals' / f'u{update:06d}_{weights}'
        summary, scored, generated, progress = [read(evaluation / (name + '.json')) for name in ('summary', 'evaluation', 'generation_manifest', 'progress')]
        assert progress['generated'] == progress['expected'] == summary['trees'] == 100
        assert len(scored['rows']) == len(generated['rows']) == 100
        for record in (summary, scored):
            assert record['update'] == update and record['weights'] == weights and record['run_output'] == str(folder)
        for rows in (scored['rows'], generated['rows']):
            pairs = [(row['seed'], row['uid']) for row in rows]
            assert len(set(pairs)) == 100 and set(pairs) == expected
        metric_keys = ('trees', 'full_trees_exact', 'native_final_sets_exact', 'capacity_abort_trees', 'count_accuracy',
                       'teacher_rule_vs_d9_gt_pass', 'first_mismatch_depth_histogram', 'exact_by_vertex_count', 'per_depth', 'acceptance', 's0_reference')
        assert all(summary[name] == scored[name] for name in metric_keys)
        rows = scored['rows']
        assert summary['full_trees_exact'] == sum(row['all_levels_exact'] for row in rows)
        assert summary['native_final_sets_exact'] == sum(row['native_final_set_exact'] for row in rows)
        assert summary['capacity_abort_trees'] == sum(row['status'] == 'capacity_abort' for row in rows)
        assert summary['count_accuracy'] == sum(row['count_correct'] for row in rows) / 100
        assert summary['first_mismatch_depth_histogram'] == dict(Counter(str(row['first_mismatch_depth']) for row in rows))
        assert summary['acceptance']['passed'] == (summary['full_trees_exact'] == 100)
        for depth in range(1, 10):
            entry = summary['per_depth'][depth - 1]
            assert entry['depth'] == depth
            assert all(len(row['levels']) == 9 and row['levels'][depth - 1]['depth'] == depth for row in rows)
            assert entry['full_level_exact'] == sum(row['levels'][depth - 1]['exact'] for row in rows)
            for name in ('global_cells_tp', 'global_cells_fp', 'global_cells_fn'):
                assert entry[name] == sum(row['levels'][depth - 1][name] for row in rows)
        for low, high, label in ((0, 300, '0-300'), (300, 700, '300-700'), (700, 1200, '700-1200'), (1200, 10**9, '1200+')):
            bucket = [row for row in rows if low <= row['target_n'] < high]
            assert summary['exact_by_vertex_count'][label] == {'trees': len(bucket), 'exact': sum(row['all_levels_exact'] for row in bucket)}
        receipt = receipts[key]
        for name in ('full_trees_exact', 'first_mismatch_depth_histogram', 'exact_by_vertex_count', 'minutes'):
            assert receipt[name] == summary[name]
        assert receipt['per_depth_exact'] == [entry['full_level_exact'] for entry in summary['per_depth']]
        actual_files = {path.name for path in (evaluation / 'predictions').glob('*.npz')}
        assert actual_files == {f'seed-{seed}_{uid}.npz' for seed, uid in expected}
        hash_rows = []
        status_by_pair = {(row['seed'], row['uid']): row['status'] for row in rows}
        for row in generated['rows']:
            path = evaluation / 'predictions' / f"seed-{row['seed']}_{row['uid']}.npz"
            assert not path.is_symlink()
            before = path.stat()
            digest = sha(path)
            after = path.stat()
            assert (before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns)
            assert digest == row['prediction_sha256']
            assert row['status'] == status_by_pair[(row['seed'], row['uid'])]
            hash_rows.append({'seed': row['seed'], 'uid': row['uid'], 'sha256': digest, 'bytes': after.st_size})
        for name in ('summary.json', 'evaluation.json', 'generation_manifest.json', 'progress.json'):
            copy(evaluation / name, 'evaluations/' + run + f'/u{update:06d}_{weights}/' + name)
        put('evaluations/' + run + '/prediction_hashes_verified.json', hash_rows)
        validated[job] = {'run': run, 'update': update, 'weights': weights, 'trees': 100, 'all_prediction_hashes_matched': True,
                          'full_trees_exact': summary['full_trees_exact'], 'per_depth_exact': receipt['per_depth_exact'],
                          'first_mismatch_depth_histogram': summary['first_mismatch_depth_histogram'],
                          'exact_by_vertex_count': summary['exact_by_vertex_count'], 'summary': summary,
                          'canonical_eval_dir': str(evaluation)}
        print('VALIDATED', job, update, weights, summary['full_trees_exact'], 'of 100; all 100 NPZ hashes match', flush=True)
    put('validation.json', validated)
    for name in ('build_milestones009_handoff.py', 'publish_milestones009_handoff.py'):
        if (ROOT / name).is_file():
            copy(ROOT / name, 'helpers/' + name)
    for name in ('run_round2.sh', 'run_round2b.sh') + tuple('run_' + job.lower() + '.sh' for job in RUNS):
        copy(ROOT / 'jobs' / name, 'jobs/' + name)
    result = {'collected_server_utc': datetime.now(timezone.utc).isoformat(), 'snapshots': snapshots, 'validated_milestones': validated,
              'source_identity': identities, 'new_J6_cascade_run': False, 'scope': 'Saved milestone validation and CPU analysis; no training/model/GPU changes.'}
    put('RESULT.json', result)
    message = ['# Codex → Opus: Round2 newly completed milestones', '',
        f'{len(validated)} new raw evaluations passed the fixed50 × two-seed completeness contract and all saved prediction SHA256 checks. Earlier published u1800 results remain separate.', '',
        '| Job | Saved train-tail update | Latest completed receipt | Newly validated | <300 | 300–700 | 700–1200 | 1200+ |',
        '|---|---:|---|---|---:|---:|---:|---:|']
    for job in RUNS:
        item = validated.get(job)
        last = snapshots[job]['last_train'] or {}
        latest = snapshots[job]['latest_completed_receipt'] or {}
        observed = f"u{latest['update']}/{latest['weights']}: {latest['full_trees_exact']}/100" if latest else 'none observed'
        buckets = item['exact_by_vertex_count'] if item else {}
        sizes = [str(buckets[k]['exact']) + '/' + str(buckets[k]['trees']) if k in buckets else 'not collected' for k in ('0-300', '300-700', '700-1200', '1200+')]
        new = f"u{item['update']}/{item['weights']}: {item['full_trees_exact']}/100" if item else 'no new target'
        message.append(f"| {job} | {last.get('update', 'unavailable')} | {observed} | {new} | " + ' | '.join(sizes) + ' |')
    message += ['', 'Compare recipes at equal updates: J5 u1800 differs from J1/J2/J3 u3600. These remain interim results.', '',
        '- All canonical receipts, JSON cohort counts, UID/seed sets, per-depth aggregates, first-error histograms, size buckets and prediction hashes agree.',
        '- Six-job configs, saved statuses, train/probe/console tails, evaluation receipts, code/data hashes and the fresh status_eta_20261010_1240.json are included when present. Saved files do not prove each formal pod live-process state; ETA is an estimate.',
        '- No new J6 milestone was collected; its previously published u1800 CPU cascade was not rerun.',
        '- No checkpoint reads, model/GPU work, training changes or Mac result artifacts. NPZ predictions remain on the server.', '',
        '[Compressed evidence](../evidence/20261010-round2-milestones009/README.md)', '']
    text = '\n'.join(message)
    put('REPORT.md', text)
    (OUT / MESSAGE).write_text(text)
    paths = sorted(path for path in stage.rglob('*') if path.is_file())
    for path in paths:
        assert path.suffix not in {'.pt', '.npz'} and 'predictions' not in path.parts and not FORBIDDEN.search(path.read_bytes())
    put('SHA256SUMS', ''.join(f'{sha(path)}  {path.relative_to(stage)}\n' for path in paths))
    archive = OUT / (NAME + '.tgz')
    with tarfile.open(archive, 'w:gz') as tar:
        for path in sorted(stage.rglob('*')):
            if path.is_file():
                tar.add(path, arcname=NAME + '/' + str(path.relative_to(stage)), recursive=False)
    package = {'file': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive), 'files': len(paths) + 1,
               'validated_milestones': {job: TARGETS[job] for job in validated}, 'new_J6_cascade_run': False, 'excluded': ['*.pt', '*.npz', 'predictions/', 'credentials']}
    assert package['bytes'] < 90 << 20
    (OUT / 'PACKAGE.json').write_text(json.dumps(package, indent=2) + '\n')
    (OUT / 'README.md').write_text('# Round2 milestone009 evidence\n\n[Compressed records](' + archive.name + ') · [Manifest](PACKAGE.json)\n\n'
        f"SHA256: `{package['sha256']}`\n\nVerify archive hash then inner `SHA256SUMS`. No weights or prediction arrays; originals remain on the server.\n")
    print('PACKAGE_READY', json.dumps(package), flush=True)


if __name__ == '__main__':
    main()
