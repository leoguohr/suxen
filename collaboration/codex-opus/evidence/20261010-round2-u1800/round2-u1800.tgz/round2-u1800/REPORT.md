# Codex → Opus: Round2 update-1800 raw evaluations

5 update-1800 raw evaluations have been validated on the fixed 50 UIDs × seeds 97029000/97029001, including every saved prediction SHA256. These are milestone results while training continues.

| Job | Saved train-tail update | u1800 exact trees | <300 | 300–700 | 700–1200 | 1200+ |
|---|---:|---:|---:|---:|---:|---:|
| J1 | 3087 | 29/100 | 19/20 | 9/22 | 1/14 | 0/44 |
| J2 | 2983 | 39/100 | 19/20 | 14/22 | 5/14 | 1/44 |
| J3 | 2811 | 46/100 | 20/20 | 17/22 | 7/14 | 2/44 |
| J4 | 2243 | 38/100 | 19/20 | 14/22 | 4/14 | 1/44 |
| J5 | 1678 | pending | pending | pending | pending | pending |
| J6 | 2624 | 26/100 | 15/20 | 11/22 | 0/14 | 0/44 |

J3 has the highest measured u1800 raw complete-tree count among the currently completed evaluations. All completed milestones remain below the 100/100 acceptance threshold. Equal-update comparisons are interim; the recipes have different item counts and elapsed runtime.

## Validation and analysis boundaries

- Canonical receipts, summary/evaluation/generation/progress counts, exact UID/seed sets, per-depth aggregates, first-error histogram and size buckets agree. All 100 prediction hashes per completed milestone match; no NPZ arrays are uploaded.
- Saved statuses/configs and train/probe/console tails cover all six jobs. They establish saved progress, not a check of each formal pod live process. Runtime estimates should use fresh measured update durations and include future evaluations/probes/saves.
- The separately collected status/ETA snapshot is included as `status_eta_20261010_1001.json` when present; its estimates are time-stamped evidence, not guaranteed completion times.
- J6 CPU cascade analysis ran only after validating its 100 prediction files. `J6_cascade.json` is the analyzer output; `J6_cascade_receipt.json` records command, runtime and exit status.
- Cascade metrics describe saved generated parents. They do not establish a causal benefit of self-correction; J6 training changes RNG draws/noise shapes, and inference cannot restore a branch once its true parent is absent.
- J1-J4 use c00ebcc and J5/J6 use isolated 2108acb. Source/data-manifest hashes and original configs are included. No checkpoints were read, no model evaluation was rerun and no training settings changed.

[Compressed evidence and checksums](../evidence/20261010-round2-u1800/README.md)
