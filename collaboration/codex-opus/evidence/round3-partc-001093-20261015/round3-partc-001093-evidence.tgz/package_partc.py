"""Package the completed CPU diagnosis, excluding model and prediction files."""
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / 'results'
BUNDLE = ROOT / 'publication'


def encoded(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def entry(path, base):
    content = path.read_bytes()
    return {'path': str(path.relative_to(base)), 'bytes': len(content),
            'sha256': hashlib.sha256(content).hexdigest()}


def main():
    assert str(ROOT).startswith('/guohaoran/') and not BUNDLE.exists()
    diagnosis = json.loads((RESULTS / 'diagnosis.json').read_text())
    status = json.loads((RESULTS / 'STATUS.json').read_text())
    assert status['complete'] and status['prediction_files'] == 44
    focus = [18, 31, 35]
    model_values = {}
    for model in ['J5', 'J2']:
        rows = [r for r in diagnosis['predictions'] if r['model'] == model]
        bits = [next(c for c in r['target_cells'] if c['depth6_cell'] == focus) for r in rows]
        assert all(b['parent_present'] for b in bits)
        model_values[model] = {'files': len(rows), 'estimate_min': min(b['estimate'] for b in bits),
                               'estimate_max': max(b['estimate'] for b in bits),
                               'focus_bit_correct': sum(b['predicted_occupied'] for b in bits),
                               'whole_tree_pass': sum(r['tree_pass'] for r in rows)}
    j5rows = [r for r in diagnosis['predictions'] if r['model'] == 'J5']
    sibling_correct = sum(all(c['predicted_occupied'] == bool(c['ground_truth'])
                              for c in next(p for p in r['parent_siblings'] if p['depth5_parent'] == [9,15,17])['children']
                              if c['bit'] != 3) for r in j5rows)
    assert diagnosis['j5_depth6_missing_intersection'] == [focus]
    overview = ('## Main finding\n\n'
        '- The recurring J5 omission is D6 **(18,31,35)**, child bit **3** of D5 parent **(9,15,17)**. '
        'The parent exists in all 32 J5 files; this is a direct occupancy-bit error.\n'
        f'- J5 estimates range from **{model_values["J5"]["estimate_min"]:.9f} to {model_values["J5"]["estimate_max"]:.9f}**, all below 0.5; '
        'the error is not a small threshold-margin miss in these saved outputs.\n'
        f'- J2 recovers this bit in **{model_values["J2"]["focus_bit_correct"]}/12** files '
        f'(estimates {model_values["J2"]["estimate_min"]:.9f}–{model_values["J2"]["estimate_max"]:.9f}); '
        f'whole-tree exact is **{model_values["J2"]["whole_tree_pass"]}/12**, because other cells can fail.\n'
        f'- The other seven child bits of the same parent are all correct in **{sibling_correct}/32** J5 files. '
        'GT vector: `[0,1,0,1,0,0,0,0]`.\n'
        '- This D6 cell contains **2 unique float vertices / 2 D9 cells**: `(145,250,285)` and `(148,250,282)`. '
        'Nearest outside float-GT distances are **8.114519596** and **9.106945654** D9 cell widths; '
        'integer-D9 distances are **8** and **9.055385138**. The five D9 collision losses occur elsewhere.\n'
        '- Missing-cell sets are not identical in every file: J5 2-step seed97029009 additionally misses `(6,30,55)` directly; '
        'J5 20-step seed97029004 additionally loses `(22,32,13)`, `(23,32,12)`, `(23,33,12)` through an absent D5 parent.\n'
        '- The target bit is present in the actual prepared D9 label and its frozen CPU octree encoding; '
        'D9 files in both original training checkouts have the same verified hash.\n'
        '- These results establish a stable local J5 error and a successful J2 comparison. '
        'They do not identify its training cause or justify a model/loss change by themselves.\n\n')
    # Check summary statements against the complete derived result before publishing.
    assert sibling_correct == 32 and model_values['J5']['focus_bit_correct'] == 0
    assert model_values['J2']['focus_bit_correct'] == 12 and model_values['J2']['whole_tree_pass'] == 7
    geometry = next(g for g in diagnosis['ground_truth_under_missing_cells'] if g['depth6_cell'] == focus)
    assert geometry['unique_float_vertices'] == geometry['depth9_cell_count'] == 2
    for seed, steps, expected in [(97029009, 2, 'direct_bit_miss'), (97029004, 20, 'inherited_missing_parent')]:
        row = next(r for r in j5rows if r['seed'] == seed and r['steps'] == steps)
        other = [c for c in row['target_cells'] if c['depth6_cell'] != focus and c['depth6_cell'] in row['depth6_missing']]
        assert other and all(c['omission_kind'] == expected for c in other)
    stage, payload = BUNDLE / 'archive_contents', BUNDLE / 'payload'
    stage.mkdir(parents=True)
    payload.mkdir()
    for name in ['diagnosis.json', 'INPUT_MANIFEST.json', 'STATUS.json']:
        shutil.copy2(RESULTS / name, stage / name)
    report = (RESULTS / 'REPORT.md').read_text()
    report = report.replace('# Round3 Part C: 001093 diagnosis\n\n', '# Round3 Part C: 001093 diagnosis\n\n' + overview, 1)
    (stage / 'REPORT.md').write_text(report)
    for name in ['diagnose_001093.py', 'package_partc.py', 'publish_partc.py', 'diagnosis.log']:
        shutil.copy2(ROOT / name, stage / name)
    command = ('cd ' + str(ROOT) + '\n'
        'CUDA_VISIBLE_DEVICES= PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION=python OMP_NUM_THREADS=8 '
        'PYTHONDONTWRITEBYTECODE=1 /guohaoran/envs/nexus-algo/bin/python -u diagnose_001093.py '
        '--output ' + str(RESULTS) + ' > diagnosis.log 2>&1\n')
    (stage / 'EXECUTION.txt').write_text(command + '\nExecuted successfully, exit code 0. CPU only. No model checkpoint tensors loaded.\n')
    (stage / 'CODE_REFERENCES.md').write_text('''# Frozen source references

Commit: e7e3a326a65bc550be695104ae69e0d3435bd446. Paths below are under vertex/dense_overfit50_20261009/.

- common.py:25: xyz child bit order.
- common.py:52–76: manifest/hash-bound labels and actual build_octree_levels training target construction.
- common.py:125–133: own-parent rollout, inclusive estimate >=0.5 threshold and saved continuous values.
- common.py:165–198: per-depth truth and full-tree success definition.
- common.py:276–278: saved NPZ fields.
- vendor/mini_nexus/octree.py:83–109: child index and occupancy expansion.
- analyze_boundary.py:30–47: D15-to-D9 shift and cell-width conventions.

The new script invokes the frozen octree builder on CPU and independently checks each saved parent expansion, threshold and whole-tree result. The repository is unchanged; all source/input hashes are in INPUT_MANIFEST.json.
''')
    files = sorted(p for p in stage.rglob('*') if p.is_file())
    assert all(p.suffix not in ['.pt', '.pth', '.npz'] for p in files)
    manifest = [entry(p, stage) for p in files]
    (payload / 'FILE_MANIFEST.json').write_bytes(encoded(manifest))
    archive = payload / 'round3-partc-001093-evidence.tgz'
    with tarfile.open(archive, 'w:gz') as tar:
        for p in files:
            tar.add(p, arcname=str(p.relative_to(stage)), recursive=False)
    for name in ['REPORT.md', 'STATUS.json']:
        shutil.copy2(stage / name, payload / name)
    (BUNDLE / 'UPLOAD_MANIFEST.json').write_bytes(encoded([entry(p, payload) for p in sorted(payload.iterdir())]))
    print(json.dumps({'bundle': str(BUNDLE), 'archive_bytes': archive.stat().st_size,
                      'focus': model_values, 'sibling_seven_correct_files': sibling_correct}))


if __name__ == '__main__':
    main()
