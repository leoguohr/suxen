# Frozen source references

Commit: e7e3a326a65bc550be695104ae69e0d3435bd446. Paths below are under vertex/dense_overfit50_20261009/.

- common.py:25: xyz child bit order.
- common.py:52–76: manifest/hash-bound labels and actual build_octree_levels training target construction.
- common.py:125–133: own-parent rollout, inclusive estimate >=0.5 threshold and saved continuous values.
- common.py:165–198: per-depth truth and full-tree success definition.
- common.py:276–278: saved NPZ fields.
- vendor/mini_nexus/octree.py:83–109: child index and occupancy expansion.
- analyze_boundary.py:30–47: D15-to-D9 shift and cell-width conventions.

The new script invokes the frozen octree builder on CPU and independently checks each saved parent expansion, threshold and whole-tree result. The repository is unchanged; all source/input hashes are in INPUT_MANIFEST.json.
