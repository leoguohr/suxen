"""CPU-only read-only diagnosis of the requested saved Vertex Diffusion arrays."""
import argparse
from collections import Counter
import datetime
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys

import numpy as np

UID = 'nexus_2k_001093'
OFFSETS = np.array([[i >> 2 & 1, i >> 1 & 1, i & 1] for i in range(8)], dtype=np.int64)
SOURCE = Path('/guohaoran/tmp/nexus_vertex_round3_batch2A_eval_20261015/repo')
WORK = SOURCE / 'vertex/dense_overfit50_20261009'
ROUND2 = Path('/guohaoran/tmp/nexus_vertex_dense_round2_20261009')
BATCH1 = Path('/guohaoran/tmp/nexus_round3_eval_20261015/round3_eval')
BATCH2 = Path('/guohaoran/tmp/nexus_vertex_round3_batch2A_eval_20261015/round3_sweep')
EXPECTED_COMMIT = 'e7e3a326a65bc550be695104ae69e0d3435bd446'


def cells(array):
    return set(map(tuple, np.asarray(array, dtype=np.int64).reshape(-1, 3).tolist()))


def coords(values):
    return [list(v) for v in sorted(values)]


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    out = args.output.resolve()
    assert str(out).startswith('/guohaoran/') and os.environ.get('CUDA_VISIBLE_DEVICES') == ''
    out.mkdir(parents=True, exist_ok=True)
    assert not (out / 'diagnosis.json').exists(), 'Do not overwrite an earlier diagnosis'
    git = lambda *a: subprocess.check_output(['git', *a], cwd=SOURCE, text=True).strip()
    assert git('rev-parse', 'HEAD') == EXPECTED_COMMIT and git('status', '--porcelain') == ''
    inventory = {}

    def read(path, kind):
        path = Path(path)
        content = path.read_bytes()
        inventory[str(path)] = {'path': str(path), 'kind': kind, 'bytes': len(content),
                                'sha256': hashlib.sha256(content).hexdigest()}
        return content

    def read_json(path, kind):
        return json.loads(read(path, kind))

    def read_npz(path, kind):
        with np.load(io.BytesIO(read(path, kind)), allow_pickle=False) as data:
            return {k: data[k].copy() for k in data.files}

    manifest = read_json(WORK / 'data/prepared_d9/manifest.json', 'training_manifest')
    record = next(r for r in manifest['records'] if r['uid'] == UID)
    label_path = WORK / 'data/prepared_d9' / record['label_file']
    source_path = WORK / 'data' / record['source_label_file']
    d9 = read_npz(label_path, 'training_d9_label')
    d15 = read_npz(source_path, 'source_d15_label')
    assert inventory[str(label_path)]['sha256'] == record['label_sha256']
    assert inventory[str(source_path)]['sha256'] == record['source_label_sha256']
    assert int(d9['depth']) == 9 and int(d15['depth']) == 15
    q9, q15 = d9['leaves'], d15['leaves']
    mapped9, mapped15 = q9[d9['original_to_leaf']], q15[d15['original_to_leaf']]
    assert np.array_equal(mapped9, mapped15 >> 6) and np.array_equal(mapped15, d15['raw'])
    xyz, first, inverse, multiplicity = np.unique(d15['gt_normalized'], axis=0,
                                                return_index=True, return_inverse=True, return_counts=True)
    xyz = xyz.astype(np.float64)
    xyzq9, xyzq15 = mapped9[first], mapped15[first]
    assert np.array_equal(mapped9, xyzq9[inverse]) and np.array_equal(mapped15, xyzq15[inverse])
    requantized = np.floor((d15['gt_normalized'].astype(np.float64) + 1) * 256).clip(0, 511).astype(np.int64)
    assert np.array_equal(requantized, mapped9)
    truths = {depth: cells(q9 >> (9 - depth)) for depth in range(1, 10)}

    # Invoke the frozen training label builder on CPU, without importing a model.
    import torch
    octree_path = WORK / 'vendor/mini_nexus/octree.py'
    read(octree_path, 'frozen_source')
    spec = importlib.util.spec_from_file_location('partc_frozen_octree', octree_path)
    octree = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = octree
    spec.loader.exec_module(octree)
    native = octree.build_octree_levels(torch.from_numpy(q9.copy()), 9)[5]
    gtparents, gttarget = native.parent_codes.numpy(), native.target.numpy()
    assert cells((gtparents[:, None] * 2 + OFFSETS)[gttarget.astype(bool)]) == truths[6]
    for n in ['common.py', 'evaluate.py', 'dense_train.py', 'analyze_boundary.py', 'analyze_cascade.py']:
        read(WORK / n, 'frozen_source')

    training_configs = {}
    training_label_copies = []
    for model, job in [('J5', 'J5_token_fine2'), ('J2', 'J2_token')]:
        config = read_json(ROUND2 / 'runs' / job / 'config.json', 'training_config')
        assert UID in config['uids']
        training_configs[model] = {'uid_in_training': True, 'max_updates': config['max_updates'],
                                  'eval_steps': config['eval_steps'], 'loss_weighting': config['loss_weighting'],
                                  'fine_copies': config.get('fine_copies', 1), 'seed': config['seed']}
    for p in sorted(ROUND2.glob('repo*/vertex/dense_overfit50_20261009/data/prepared_d9/' + UID + '.npz')):
        read(p, 'training_checkout_label_copy')
        assert inventory[str(p)]['sha256'] == record['label_sha256']
        training_label_copies.append(inventory[str(p)])

    groups = [
        ('J5', 1, Path('/guohaoran/tmp/nexus_vertex_dense_round2c_20261010/decode_test/J5_token_fine2_ema_s1'), [97029000, 97029001]),
        ('J5', 2, BATCH2 / 'steps02_ema', list(range(97029000, 97029010))),
        ('J5', 5, BATCH2 / 'steps05_ema', list(range(97029000, 97029010))),
        ('J5', 20, ROUND2 / 'runs/J5_token_fine2/evals/u009000_ema', [97029000, 97029001]),
        ('J2', 5, BATCH1 / 'J2_ema_euler5_official', [97029000, 97029001]),
        ('J2', 20, ROUND2 / 'runs/J2_token/evals/u009000_ema', [97029000, 97029001]),
    ]
    for model in ['J5', 'J2']:
        for seed in range(97029002, 97029010, 2):
            groups.append((model, 20, BATCH1 / f'{model}_ema_euler20_seeds{seed}_{seed+1}', [seed, seed+1]))
    predictions = []
    arrays = {}
    for model, steps, folder, seeds in groups:
        evaluation = read_json(folder / 'evaluation.json', 'saved_evaluation')
        assert evaluation['weights'] == 'ema' and evaluation['update'] == 9000
        assert evaluation.get('steps_per_depth', steps) == steps
        assert evaluation.get('sampler', 'euler') == 'euler'
        expected_names = {f'seed-{s}_{UID}.npz' for s in seeds}
        assert {p.name for p in (folder / 'predictions').glob(f'seed-*_{UID}.npz')} == expected_names
        for seed in seeds:
            path = folder / 'predictions' / f'seed-{seed}_{UID}.npz'
            a = read_npz(path, 'prediction_input_not_uploaded')
            row = next(r for r in evaluation['rows'] if r['uid'] == UID and r['seed'] == seed)
            levels = []
            for depth in range(1, 10):
                p, occ, est = [a[f'depth{depth}_{key}'] for key in ['parents', 'occupancy', 'estimate']]
                assert p.shape == (len(p), 3) and len(cells(p)) == len(p)
                assert occ.shape == (len(p), 8) and est.shape == (1, len(p), 8)
                assert np.isfinite(est).all() and np.array_equal(est[0] >= .5, occ)
                generated = cells((p[:, None] * 2 + OFFSETS)[occ.astype(bool)])
                if depth > 1:
                    assert cells(p) == previous, 'Saved own-parent expansion is inconsistent'
                else:
                    assert cells(p) == {(0, 0, 0)}
                levels.append({'depth': depth, 'missing': coords(truths[depth] - generated),
                               'extra': coords(generated - truths[depth]), 'exact': generated == truths[depth]})
                previous = generated
            all_exact = all(x['exact'] for x in levels)
            first_mismatch = next((x['depth'] for x in levels if not x['exact']), None)
            assert all_exact == row['all_levels_exact']
            assert first_mismatch == row['first_mismatch_depth']
            assert levels[-1]['exact'] == row['native_final_set_exact']
            key = f'{model}_s{steps}_{seed}'
            assert key not in arrays
            arrays[key] = a
            predictions.append({'id': key, 'model': model, 'steps': steps, 'seed': seed,
                                'file': str(path), 'sha256': inventory[str(path)]['sha256'],
                                'saved_evaluation_checkpoint': evaluation.get('checkpoint'),
                                'saved_evaluation_checkpoint_sha256': evaluation.get('checkpoint_sha256'),
                                'weights': 'ema', 'update': 9000, 'tree_pass': all_exact,
                                'final_leaf_set_exact': levels[-1]['exact'], 'first_mismatch_depth': first_mismatch,
                                'predicted_n': row['predicted_n'], 'depth6_missing': levels[5]['missing'],
                                'depth6_extra': levels[5]['extra'], 'per_depth': levels})
    predictions.sort(key=lambda r: (r['model'], r['steps'], r['seed']))
    assert Counter(r['model'] for r in predictions) == {'J5': 32, 'J2': 12}
    missing_sets = [cells(r['depth6_missing']) for r in predictions if r['model'] == 'J5']
    union, intersection = set.union(*missing_sets), set.intersection(*missing_sets)
    assert union, 'Requested suspected missing cell not present in these arrays'
    parent_keys = sorted({tuple(int(x) // 2 for x in c) for c in union})
    geometry = []
    for c in sorted(union):
        c_array = np.array(c)
        inside = np.all((xyzq9 >> 3) == c_array, axis=1)
        outside_ids = np.flatnonzero(~inside)
        gt9inside = np.array(sorted(v for v in cells(q9) if tuple(np.array(v) >> 3) == c))
        gt9outside = np.array(sorted(v for v in cells(q9) if tuple(np.array(v) >> 3) != c))
        unique_vertices = []
        for i in np.flatnonzero(inside):
            ds = np.linalg.norm(xyz[outside_ids] - xyz[i], axis=1) * 256
            nearest = outside_ids[int(ds.argmin())]
            di = np.linalg.norm(gt9outside - xyzq9[i], axis=1)
            nearest_q = gt9outside[int(di.argmin())]
            unique_vertices.append({'unique_float_vertex_index': int(i), 'original_record_index': int(first[i]),
                                    'original_record_multiplicity': int(multiplicity[i]),
                                    'xyz_normalized': xyz[i].tolist(), 'depth15_cell': xyzq15[i].tolist(),
                                    'depth9_cell': xyzq9[i].tolist(),
                                    'nearest_outside_float_distance_d9_units': float(ds.min()),
                                    'nearest_outside_float_xyz': xyz[nearest].tolist(),
                                    'nearest_outside_float_depth9_cell': xyzq9[nearest].tolist(),
                                    'nearest_outside_integer_d9_distance': float(di.min()),
                                    'nearest_outside_integer_d9_cell': nearest_q.tolist()})
        parent = c_array // 2
        bit = int((c_array % 2) @ np.array([4, 2, 1]))
        idx = np.flatnonzero(np.all(gtparents == parent, axis=1))
        assert len(idx) == 1 and gttarget[idx[0], bit] == 1
        geometry.append({'depth6_cell': list(c), 'depth5_parent': parent.tolist(), 'child_bit': bit,
                         'training_target': float(gttarget[idx[0], bit]),
                         'unique_float_vertices': int(inside.sum()), 'raw_records': int(multiplicity[inside].sum()),
                         'depth9_cell_count': len(gt9inside), 'depth9_cells': gt9inside.tolist(),
                         'vertices': unique_vertices})
    for row in predictions:
        a = arrays[row['id']]
        p, est = a['depth6_parents'], a['depth6_estimate'][0]
        row['parent_siblings'] = []
        row['target_cells'] = []
        for parent in parent_keys:
            matches = np.flatnonzero(np.all(p == np.array(parent), axis=1))
            assert len(matches) <= 1
            e = est[matches[0]] if len(matches) else None
            children = np.array(parent) * 2 + OFFSETS
            siblings = [{'bit': i, 'depth6_cell': c.tolist(), 'ground_truth': int(tuple(c) in truths[6]),
                         'estimate': float(e[i]) if e is not None else None,
                         'predicted_occupied': bool(e[i] >= .5) if e is not None else None}
                        for i, c in enumerate(children)]
            row['parent_siblings'].append({'depth5_parent': list(parent), 'parent_present': e is not None,
                                           'row_index': int(matches[0]) if len(matches) else None, 'children': siblings})
            for s in siblings:
                if tuple(s['depth6_cell']) in union:
                    row['target_cells'].append(s | {'depth5_parent': list(parent), 'parent_present': e is not None,
                        'omission_kind': 'inherited_missing_parent' if e is None else
                                         ('direct_bit_miss' if s['ground_truth'] and not s['predicted_occupied'] else 'not_missing')})
    counts = []
    for model, steps in sorted({(r['model'], r['steps']) for r in predictions}):
        rows = [r for r in predictions if (r['model'], r['steps']) == (model, steps)]
        counts.append({'model': model, 'steps': steps, 'files': len(rows), 'tree_pass': sum(r['tree_pass'] for r in rows),
                       'missing_cells': [{'cell': list(c), 'files_missing': sum(c in cells(r['depth6_missing']) for r in rows)}
                                         for c in sorted(union)]})
    training = {'manifest_record': record, 'd9_label_path': str(label_path), 'd15_source_path': str(source_path),
                'd9_label_sha256': record['label_sha256'], 'd15_label_sha256': record['source_label_sha256'],
                'raw_records': len(mapped9), 'unique_float_vertices': len(xyz), 'd15_leaves': len(q15),
                'd9_leaves': len(q9), 'd9_collision_reduction': len(xyz)-len(q9),
                'mapping_d15_to_d9_equal': True, 'requantized_stored_float_to_d9_equal': True,
                'frozen_build_octree_levels_cpu_checked': True, 'configs': training_configs,
                'training_checkout_label_copies': training_label_copies}
    result = {'title': 'Round3 Part C: 001093 diagnosis', 'uid': UID,
              'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'scope': 'CPU-only saved-array analysis; no model forward, GPU, training or repository edits',
              'code_commit': EXPECTED_COMMIT, 'prediction_files': len(predictions), 'training_label': training,
              'j5_depth6_missing_union': coords(union), 'j5_depth6_missing_intersection': coords(intersection),
              'j5_identical_complete_missing_set_every_file': all(s == missing_sets[0] for s in missing_sets),
              'group_summary': counts, 'ground_truth_under_missing_cells': geometry, 'predictions': predictions,
              'formulas': {'child': '2*depth5_parent + [bit>>2&1,bit>>1&1,bit&1]',
                           'target_depth6': 'unique(d9_leaves >> 3)', 'threshold': 'estimate >= 0.5',
                           'primary_distance': 'min_{u outside same depth6 cell} ||GTfloat(v)-GTfloat(u)||_2 * 256',
                           'secondary_distance': 'min_{q outside same depth6 cell} ||q9(v)-q9(u)||_2'},
              'limitations': ['Distances use stored normalized GT (float32 promoted to float64), not reread original CAD.',
                              'Different step counts/seeds are observed saved trajectories; identical actual noise by coordinate is not asserted.',
                              'No new model replay or checkpoint tensor loading; null saved checkpoint SHA remains null.',
                              'Depth9 collision reduction is reported separately and is not evidence of the cause of a missing depth6 bit.']}
    assert git('status', '--porcelain') == ''
    write(out / 'diagnosis.json', result)
    write(out / 'INPUT_MANIFEST.json', list(inventory.values()))
    status = {'complete': True, 'uid': UID, 'j5_files': 32, 'j2_files': 12, 'prediction_files': 44,
              'all_saved_thresholds_verified': True, 'all_tree_pass_values_recomputed': True,
              'all_saved_parent_expansions_verified': True, 'training_label_hashes_verified': True,
              'repository_unchanged': True, 'gpu_used': False, 'training_started': False,
              'same_persistent_missing_cells': coords(intersection)}
    write(out / 'STATUS.json', status)
    lines = ['# Round3 Part C: 001093 diagnosis', '',
             '- Completed CPU-only analysis of 44 saved predictions: J5 32, J2 12. No model replay or training.',
             f'- Frozen reference: `{EXPECTED_COMMIT}`. Input hashes and exact paths: `INPUT_MANIFEST.json`.',
             f'- J5 cells missing in EVERY supplied file: `{coords(intersection)}`.',
             f'- Identical full missing-cell set across every file: **{result["j5_identical_complete_missing_set_every_file"]}**. All missing cells: `{coords(union)}`.',
             '- Missing parents are inherited omissions with null estimates; no zero value is fabricated.', '',
             '## Training labels and distances', '',
             f'- Training manifest contains {UID}; actual frozen `build_octree_levels` on CPU confirms every listed target bit equals 1.',
             f'- Raw records {len(mapped9)}; unique float vertices {len(xyz)}; D15 leaves {len(q15)}; D9 leaves {len(q9)}; D9 collision reduction {len(xyz)-len(q9)}.',
             '- D9/source hashes match the manifest; saved mappings and direct float64 D9 quantization agree.',
             '- Primary distance: Euclidean distance between stored normalized float GT vertices, multiplied by 256 (one D9 cell width is 2/512). Outside means outside the entire specified D6 cell.',
             '- Integer-D9 distance is also supplied, with the nearest outside point/cell; it is a separate metric.', '']
    for g in geometry:
        lines += [f'### Cell {g["depth6_cell"]}; parent {g["depth5_parent"]}; bit {g["child_bit"]}', '',
                  f'- GT: {g["unique_float_vertices"]} unique vertices, {g["raw_records"]} raw records, {g["depth9_cell_count"]} D9 cells; training target={g["training_target"]}.', '',
                  '| GT D9 cell | Nearest outside float distance (D9 units) | Nearest outside integer-D9 distance |',
                  '|---|---:|---:|']
        for v in g['vertices']:
            lines.append(f'| {v["depth9_cell"]} | {v["nearest_outside_float_distance_d9_units"]:.9f} | {v["nearest_outside_integer_d9_distance"]:.9f} |')
        lines += ['']
    lines += ['## Every-file target estimates and tree outcome', '',
              'Tree pass is all nine level sets exact, recomputed from saved occupancy arrays and checked against existing evaluation.json.', '']
    for c in sorted(union):
        lines += [f'### D6 cell {list(c)}', '', '| Model | Steps | Seed | Estimate | Occupied | Omission | Whole-tree pass | First mismatch |',
                  '|---|---:|---:|---:|---|---|---|---:|']
        for r in predictions:
            v = next(x for x in r['target_cells'] if x['depth6_cell'] == list(c))
            est = f'{v["estimate"]:.9f}' if v['estimate'] is not None else 'not evaluated'
            lines.append(f'| {r["model"]} | {r["steps"]} | {r["seed"]} | {est} | {v["predicted_occupied"]} | {v["omission_kind"]} | {r["tree_pass"]} | {r["first_mismatch_depth"]} |')
        lines += ['']
    lines += ['## All sibling bits for each affected parent', '', 'Bit order: 000,001,010,011,100,101,110,111 (x,y,z). Each vector includes the target bit and the other seven bits.', '']
    for parent in parent_keys:
        truth = [int(tuple(np.array(parent)*2 + off) in truths[6]) for off in OFFSETS]
        lines += [f'### Parent {list(parent)}; GT bits {truth}', '',
                  '| J5 steps | Seed | Eight final estimates (bit 0 through 7) |', '|---:|---:|---|']
        for r in predictions:
            if r['model'] != 'J5': continue
            p = next(p for p in r['parent_siblings'] if p['depth5_parent'] == list(parent))
            es = ', '.join(f'{v["estimate"]:.9f}' for v in p['children']) if p['parent_present'] else 'Parent absent: all eight not evaluated'
            lines.append(f'| {r["steps"]} | {r["seed"]} | {es} |')
        lines += ['']
    lines += ['## Evidence boundary', ''] + ['- '+v for v in result['limitations']]
    lines += ['', 'Only derived tables, logs, hashes and this independent script are uploaded. Original .npz predictions, labels and checkpoints stay on the server.', '']
    (out / 'REPORT.md').write_text('\n'.join(lines))
    print(json.dumps({'status': status, 'groups': counts, 'geometry': geometry}, allow_nan=False), flush=True)


if __name__ == '__main__':
    main()
