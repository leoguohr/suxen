# Executed launch record

Base commit: `239140421d5392f905e61c3b6011100e066e1c61` on `vertex-dense-overfit50-20261009`.
Effective code is base plus `execution/dense_train_vs_2391404.patch`; coordinator and backup worker are external scripts.

## Commands and effective settings

Inherited environment: `PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION=python OMP_NUM_THREADS=8 NEXUS_SKIP_COARSE_PROBES=1`.
`T=102` minutes per run; no explicit chunk override (default 8192); save-optimizer default 1; save-minutes default 60; row-tokens 4096; checkpoint-activations 1.
Fresh AdamW (wd=0), warmup50, EMA=.995, clip1, objects/update=8, BF16 network and FP32 model/Adam. All start from S0 weights independently.

```sh
nohup /guohaoran/envs/nexus-algo/bin/python -u run_four.py --train-minutes 102 --clock-offset-seconds 276 > coordinator.log 2>&1 < /dev/null &
```

## Per-process commands, GPU and times

Recorded training-host Unix timestamps are retained in coordinator.json. UTC below adds the measured +276s clock correction. Durations use elapsed time. Local Singapore time is UTC+08:00.

### A_train

- GPU: NVIDIA A100-SXM4-80GB; `GPU-10bebca7-76a1-7fcf-f5ea-5d280851a9f9`.
- Corrected UTC start: 2026-10-09T09:00:11.552997+00:00; end: 2026-10-09T10:44:52.017326+00:00.
- Return code: 0; state: complete.
```sh
/guohaoran/envs/nexus-algo/bin/python -u dense_train.py --init /tmp/nexus_vertex_dense_overfit50_20261009/checkpoint-034000.pt --init-sha skip --output /tmp/nexus_vertex_dense_overfit50_20261009/A --lr 1e-5 --coarse-copies 4 --train-minutes 102
```

### B_train

- GPU: NVIDIA A100-SXM4-80GB; `GPU-4db14efb-13b4-ec8b-bcba-670816c5837f`.
- Corrected UTC start: 2026-10-09T09:00:11.936423+00:00; end: 2026-10-09T10:44:52.025791+00:00.
- Return code: 0; state: complete.
```sh
/guohaoran/envs/nexus-algo/bin/python -u dense_train.py --init /tmp/nexus_vertex_dense_overfit50_20261009/checkpoint-034000.pt --init-sha skip --output /tmp/nexus_vertex_dense_overfit50_20261009/B --lr 3e-5 --coarse-copies 4 --train-minutes 102
```

### C_train

- GPU: NVIDIA A100-SXM4-80GB; `GPU-80f199d2-afab-fad3-824d-6d2482a4c882`.
- Corrected UTC start: 2026-10-09T09:00:12.695921+00:00; end: 2026-10-09T10:44:51.495865+00:00.
- Return code: 0; state: complete.
```sh
/guohaoran/envs/nexus-algo/bin/python -u dense_train.py --init /tmp/nexus_vertex_dense_overfit50_20261009/checkpoint-034000.pt --init-sha skip --output /tmp/nexus_vertex_dense_overfit50_20261009/C --lr 1e-4 --coarse-copies 4 --train-minutes 102
```

### D_train

- GPU: NVIDIA A100-SXM4-80GB; `GPU-0634fd68-4a4d-facb-1b7f-0f9789679b47`.
- Corrected UTC start: 2026-10-09T09:00:12.784693+00:00; end: 2026-10-09T10:44:52.531444+00:00.
- Return code: 0; state: complete.
```sh
/guohaoran/envs/nexus-algo/bin/python -u dense_train.py --init /tmp/nexus_vertex_dense_overfit50_20261009/checkpoint-034000.pt --init-sha skip --output /tmp/nexus_vertex_dense_overfit50_20261009/D --lr 3e-5 --coarse-copies 8 --train-minutes 102
```

### C_raw

- GPU: NVIDIA A100-SXM4-80GB; `GPU-80f199d2-afab-fad3-824d-6d2482a4c882`.
- Corrected UTC start: 2026-10-09T10:44:51.497385+00:00; end: 2026-10-09T11:03:07.206903+00:00.
- Return code: 0; state: complete.
```sh
/guohaoran/envs/nexus-algo/bin/python -u evaluate.py --checkpoint /tmp/nexus_vertex_dense_overfit50_20261009/C/final.pt --weights raw --output /tmp/nexus_vertex_dense_overfit50_20261009/C/eval_raw
```

### A_raw

- GPU: NVIDIA A100-SXM4-80GB; `GPU-10bebca7-76a1-7fcf-f5ea-5d280851a9f9`.
- Corrected UTC start: 2026-10-09T10:44:52.018454+00:00; end: 2026-10-09T11:03:12.213259+00:00.
- Return code: 0; state: complete.
```sh
/guohaoran/envs/nexus-algo/bin/python -u evaluate.py --checkpoint /tmp/nexus_vertex_dense_overfit50_20261009/A/final.pt --weights raw --output /tmp/nexus_vertex_dense_overfit50_20261009/A/eval_raw
```

### B_raw

- GPU: NVIDIA A100-SXM4-80GB; `GPU-4db14efb-13b4-ec8b-bcba-670816c5837f`.
- Corrected UTC start: 2026-10-09T10:44:52.026864+00:00; end: 2026-10-09T11:03:18.221400+00:00.
- Return code: 0; state: complete.
```sh
/guohaoran/envs/nexus-algo/bin/python -u evaluate.py --checkpoint /tmp/nexus_vertex_dense_overfit50_20261009/B/final.pt --weights raw --output /tmp/nexus_vertex_dense_overfit50_20261009/B/eval_raw
```

### D_raw

- GPU: NVIDIA A100-SXM4-80GB; `GPU-0634fd68-4a4d-facb-1b7f-0f9789679b47`.
- Corrected UTC start: 2026-10-09T10:44:52.533293+00:00; end: 2026-10-09T11:04:14.294841+00:00.
- Return code: 0; state: complete.
```sh
/guohaoran/envs/nexus-algo/bin/python -u evaluate.py --checkpoint /tmp/nexus_vertex_dense_overfit50_20261009/D/final.pt --weights raw --output /tmp/nexus_vertex_dense_overfit50_20261009/D/eval_raw
```

### D_ema

- GPU: NVIDIA A100-SXM4-80GB; `GPU-0634fd68-4a4d-facb-1b7f-0f9789679b47`.
- Corrected UTC start: 2026-10-09T11:04:14.296005+00:00; end: 2026-10-09T11:22:15.421654+00:00.
- Return code: 0; state: complete.
```sh
/guohaoran/envs/nexus-algo/bin/python -u evaluate.py --checkpoint /tmp/nexus_vertex_dense_overfit50_20261009/D/final.pt --weights ema --output /tmp/nexus_vertex_dense_overfit50_20261009/D/eval_ema
```

## Hardware and storage snapshots

The original four-GPU query is `launch_gpu_snapshot.json`; raw original `nvidia-smi -L` text was not retained, so it is not reconstructed as an executed command.
Original launch disk snapshot: `disk_check_2391404.log`. Collection-host `nvidia-smi -L` and `df -h`: `current_host_gpu_and_disk.txt` (new host with one GPU; no GPU computation was run during collection).

## Gate execution and deviations

- Initial CPU gate failed at protobuf/ONNX lazy import; upstream commit 2391404 set PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION=python.
- CPU default SDPA produced nonfinite values. Original full CPU suite passed under a CPU-only math SDP wrapper; GPU training backend was not forced to math.
- First GPU preflight stalled loading shared-filesystem mmap; restarted from a byte-identical, SHA-verified NVMe copy before any preflight update.
- Second GPU preflight matched S0 coarse counts [49,43,30,16,9] and completed TWO finite updates. The runner interrupted it before the required third update; no full PREFLIGHT_OK.
- The runner misinterpreted a user question and set NEXUS_SKIP_COARSE_PROBES=1, skipping all initial, periodic and final coarse probes. This was NOT an explicit user request to suppress probes. Raw historical logs incorrectly attribute it to the user; preserved unchanged here, corrected by this note.
- Four runs used four A100-SXM4-80GB GPUs on one host rather than two hosts. A/B/C ended at 749 updates and D at 608 under the same 102-minute budget; this is not equal-update training.
- All four training runs, all four raw evaluations and D EMA exited successfully. A/B/C EMA was never launched because remaining time was insufficient. No actual training restart, crash, OOM or nonfinite training record was found.
- Persistent SSD quota prevented using /ssdwork initially. Training wrote to /tmp; a background atomic-copy worker preserved files in /guohaoran with destination checkpoint hash readback. No old user files were deleted.
- Source checkpoint SHA fields in final.pt are literally skip because --init-sha skip was used after separate SHA verification. Identity comes from the separate verification logs and manifests.
- Saved checkpoints contain model, EMA, AdamW, update and args, but no RNG or scheduler state. The supplied trainer --init loads weights and creates fresh AdamW/EMA at update zero; it is not a complete-state resume interface.
- Teacher-style acceptance aggregate in summary.json is against decoded D9 GT centers. evaluation.json separately contains unique_float_gt_xyz. These are distinct references; no CAD50 generation claim is made.
