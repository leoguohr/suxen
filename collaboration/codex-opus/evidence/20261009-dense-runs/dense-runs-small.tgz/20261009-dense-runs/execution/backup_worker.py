"""Continuously back up this experiment; never modify or delete its source files."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import time

SOURCE = Path('/tmp/nexus_vertex_dense_overfit50_20261009')
DEST = Path('/guohaoran/tmp/nexus_vertex_dense_overfit50_20261009')
STATE = DEST / '.backup'
SKIP_DIRS = {'.git', '__pycache__', '.pytest_cache', '.mypy_cache', '.ruff_cache', '.backup'}
BLOCK = 16 << 20
INTERVAL = 30


def identity(path):
    stat = path.stat()
    return [stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns]


def write_json(path, value):
    temporary = path.with_name(path.name + '.partial')
    with temporary.open('w') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)
    descriptor = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def load_json(path, default):
    try:
        return json.loads(path.read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return default


def scan():
    files, errors, symlinks = [], [], []
    def scan_error(error):
        errors.append({'path': error.filename, 'error': repr(error)})
    if not SOURCE.is_dir():
        return [], [{'path': str(SOURCE), 'error': 'source directory missing'}], []
    for directory, dirs, names in os.walk(SOURCE, onerror=scan_error):
        root = Path(directory)
        symlinks.extend(str((root / name).relative_to(SOURCE)) for name in dirs
                        if (root / name).is_symlink() and name not in SKIP_DIRS)
        dirs[:] = [name for name in dirs if name not in SKIP_DIRS and not (root / name).is_symlink()]
        for name in names:
            path = root / name
            if name == 'checkpoint-034000.pt' or name.endswith(('.tmp', '.partial')):
                continue
            if path.is_symlink():
                symlinks.append(str(path.relative_to(SOURCE)))
            elif path.is_file():
                files.append(path)
    files.sort(key=lambda p: (p.suffix == '.pt', p.name == 'latest_weights.pt', str(p)))
    return files, errors, symlinks


def main():
    while True:
        try:
            STATE.mkdir(parents=True, exist_ok=True)
            lock = (STATE / 'worker.lock').open('a+')
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            break
        except BlockingIOError:
            raise SystemExit('another backup worker holds this destination lock')
        except OSError as error:
            print('backup setup retry:', repr(error), flush=True)
            time.sleep(INTERVAL)
    lock.seek(0)
    lock.truncate()
    lock.write(str(os.getpid()) + '\n')
    lock.flush()
    manifest = load_json(STATE / 'manifest.json', {'schema_version': 1, 'files': {}})
    manifest.update(source=str(SOURCE), destination=str(DEST),
                    exclusions={'directories': sorted(SKIP_DIRS), 'files': ['checkpoint-034000.pt', '*.tmp', '*.partial']})
    status = {'state': 'syncing', 'pid': os.getpid(), 'started_unix': time.time(), 'errors': []}
    finished_since = None

    def progress(**values):
        status.update(values, updated_unix=time.time())
        write_json(STATE / 'status.json', status)

    def unchanged(source, row):
        destination = DEST / source.relative_to(SOURCE)
        return row is not None and identity(source) == row['source_identity'] and destination.is_file() \
            and identity(destination) == row['destination_identity']

    def copy(source):
        relative = str(source.relative_to(SOURCE))
        destination = DEST / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        partial = destination.with_name(destination.name + '.partial')
        before = identity(source)
        digest, copied, next_progress = hashlib.sha256(), 0, 0
        progress(current_file=relative, phase='copying', copied_bytes=0, expected_bytes=before[2])
        try:
            with source.open('rb') as incoming, partial.open('wb') as outgoing:
                opened = os.fstat(incoming.fileno())
                assert [opened.st_dev, opened.st_ino, opened.st_size, opened.st_mtime_ns] == before
                while True:
                    block = incoming.read(BLOCK)
                    if not block:
                        break
                    outgoing.write(block)
                    digest.update(block)
                    copied += len(block)
                    if time.monotonic() >= next_progress:
                        progress(copied_bytes=copied)
                        next_progress = time.monotonic() + 5
                outgoing.flush()
                os.fsync(outgoing.fileno())
            if identity(source) != before or copied != before[2]:
                raise RuntimeError('source changed during copy; previous backup retained')
            expected = digest.hexdigest()
            verified = source.suffix == '.pt'
            if verified:
                progress(phase='verifying_destination', verified_bytes=0)
                check, checked, next_progress = hashlib.sha256(), 0, 0
                with partial.open('rb') as incoming:
                    for block in iter(lambda: incoming.read(BLOCK), b''):
                        check.update(block)
                        checked += len(block)
                        if time.monotonic() >= next_progress:
                            progress(verified_bytes=checked)
                            next_progress = time.monotonic() + 5
                if check.hexdigest() != expected or checked != copied:
                    raise RuntimeError('destination SHA256 readback mismatch; previous backup retained')
                if identity(source) != before:
                    raise RuntimeError('source changed during verification; previous backup retained')
            os.replace(partial, destination)
            descriptor = os.open(destination.parent, os.O_RDONLY | os.O_DIRECTORY)
            try:
                os.fsync(descriptor)
            finally:
                os.close(descriptor)
            manifest['files'][relative] = {'source_identity': before, 'destination_identity': identity(destination),
                                         'bytes': copied, 'sha256': expected, 'destination_readback_verified': verified,
                                         'completed_unix': time.time()}
            write_json(STATE / 'manifest.json', manifest)
        finally:
            try:
                partial.unlink(missing_ok=True)
            except OSError:
                pass

    while True:
        try:
            files, errors, symlinks = scan()
            progress(state='syncing', errors=errors, excluded_symlinks=symlinks)
            for source in files:
                relative = str(source.relative_to(SOURCE))
                try:
                    if not unchanged(source, manifest['files'].get(relative)):
                        copy(source)
                except (OSError, RuntimeError, AssertionError) as error:
                    errors.append({'path': relative, 'error': repr(error)})
                    print('backup will retry:', relative, repr(error), flush=True)
            manifest['updated_unix'] = time.time()
            write_json(STATE / 'manifest.json', manifest)
            ended = load_json(SOURCE / 'coordinator.json', {}).get('state') == 'finished'
            finished_since = (finished_since or time.monotonic()) if ended else None
            remaining = []
            latest_files, scan_errors, symlinks = scan()
            errors.extend(scan_errors)
            for source in latest_files:
                try:
                    if not unchanged(source, manifest['files'].get(str(source.relative_to(SOURCE)))):
                        remaining.append(str(source.relative_to(SOURCE)))
                except OSError as error:
                    errors.append({'path': str(source), 'error': repr(error)})
            complete = ended and finished_since is not None and time.monotonic() - finished_since >= INTERVAL \
                and not errors and not remaining and not symlinks
            progress(state='complete' if complete else 'waiting_for_coordinator' if not errors and not remaining else 'retrying',
                     coordinator_finished=ended, errors=errors, pending_files=remaining, excluded_symlinks=symlinks,
                     backed_up_files=len(manifest['files']), current_file=None, phase='idle')
            if complete:
                print('BACKUP_COMPLETE', str(DEST), flush=True)
                return
        except OSError as error:
            print('backup metadata/storage retry:', repr(error), flush=True)
        time.sleep(INTERVAL)


if __name__ == '__main__':
    main()
