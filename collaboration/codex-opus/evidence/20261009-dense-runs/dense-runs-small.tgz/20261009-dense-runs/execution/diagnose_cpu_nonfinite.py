"""CPU-only narrow diagnostic; no optimizer creation, update, or source edits."""
import importlib.util
import os
from pathlib import Path
import sys
import torch
import torch.nn.functional as F

SOURCE = Path('/tmp/nexus_vertex_dense_overfit50_20261009/source/vertex/dense_overfit50_20261009')
sys.path.insert(0, str(SOURCE))
spec = importlib.util.spec_from_file_location('cpu_fixture', SOURCE / 'tests/test_cpu.py')
fixture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)
import dense_train
import packed

if os.environ.get('CPU_FORCE_MATH') == '1':
    torch.backends.cuda.enable_flash_sdp(False)
    torch.backends.cuda.enable_mem_efficient_sdp(False)
    torch.backends.cuda.enable_math_sdp(True)
    print('CPU diagnostic: math SDPA forced', flush=True)

def stats(name, value):
    print(name, 'shape', tuple(value.shape), 'finite', bool(torch.isfinite(value).all()),
          'nan', int(torch.isnan(value).sum()), 'max_abs', float(value.detach().abs().max()), flush=True)

original_sdpa = F.scaled_dot_product_attention
def sdpa(query, key, value, *args, **kwargs):
    output = original_sdpa(query, key, value, *args, **kwargs)
    if not torch.isfinite(output).all():
        print('FIRST NONFINITE SDPA OUTPUT', flush=True)
        for name, tensor in [('query', query), ('key', key), ('value', value), ('output', output)]:
            stats(name, tensor)
        mask = kwargs.get('attn_mask')
        if mask is not None:
            print('mask', mask.dtype, tuple(mask.shape), 'min_allowed_keys', int(mask.sum(-1).min()), flush=True)
    return output
F.scaled_dot_product_attention = sdpa

_, conditions, _, levels, _ = fixture.load_data(torch.device('cpu'))
model = fixture.tiny_model()
fixture.cache_fixed_features(model, conditions)
args = fixture.make_args(checkpoint_activations=1, row_tokens=4096, chunk_tokens=8192)
objects = dense_train.objects_for_update(args, 2, 50)
items = dense_train.build_items(args, objects, levels, 2, torch.device('cpu'))
chunks = packed.make_chunks(items, packed.pack_rows(items, args.row_tokens), args.chunk_tokens, torch.device('cpu'))
print('objects', objects, 'chunks', len(chunks), flush=True)
batch = dense_train.cached_condition_batch(model, conditions, objects)
context = model.condition_encoder(batch)
stats('reference context', context)
reference = 0
for i, chunk in enumerate(chunks):
    prediction = packed.packed_flow_forward(model.flow, chunk.noisy, chunk.codes, chunk.depths,
                    chunk.item_ids, chunk.item_times, context[chunk.row_object])
    loss, _ = packed.chunk_loss(prediction, chunk)
    print('reference chunk', i, 'loss', float(loss), 'prediction_finite', bool(torch.isfinite(prediction).all()), flush=True)
    reference = reference + loss
reference.backward()
bad_gradients = [name for name, p in model.named_parameters() if p.grad is not None and not torch.isfinite(p.grad).all()]
print('reference nonfinite gradients', bad_gradients, flush=True)
for checkpoint in (1, 0):
    model.zero_grad(set_to_none=True)
    batch = dense_train.cached_condition_batch(model, conditions, objects)
    full = model.condition_encoder(batch)
    stats(f'checkpoint={checkpoint} context', full)
    print('context difference', float((full - context.detach()).abs().max()), flush=True)
    leaf = full.detach().float().requires_grad_(True)
    for i, chunk in enumerate(chunks):
        prediction = packed.packed_flow_forward(model.flow, chunk.noisy, chunk.codes, chunk.depths,
                    chunk.item_ids, chunk.item_times, leaf[chunk.row_object], use_checkpoint=checkpoint)
        loss, _ = packed.chunk_loss(prediction, chunk)
        print('detached checkpoint', checkpoint, 'chunk', i, 'loss', float(loss),
              'prediction_finite', bool(torch.isfinite(prediction).all()), flush=True)
        if not torch.isfinite(loss):
            stats('prediction', prediction)
            stats('target velocity', chunk.velocity)
            break
        loss.backward()
    print('condition leaf gradient finite', leaf.grad is not None and bool(torch.isfinite(leaf.grad).all()), flush=True)
print('DIAGNOSTIC COMPLETE; no optimizer instantiated or stepped', flush=True)
