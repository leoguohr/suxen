"""External command coordinator. Launch only after the authorized gates pass."""
import argparse
import datetime as dt
import json
import os
from pathlib import Path
import shlex
import signal
import subprocess
import time

PY = "/guohaoran/envs/nexus-algo/bin/python"
OUT = Path("/tmp/nexus_vertex_dense_overfit50_20261009")
CODE = OUT / "source/vertex/dense_overfit50_20261009"
S0 = "/tmp/nexus_vertex_dense_overfit50_20261009/checkpoint-034000.pt"
DEADLINE = dt.datetime.fromisoformat("2026-10-09T11:27:00+00:00").timestamp()
RUNS = {
    "A": ("GPU-10bebca7-76a1-7fcf-f5ea-5d280851a9f9", "1e-5", 4),
    "B": ("GPU-4db14efb-13b4-ec8b-bcba-670816c5837f", "3e-5", 4),
    "C": ("GPU-80f199d2-afab-fad3-824d-6d2482a4c882", "1e-4", 4),
    "D": ("GPU-0634fd68-4a4d-facb-1b7f-0f9789679b47", "3e-5", 8),
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--train-minutes", type=int, required=True)
    parser.add_argument("--chunk-tokens", type=int, choices=(4096,))
    parser.add_argument("--clock-offset-seconds", type=float, default=0.0,
                        help="authoritative UTC minus server wall-clock time")
    args = parser.parse_args()
    deadline = DEADLINE - args.clock_offset_seconds
    path = OUT / "coordinator.json"
    assert args.train_minutes > 0 and time.time() < deadline - 10
    assert CODE.is_dir() and not path.exists(), "coordinator must be a new execution"
    assert all(not (OUT / run).exists() and not (OUT / f"{run}.log").exists() for run in RUNS)
    records, processes = {}, {}
    report = {"state": "running", "deadline_utc": "2026-10-09T11:27:00Z",
              "clock_offset_seconds": args.clock_offset_seconds, "deadline_server_unix": deadline,
              "jobs": records}
    stop = {"at": deadline - 10, "reason": "deadline_guard"}
    ema_queue, next_report = list("DBAC"), time.time() + 900

    def persist():
        temporary = path.with_suffix(".json.tmp")
        temporary.write_text(json.dumps(report, indent=2) + "\n")
        temporary.replace(path)

    def request_stop(signum, _frame):
        stop.update(at=min(stop["at"], time.time()), reason=f"signal_{signum}")

    signal.signal(signal.SIGTERM, request_stop)
    signal.signal(signal.SIGINT, request_stop)

    def launch(run, phase):
        uuid, lr, copies = RUNS[run]
        key = f"{run}_{phase}"
        if phase == "train":
            command = [PY, "-u", "dense_train.py", "--init", S0, "--init-sha", "skip", "--output",
                       str(OUT / run), "--lr", lr, "--coarse-copies", str(copies),
                       "--train-minutes", str(args.train_minutes)]
            if args.chunk_tokens:
                command += ["--chunk-tokens", str(args.chunk_tokens)]
            log = OUT / f"{run}.log"
        else:
            command = [PY, "-u", "evaluate.py", "--checkpoint", str(OUT / run / "final.pt"),
                       "--weights", phase, "--output", str(OUT / run / f"eval_{phase}")]
            log = OUT / f"{run}_eval_{phase}.log"
        env = os.environ.copy()
        changes = {"CUDA_VISIBLE_DEVICES": uuid, "PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION": "python",
                   "OMP_NUM_THREADS": "8"}
        env.update(changes)
        records[key] = {"run": run, "phase": phase, "command": shlex.join(command), "environment": changes,
                        "cwd": str(CODE), "log": str(log), "start_unix": time.time(), "state": "starting"}
        persist()
        try:
            stream = log.open("x")
            try:
                process = subprocess.Popen(command, cwd=CODE, env=env, stdout=stream,
                                           stderr=subprocess.STDOUT, start_new_session=True)
            finally:
                stream.close()
            processes[key] = process
            records[key].update(pid=process.pid, process_group=process.pid, state="running")
        except OSError as error:
            records[key].update(state="failed", error=repr(error), end_unix=time.time())
        persist()

    def completed(key):
        return records.get(key, {}).get("state") == "complete"

    def signal_owned(sig):
        for key, process in processes.items():
            if process.poll() is None:
                try:
                    os.killpg(process.pid, sig)
                    records[key]["stop_reason"] = stop["reason"]
                except ProcessLookupError:
                    pass
        persist()

    for run in RUNS:
        launch(run, "train")
    terminating = None
    while True:
        now = time.time()
        if now >= stop["at"] and terminating is None:
            terminating = now
            report.update(state="stopping", stop_reason=stop["reason"])
            signal_owned(signal.SIGTERM)
        if terminating is not None and now >= terminating + 5:
            signal_owned(signal.SIGKILL)
        for key, process in list(processes.items()):
            row = records[key]
            rc = process.poll()
            if rc is None or row["state"] != "running":
                continue
            run, phase = row["run"], row["phase"]
            text = Path(row["log"]).read_text(errors="replace")
            artifact = OUT / run / ("final.pt" if phase == "train" else f"eval_{phase}/summary.json")
            marker = "TRAINING_COMPLETE" if phase == "train" else "EVALUATION_COMPLETE"
            ok = rc == 0 and marker in text and artifact.is_file() and "stop_reason" not in row
            row.update(return_code=rc, end_unix=time.time(), seconds=time.time() - row["start_unix"],
                       state="complete" if ok else "stopped" if "stop_reason" in row else "failed")
            persist()
            if ok and phase == "train" and terminating is None:
                launch(run, "raw")
        active = any(row["state"] == "running" for row in records.values())
        if not active:
            all_raw = all(completed(f"{run}_raw") for run in RUNS)
            if all_raw and ema_queue and terminating is None:
                needed = max(records[f"{run}_raw"]["seconds"] for run in RUNS) * 1.1 + 60
                if deadline - time.time() >= needed:
                    launch(ema_queue.pop(0), "ema")
                    continue
                report["ema_skipped"] = {"runs": ema_queue, "reason": "insufficient_time", "needed_seconds": needed}
            break
        if now >= next_report:
            for run in RUNS:
                log = OUT / f"{run}.log"
                lines = log.read_text(errors="replace").splitlines() if log.exists() else []
                update = next((s for s in reversed(lines) if s.startswith("u") and " loss " in s), "pending")
                journal = OUT / run / "train.jsonl"
                if journal.exists():
                    try:
                        latest = json.loads(journal.read_text().splitlines()[-1])
                        update = f"u{latest['update']} loss {latest['loss']:.5f} {latest['seconds']:.1f}s/update"
                    except (json.JSONDecodeError, IndexError):
                        pass
                probe = next((s for s in reversed(lines) if s.startswith("[probe u")), "pending")
                print(f"{run}: {update} | {probe}", flush=True)
            next_report = now + 900
        time.sleep(0.5)
    report.update(state="finished", end_unix=time.time(), all_raw_complete=all(completed(f"{r}_raw") for r in RUNS))
    persist()
    print(json.dumps(report), flush=True)


if __name__ == "__main__":
    main()
