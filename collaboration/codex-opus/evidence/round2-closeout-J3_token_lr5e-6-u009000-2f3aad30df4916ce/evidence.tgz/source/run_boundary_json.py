"""Run the frozen boundary calculations without the CLI's nullable float formatting."""
import argparse
import importlib.util
import json
import os
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--eval-dir', type=Path, action='append', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    os.environ['CUDA_VISIBLE_DEVICES'] = ''
    spec = importlib.util.spec_from_file_location('frozen_boundary_analysis', args.source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    labels = module.load_labels()
    reports = [module.analyze(folder, labels) for folder in args.eval_dir]
    encoded = json.dumps(reports, indent=2) + '\n'
    args.output.write_text(encoded)
    print(encoded, end='')


if __name__ == '__main__':
    main()
