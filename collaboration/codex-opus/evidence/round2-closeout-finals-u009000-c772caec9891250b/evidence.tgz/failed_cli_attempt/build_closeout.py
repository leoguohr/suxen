"""CPU-only Round2 closeout: validate saved predictions, analyze, package; never train."""
import argparse
from collections import deque
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import time

OLD = Path('/guohaoran/tmp/nexus_vertex_dense_round2_20261009')
ANALYSIS = Path('/guohaoran/tmp/nexus_vertex_dense_round2c_20261010')
OUT = Path('/guohaoran/tmp/nexus_round2_closeout_20261014')
CODE = ANALYSIS / 'repo_2449388/vertex/dense_overfit50_20261009'
COMMIT = 'e7c85bf2b82fdc6ee15eb59be20486ffc7853fa4'
PY = '/guohaoran/envs/nexus-algo/bin/python'
JOBS = ('J1_item', 'J2_token', 'J3_token_lr5e-6', 'J4_token_copies8',
        'J5_token_fine2', 'J6_token_selfcorrect')
DECODE_JOBS = ('J3_token_lr5e-6', 'J1_item', 'J2_token', 'J5_token_fine2')
JSONS = ('summary.json', 'evaluation.json', 'generation_manifest.json', 'progress.json')
SNAPSHOT_COMMIT = 'd482f4c414fde9fe42078952e124785d3b2ab471'
ENV = os.environ | {'CUDA_VISIBLE_DEVICES': '', 'OMP_NUM_THREADS': '2',
                    'OPENBLAS_NUM_THREADS': '2', 'MKL_NUM_THREADS': '2',
                    'PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION': 'python', 'GIT_NO_LAZY_FETCH': '1'}


def read(path):
    return json.loads(path.read_text())


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(8 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def clean(value):
    if isinstance(value, float) and not math.isfinite(value):
        return str(value)
    if isinstance(value, dict):
        return {key: clean(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [clean(item) for item in value]
    return value


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(clean(value), indent=2, allow_nan=False) + '\n')


def copy(source, dest):
    assert source.is_file() and not source.is_symlink(), str(source)
    assert source.suffix not in ('.pt', '.npz') and 'predictions' not in source.parts
    assert source.stat().st_size <= 128 << 20, f'Oversized evidence: {source}'
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        assert sha(source) == sha(dest), f'Source changed: {source}'
    else:
        shutil.copyfile(source, dest)


def training_record(job, evidence, uids):
    run = OLD / 'runs' / job
    status = read(run / 'status.json')
    configs = sorted(run.glob('config*.json'))
    assert configs and all(read(path)['uids'] == uids and read(path)['eval_steps'] == 20 for path in configs)
    for source in configs + [run / name for name in ('status.json', 'train.jsonl', 'probes.jsonl', 'evals.jsonl')]:
        assert source.is_file(), str(source)
        copy(source, evidence / 'runs' / job / source.name)
    with (run / 'train.jsonl').open() as stream:
        tail = list(deque(stream, maxlen=10))
    (evidence / 'runs' / job / 'train_tail.jsonl').write_text(''.join(tail))
    last = json.loads(tail[-1]) if tail else None
    console = sorted(path for path in (OLD / 'job_logs' / job).glob('console-*.log') if not path.is_symlink())
    complete = []
    marker = f'JOB_COMPLETE updates=9000 final={run / "final.pt"}'
    for path in console:
        copy(path, evidence / 'job_logs' / job / path.name)
        if marker in path.read_text().splitlines():
            complete.append(str(path))
    checkpoints = {}
    for name in ('latest.pt', 'final.pt'):
        path = run / name
        if path.exists():
            stat = path.stat()
            checkpoints[name] = {'path': str(path), 'bytes': stat.st_size, 'mtime_ns': stat.st_mtime_ns,
                                 'sha256_verified_this_builder': False}
    record = {'job': job, 'status': status, 'last_train_row': last,
              'job_complete_logs': complete, 'checkpoints': checkpoints,
              'config_sha256': {str(path): sha(path) for path in configs}}
    if job != 'J4_token_copies8':
        assert status['state'] == 'complete' and status['update'] == 9000 and complete
        assert status['final'] == str(run / 'final.pt') and checkpoints['final.pt']['bytes'] > 0
        record['completion_verified'] = True
    else:
        record['completion_verified'] = False
        record['boundary'] = 'Last recorded state only; no liveness claim, no restart, no final score inferred.'
    return record


def distance_denominators(source):
    import numpy as np
    missing = empty = 0
    for path in (source / 'predictions').glob('*.npz'):
        with np.load(path, allow_pickle=False) as values:
            if 'depth9_parents' not in values.files:
                missing += 1
            elif not values['depth9_occupancy'].astype(bool).any():
                empty += 1
    return {'all_trees': 100, 'missing_depth9_excluded': missing, 'distance_trees': 100 - missing,
            'empty_prediction_infinite_distance': empty, 'finite_chamfer_mean_trees': 100 - missing - empty}


def analyze(source, destination, identity, summary):
    destination.mkdir(parents=True, exist_ok=True)
    results = {}
    for kind in ('boundary', 'cascade'):
        script = CODE / f'analyze_{kind}.py'
        result, log, receipt = [destination / (kind + suffix) for suffix in ('.json', '.log', '.receipt.json')]
        command = [PY, str(script), '--eval-dir', str(source), '--output', str(result)]
        provenance = identity | {'script_sha256': sha(script), 'kind': kind}
        if receipt.exists():
            saved = read(receipt)
            assert saved['identity'] == provenance and saved['return_code'] == 0
            assert saved['result_sha256'] == sha(result) and saved['log_sha256'] == sha(log)
        else:
            assert not result.exists() and not log.exists(), f'Partial analysis preserved: {destination}'
            started = time.time()
            with log.open('x') as stream:
                code = subprocess.run(command, cwd=CODE, env=ENV, stdin=subprocess.DEVNULL,
                                      stdout=stream, stderr=subprocess.STDOUT).returncode
            assert code == 0, f'CPU {kind} failed ({code}); preserve {log}'
            write(receipt, {'identity': provenance, 'command': command, 'return_code': code,
                            'started_unix': started, 'ended_unix': time.time(),
                            'result_sha256': sha(result), 'log_sha256': sha(log)})
        values = read(result)
        assert len(values) == 1 and values[0]['eval_dir'] == str(source) and values[0]['trees'] == 100
        results[kind] = values[0]
    boundary = results['boundary']
    assert boundary['exact_within_cells']['0'] == summary['native_final_sets_exact']
    denoms = distance_denominators(source)
    assert boundary['incomplete_trees'] == denoms['missing_depth9_excluded']
    results['distance_denominators'] = denoms
    write(destination / 'DISTANCE_DENOMINATORS.json', denoms)
    return results


def collect_eval(job, weights, steps, source, evidence, validate, pairs, labels, checkpoint=None, digest=None):
    name = f'{job}_{weights}_s{steps}'
    summary = validate(source, 9000, weights, pairs, checkpoint, digest, steps if checkpoint else None)
    if steps == 20:
        assert summary['run_output'] == str(OLD / 'runs' / job)
        receipts = [json.loads(line) for line in (OLD / 'runs' / job / 'evals.jsonl').read_text().splitlines() if line]
        matches = [row for row in receipts if row['update'] == 9000 and row['weights'] == weights]
        assert matches and all(row['full_trees_exact'] == summary['full_trees_exact'] and
                              row['per_depth_exact'] == [v['full_level_exact'] for v in summary['per_depth']] for row in matches)
    for filename in JSONS:
        copy(source / filename, evidence / 'evaluations' / name / filename)
    if source.with_suffix('.log').is_file():
        copy(source.with_suffix('.log'), evidence / 'evaluations' / name / 'evaluate.log')
    identity = {'code_commit': COMMIT, 'eval_dir': str(source), 'labels_sha256': labels,
                'input_json_sha256': {name: sha(source / name) for name in JSONS}}
    analyzed = analyze(source, evidence / 'analysis' / name, identity, summary)
    return {'job': job, 'update': 9000, 'weights': weights, 'steps_per_depth': steps,
            'sampler': 'euler', 'trees': 100, 'eval_dir': str(source), 'summary': summary,
            'validation': '100 fixed UID/seed pairs, counts, per-depth totals, and every prediction SHA256 verified',
            'analysis': analyzed, 'identity': identity}


def report(result):
    lines = ['# NEXUS Round2 closeout', '',
             f"Scope: `{result['scope']}`; update 9000; analysis code `{COMMIT}`.", '',
             'Saved predictions were validated and analyzed on CPU. This package runs no model forward or training.', '',
             '| Job | Weights | Euler steps/layer | Teacher rule vs D9 GT | Full tree exact | Final integer set exact | Within one cell |',
             '|---|---|---:|---:|---:|---:|---:|']
    for row in result['evaluations']:
        value = row['summary']
        one_cell = row['analysis']['boundary']['exact_within_cells']['1']
        lines.append(f"| {row['job']} | {row['weights']} | {row['steps_per_depth']} | {value['teacher_rule_vs_d9_gt_pass']}/100 | {value['full_trees_exact']}/100 | {value['native_final_sets_exact']}/100 | {one_cell}/100 |")
    lines += ['', '| Job / weights / steps | depth 1–9 exact counts (each /100) | First mismatch depth |',
              '|---|---|---|']
    for row in result['evaluations']:
        summary = row['summary']
        counts = ', '.join(str(v['full_level_exact']) for v in summary['per_depth'])
        lines.append(f"| {row['job']} / {row['weights']} / {row['steps_per_depth']} | {counts} | `{json.dumps(summary.get('first_mismatch_depth_histogram', {}), sort_keys=True)}` |")
    lines += ['', '| Job / weights / steps | Vertex count accuracy | Depth9 micro F1 | Full-tree exact by GT vertex-count bucket |',
              '|---|---:|---:|---|']
    for row in result['evaluations']:
        summary = row['summary']
        depth = summary['per_depth'][-1]
        tp, fp, fn = [depth['global_cells_' + key] for key in ('tp', 'fp', 'fn')]
        f1 = 2 * tp / (2 * tp + fp + fn)
        lines.append(f"| {row['job']} / {row['weights']} / {row['steps_per_depth']} | {summary['count_accuracy']:.4f} | {f1:.6f} | `{json.dumps(summary['exact_by_vertex_count'], sort_keys=True)}` |")
    lines += ['', 'Distance metrics are vertex-set distances between D9 cell centres in [-1,1] units; they are not surface metrics or raw floating-point GT errors.',
              'Hausdorff uses the maximum directional nearest-neighbour distance. Chamfer is half the sum of the two directional mean distances.',
              'Missing-depth9 trees are excluded by the supplied distance evaluator. Empty predictions have infinite distance. Chamfer mean includes finite trees only; per-case denominators are recorded in RESULT.json and DISTANCE_DENOMINATORS.json.',
              'Full-tree and integer-set success always retain all 100 scheduled trees as the denominator.', '',
              'J4 is not counted as completed: its saved status/log/checkpoint inventory is provided without restarting it or inferring a final result.' if result['scope'] == 'finals' else 'The 20-step results are saved final training evaluations; 1/50-step cases are the completed frozen-checkpoint supplement.',
              'Final training evaluations identify run/update, not a freshly replayed checkpoint hash. Checkpoint byte hashes and recovery-state audits are separate evidence; this builder never loads model or optimizer tensors.', '',
              f"J3@7075 eight-case decoding and 14 boundary analyses were already published at [commit {SNAPSHOT_COMMIT[:8]}](https://github.com/leoguohr/suxen/commit/{SNAPSHOT_COMMIT}); they are not rerun here.", '',
              'Excluded: checkpoint tensors, prediction NPZ arrays, credentials. Those remain on the server. No causal attribution is made from these comparisons.', '']
    return '\n'.join(lines)


def package(folder, result):
    evidence = folder / 'evidence'
    write(folder / 'RESULT.json', result)
    (folder / 'REPORT.md').write_text(report(result))
    copy(folder / 'RESULT.json', evidence / 'RESULT.json')
    copy(folder / 'REPORT.md', evidence / 'REPORT.md')
    manifest = [{'path': str(path.relative_to(evidence)), 'bytes': path.stat().st_size, 'sha256': sha(path)}
                for path in sorted(evidence.rglob('*')) if path.is_file()]
    write(folder / 'FILE_MANIFEST.json', manifest)
    copy(folder / 'FILE_MANIFEST.json', evidence / 'FILE_MANIFEST.json')
    archive = folder / 'evidence.tgz'
    assert not archive.exists(), 'Refuse overwriting an evidence archive'
    with tarfile.open(archive, 'w:gz', compresslevel=6) as tar:
        for path in sorted(evidence.rglob('*')):
            if path.is_file():
                assert not path.is_symlink() and path.suffix not in ('.pt', '.npz') and 'predictions' not in path.parts
                tar.add(path, arcname=str(path.relative_to(evidence)), recursive=False)
    write(folder / 'PACKAGE.json', {'schema_version': 1,
          'identity': {'scope': result['scope'], 'job': result['job'], 'update': 9000,
                       'analysis_code_commit': COMMIT, 'manifest_sha256': sha(folder / 'FILE_MANIFEST.json')},
          'archive': archive.name, 'archive_sha256': sha(archive), 'archive_bytes': archive.stat().st_size})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--scope', required=True, choices=('finals', 'decode'))
    parser.add_argument('--job', choices=DECODE_JOBS)
    args = parser.parse_args()
    assert (args.scope == 'decode') == bool(args.job), '--job is required only for decode'
    os.environ.update({key: ENV[key] for key in ('CUDA_VISIBLE_DEVICES', 'OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION')})
    folder = OUT / ('finals' if args.scope == 'finals' else 'decode_' + args.job)
    folder.mkdir(parents=True, exist_ok=True)
    lock = (folder / '.build.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    if (folder / 'PACKAGE.json').exists():
        previous = read(folder / 'PACKAGE.json')
        assert read(folder / 'RESULT.json')['state'] == 'complete'
        assert previous['archive_sha256'] == sha(folder / previous['archive'])
        print('CLOSEOUT_ALREADY_COMPLETE', str(folder), flush=True)
        return
    assert not (folder / 'GITHUB_PUBLISH.json').exists(), 'Refuse to overwrite published evidence'
    assert subprocess.check_output(['git', '-C', str(CODE), 'rev-parse', 'HEAD'], env=ENV, text=True).strip() == COMMIT
    subprocess.run(['git', '-C', str(CODE), 'diff', '--exit-code', 'HEAD', '--', '.'], env=ENV, check=True)
    sys.path.insert(0, str(ANALYSIS / 'jobs'))
    from run_decode_test import validate
    manifest = read(CODE / 'data/prepared_d9/manifest.json')
    uids = manifest['train_uids']
    assert len(uids) == len(set(uids)) == 50
    pairs = {(seed, uid) for seed in (97029000, 97029001) for uid in uids}
    label_paths = {CODE / 'data/prepared_d9/manifest.json'}
    for entry in manifest['records']:
        label_paths.update((CODE / 'data/prepared_d9' / entry['label_file'], CODE / 'data' / entry['source_label_file']))
    labels = {str(path): sha(path) for path in sorted(label_paths)}
    evidence = folder / 'evidence'
    evidence.mkdir(exist_ok=True)
    result = {'state': 'building', 'scope': args.scope, 'job': args.job, 'started_unix': time.time(),
              'analysis_code_commit': COMMIT, 'fixed_seeds': [97029000, 97029001], 'uids': uids,
              'labels_sha256': labels, 'jobs': [], 'evaluations': [], 'commands': [sys.executable, *sys.argv],
              'checkpoint_tensor_loads': 0, 'gpu_calls': 0, 'snapshot7075_publication_commit': SNAPSHOT_COMMIT}
    copy(Path(__file__), evidence / 'source/build_closeout.py')
    copy(ANALYSIS / 'jobs/run_decode_test.py', evidence / 'source/run_decode_test.py')
    for filename in ('analyze_boundary.py', 'analyze_cascade.py', 'evaluate.py', 'common.py', 'samplers.py', 'CODEX_PROMPT_ROUND2C.md'):
        copy(CODE / filename, evidence / 'source' / filename)
    copy(CODE / 'data/prepared_d9/manifest.json', evidence / 'data_manifest.json')
    for filename in ('checkpoint_inventory.json', 'snapshot_verified.json', 'training_source_identity.json'):
        path = OUT / filename
        if path.is_file():
            copy(path, evidence / filename)
            result[filename.removesuffix('.json') + '_sha256'] = sha(path)
    selected = JOBS if args.scope == 'finals' else (args.job,)
    for job in selected:
        result['jobs'].append(training_record(job, evidence, uids))
    for source in sorted((OLD / 'jobs').glob('*.sh')):
        copy(source, evidence / 'job_scripts' / source.name)
    if args.scope == 'finals':
        for job in JOBS:
            if job == 'J4_token_copies8':
                continue
            for weights in ('raw', 'ema'):
                source = OLD / 'runs' / job / 'evals' / f'u009000_{weights}'
                result['evaluations'].append(collect_eval(job, weights, 20, source, evidence, validate, pairs, labels))
                print('CPU_ANALYSIS_COMPLETE', job, weights, 20, flush=True)
    else:
        state_path = ANALYSIS / 'decode_test' / (args.job + '_decode_status.json')
        state = read(state_path)
        assert state['state'] == 'complete' and state['final_update'] == 9000 and len(state['cases']) == 4
        checkpoint = OLD / 'runs' / args.job / 'final.pt'
        assert state['checkpoint'] == str(checkpoint) and len(state['checkpoint_sha256']) == 64
        result['decode_identity'] = {key: state[key] for key in ('checkpoint', 'checkpoint_sha256', 'code_commit', 'gpu_uuid')}
        copy(state_path, evidence / 'decode_status.json')
        assert {(row['weights'], row['steps']) for row in state['cases']} == {('ema', 1), ('raw', 1), ('ema', 50), ('raw', 50)}
        for weights in ('raw', 'ema'):
            for steps in (1, 20, 50):
                source = (OLD / 'runs' / args.job / 'evals' / f'u009000_{weights}' if steps == 20 else
                          ANALYSIS / 'decode_test' / f'{args.job}_{weights}_s{steps}')
                result['evaluations'].append(collect_eval(args.job, weights, steps, source, evidence, validate, pairs, labels,
                                                          None if steps == 20 else checkpoint,
                                                          None if steps == 20 else state['checkpoint_sha256']))
                print('CPU_ANALYSIS_COMPLETE', args.job, weights, steps, flush=True)
    result.update(state='complete', ended_unix=time.time())
    package(folder, result)
    print('CLOSEOUT_COMPLETE', str(folder), flush=True)


if __name__ == '__main__':
    main()
