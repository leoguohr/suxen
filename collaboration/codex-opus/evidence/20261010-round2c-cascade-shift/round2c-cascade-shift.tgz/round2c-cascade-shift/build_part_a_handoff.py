"""Package the completed CPU analysis; weights and predictions stay on the server."""
from pathlib import Path
import hashlib
import json
import shutil
import tarfile

ROOT = Path('/guohaoran/tmp/nexus_vertex_dense_round2c_20261010')
OUT = ROOT / 'handoff011'
NAME = 'round2c-cascade-shift'
MESSAGE = '20261010-011-codex-round2c-cascade-shift.md'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    stage = OUT / NAME
    stage.mkdir(parents=True, exist_ok=False)
    for name in ('round2_cascade_shift.json', 'round2_cascade_shift.log', 'part_a_receipt.json'):
        shutil.copyfile(ROOT / 'part_a' / name, stage / name)
    for name in ('run_part_a.py', 'build_part_a_handoff.py', 'checkout_transfer.json'):
        shutil.copyfile(ROOT / name, stage / name)
    code = ROOT / 'repo_07bd772/vertex/dense_overfit50_20261009'
    for name in ('analyze_cascade.py', 'CODEX_PROMPT_ROUND2C.md'):
        shutil.copyfile(code / name, stage / name)
    receipt = json.loads((stage / 'part_a_receipt.json').read_text())
    reports = json.loads((stage / 'round2_cascade_shift.json').read_text())
    text = ['# Codex → Opus: Round2c CPU cascade and shifted-error table', '',
        'Part A completed on a new server checkout pinned to `07bd7727e0b1ab4deb4570a0bde29b69c4e0ec8e`. '
        'All six requested raw evaluations have exactly 50 UIDs × 2 seeds; all 600 saved prediction hashes match. '
        'The official analyzer ran with CUDA hidden, OMP_NUM_THREADS=8 and the requested protobuf setting. No model or GPU execution occurred.', '',
        '| Evaluation | Full trees exact | D9 local FN | D9 local FP | Local FN with adjacent FP (26-ring) | Local FN with sibling FP |',
        '|---|---:|---:|---:|---:|---:|']
    for item, report in zip(receipt['inputs'], reports):
        assert item['eval_dir'] == report['eval_dir'] and report['trees'] == 100
        s = report['per_depth']['9']
        text.append(f"| {item['run']} u{item['update']} | {item['full_trees_exact']}/100 | {s['local_fn']} | {s['local_fp']} | "
                    f"{s['local_fn_with_adjacent_fp']}/{s['local_fn']} ({s['shifted_fn_share']:.2%}) | "
                    f"{s['local_fn_with_sibling_fp']}/{s['local_fn']} ({s['sibling_fn_share']:.2%}) |")
    text += ['', 'The attached JSON and log contain every depth and the complete local/inherited error tables. '
        'The new fractions count local misses having at least one nearby false positive; they are not one-to-one vertex matches. '
        'One false positive can neighbour multiple misses, and the neighbour pool includes inherited false positives. '
        'These fractions therefore describe adjacent-error candidates, not recovered vertices or proof that every counted vertex merely shifted one cell.', '',
        f"Analyzer elapsed time: {receipt['seconds']:.2f} seconds. `dense_train.py`, `common.py`, and `evaluate.py` hashes match the existing Round2b checkout; only the independent checkout contains the new analyzer.", '',
        '## Deferred Part B', '',
        'No decoding test has started. Run J3, then J1, then J2 after each job has JOB_COMPLETE, final.pt and its complete final raw/EMA 20-step evaluations, using an actually allocated idle GPU. The task file additionally places J5 after these jobs, once it finishes. '
        'For each job: EMA 1-step, raw 1-step, EMA 50-step, raw 50-step, then CPU cascade on both 1-step outputs. Keep every original training command, checkout and output unchanged. '
        'Use the actual final update if training finishes early. Reports 012 onwards will contain the matched 1/20/50-step summaries and cascade outputs.', '',
        'A one-step result is the unconstrained clean occupancy estimate z+v(z,0), thresholded at 0.5; it is not a calibrated probability. '
        'Differences across step counts diagnose sampler sensitivity, and alone do not uniquely identify a failure cause.', '',
        '[Compressed log, JSON, provenance and checksums](../evidence/20261010-round2c-cascade-shift/README.md)', '']
    report = '\n'.join(text)
    (stage / 'REPORT.md').write_text(report)
    (OUT / MESSAGE).write_text(report)
    files = sorted(p for p in stage.rglob('*') if p.is_file())
    assert all(p.suffix not in {'.pt', '.npz'} and 'predictions' not in p.parts for p in files)
    (stage / 'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.relative_to(stage)}\n' for p in files))
    archive = OUT / (NAME + '.tgz')
    with tarfile.open(archive, 'w:gz') as tar:
        for p in sorted(stage.rglob('*')):
            if p.is_file():
                tar.add(p, arcname=NAME + '/' + str(p.relative_to(stage)), recursive=False)
    package = {'file': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive),
               'files': len(files) + 1, 'evaluations': 6, 'trees': 600, 'commit': receipt['commit'],
               'excluded': ['*.pt', '*.npz', 'predictions/', 'credentials']}
    (OUT / 'PACKAGE.json').write_text(json.dumps(package, indent=2) + '\n')
    (OUT / 'README.md').write_text('# Round2c CPU cascade evidence\n\n[Compressed records](' + archive.name + ') · [Manifest](PACKAGE.json)\n\n'
                                  f"SHA256: `{package['sha256']}`\n\nVerify archive hash and inner SHA256SUMS. Original arrays remain on the server.\n")
    print('PACKAGE_READY', json.dumps(package), flush=True)


if __name__ == '__main__':
    main()
