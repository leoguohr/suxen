"""CPU-only Round2c analysis of the six explicitly requested saved evaluations."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/guohaoran/tmp/nexus_vertex_dense_round2_20261009')
NEW = Path('/guohaoran/tmp/nexus_vertex_dense_round2c_20261010')
CODE = NEW / 'repo_07bd772/vertex/dense_overfit50_20261009'
OUT = NEW / 'part_a'
COMMIT = '07bd7727e0b1ab4deb4570a0bde29b69c4e0ec8e'
PY = '/guohaoran/envs/nexus-algo/bin/python'
TARGETS = [('J1_item', 3600), ('J2_token', 3600), ('J3_token_lr5e-6', 1800),
           ('J3_token_lr5e-6', 3600), ('J5_token_fine2', 1800), ('J6_token_selfcorrect', 3600)]


def read(p):
    return json.loads(p.read_text())


def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda: f.read(8 << 20), b''):
            h.update(block)
    return h.hexdigest()


def main():
    assert subprocess.check_output(['git', '-C', str(CODE), 'rev-parse', 'HEAD'], text=True).strip() == COMMIT
    subprocess.run(['git', '-C', str(CODE), 'diff', '--exit-code', 'HEAD', '--', '.'], check=True)
    source_hashes = {}
    old = ROOT / 'repo_round2b/vertex/dense_overfit50_20261009'
    for name in ('dense_train.py', 'common.py', 'evaluate.py'):
        source_hashes[name] = sha(CODE / name)
        assert source_hashes[name] == sha(old / name), name
    source_hashes['analyze_cascade.py'] = sha(CODE / 'analyze_cascade.py')
    manifest = read(CODE / 'data/prepared_d9/manifest.json')
    uids = manifest['train_uids']
    assert len(uids) == len(set(uids)) == 50
    expected = {(seed, uid) for seed in (97029000, 97029001) for uid in uids}
    inputs = []
    for run, update in TARGETS:
        folder = ROOT / 'runs' / run
        path = folder / 'evals' / f'u{update:06d}_raw'
        summary, evaluation, generated, progress = [read(path / (n + '.json'))
            for n in ('summary', 'evaluation', 'generation_manifest', 'progress')]
        assert progress['generated'] == progress['expected'] == summary['trees'] == 100
        for doc in (summary, evaluation):
            assert doc['update'] == update and doc['weights'] == 'raw'
            assert doc['run_output'] == str(folder)
        for doc in (evaluation, generated):
            assert len(doc['rows']) == 100
            assert {(r['seed'], r['uid']) for r in doc['rows']} == expected
        assert summary['full_trees_exact'] == sum(r['all_levels_exact'] for r in evaluation['rows'])
        assert summary['first_mismatch_depth_histogram'] == dict(Counter(str(r['first_mismatch_depth']) for r in evaluation['rows']))
        receipts = [json.loads(l) for l in (folder / 'evals.jsonl').read_text().splitlines() if l.strip()]
        receipt = [r for r in receipts if r['update'] == update and r['weights'] == 'raw']
        assert len(receipt) == 1 and receipt[0]['full_trees_exact'] == summary['full_trees_exact']
        expected_files = {f'seed-{s}_{u}.npz' for s, u in expected}
        assert {p.name for p in (path / 'predictions').glob('*.npz')} == expected_files
        verified = []
        for row in generated['rows']:
            prediction = path / 'predictions' / f"seed-{row['seed']}_{row['uid']}.npz"
            before = prediction.stat()
            digest = sha(prediction)
            after = prediction.stat()
            assert (before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns)
            assert digest == row['prediction_sha256']
            verified.append({'uid': row['uid'], 'seed': row['seed'], 'sha256': digest})
        inputs.append({'run': run, 'update': update, 'weights': 'raw', 'eval_dir': str(path),
                       'trees': 100, 'full_trees_exact': summary['full_trees_exact'],
                       'json_hashes': {n: sha(path / n) for n in ('summary.json', 'evaluation.json', 'generation_manifest.json', 'progress.json')},
                       'prediction_hashes_verified': verified})
        print('VALIDATED', run, update, '100 trees', flush=True)
    OUT.mkdir(parents=True, exist_ok=True)
    assert not (OUT / 'round2_cascade_shift.json').exists(), 'Preserve previous outputs; inspect before rerun'
    command = [PY, str(CODE / 'analyze_cascade.py')]
    for item in inputs:
        command += ['--eval-dir', item['eval_dir']]
    command += ['--output', str(OUT / 'round2_cascade_shift.json')]
    env = dict(os.environ, CUDA_VISIBLE_DEVICES='', PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION='python', OMP_NUM_THREADS='8')
    started = time.monotonic()
    with (OUT / 'round2_cascade_shift.log').open('w') as log:
        subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
    reports = read(OUT / 'round2_cascade_shift.json')
    assert [r['eval_dir'] for r in reports] == [i['eval_dir'] for i in inputs]
    assert len(reports) == 6 and all(r['trees'] == 100 for r in reports)
    for report in reports:
        for stats in report['per_depth'].values():
            assert 0 <= stats['local_fn_with_adjacent_fp'] <= stats['local_fn']
            assert 0 <= stats['local_fn_with_sibling_fp'] <= stats['local_fn']
            assert 0 <= stats['local_fp_with_adjacent_fn'] <= stats['local_fp']
    receipt = {'completed_utc': datetime.now(timezone.utc).isoformat(), 'command': command,
               'commit': COMMIT, 'source_hashes': source_hashes, 'manifest_sha256': sha(CODE / 'data/prepared_d9/manifest.json'),
               'inputs': inputs, 'seconds': time.monotonic() - started, 'return_code': 0,
               'CUDA_VISIBLE_DEVICES': '', 'OMP_NUM_THREADS': '8',
               'outputs': {n: sha(OUT / n) for n in ('round2_cascade_shift.json', 'round2_cascade_shift.log')},
               'scope': '600 saved trees; CPU analysis only, no model replay or prediction repair.'}
    (OUT / 'part_a_receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print('PART_A_COMPLETE', json.dumps({'trees': 600, 'seconds': receipt['seconds'], 'output': str(OUT)}), flush=True)


if __name__ == '__main__':
    main()
