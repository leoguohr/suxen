# T1 可比性与数值边界报告

日期：2026-10-15。对象：`leoguohr/suxen` 的 `topology-overfit50-20261015`，固定提交 `72c993772a91482a3660faa7c83993bfd566cbfe`。

**结论：训练问题、数据、损失归一化和评价定义保持 T1 源码规定；执行方式增加了数据并行、可选的部分激活重计算和完整恢复保护。多卡 BF16 结果不保证与原单卡逐位一致，已测得差异，不能把本报告标成“所有数值门均通过”。正式 Run A / Run B 的10,000次训练尚未启动。**

## 比较基准与保留项

| 项目 | 原 T1 规定 | 此次执行适配 |
|---|---|---|
| 原始源码 | `CODEX_PROMPT.md`、`RUN_SHEET.md` 及同提交 Python 文件 | 原源码保持不变；清单见 [SOURCE_FILES.json](../SOURCE_FILES.json)。新增脚本位于独立 `tools/` |
| 模型与 AE | 原2.33B系统；冻结 OwnAE-v2 step36220；512维 latent | 保留原 `TopologyFlowSystem`、条件编码器、冻结 Decoder及参数形状 |
| 数据 | 用户固定50条，共52,820顶点；真实点云 XYZ/法向；原缓存和标准化 | 原 `load_cache` 校验及 UID 顺序不变；不增删 mesh，不改坐标或拓扑 |
| 每次有效更新 | 全50条共同参与，按全部顶点与 latent channel 等权 | 多卡分摊完整 mesh，更新的全局分母仍为 `52820 × 512` |
| 随机目标 | 原 `make_batch(seed, update)`：50对象分层时间、posterior sample、Flow noise | 每个 rank 生成同一完整批次，再选择所属对象；没有各 rank 独立重抽时间或目标 |
| 优化器与调度 | fresh AdamW；原 lr、warmup、decay、clip、EMA | 梯度求和后执行一次全局 clip、AdamW、EMA；LR仍用原 `lr_at(update)` |
| Run A / B | A fresh；B 复制 S0 兼容权重，latent 输入输出层新建 | 调用原初始化与 `transfer_vertex_weights`；B优化器仍 fresh |
| 精度 | FP32 参数、BF16 autocast；TF32关闭 | 保留；未切换为历史实验的 FP32 MATH 配方 |
| probe / milestone | 原250步 probe、2000步 raw/EMA评价及末次评价 | 原函数在 rank0执行；其他 rank等待；恢复时补做已到边界但尚未记录的工作 |
| Edge / Face | 原 `metrics.py`、`evaluate.py`、采样器及阈值 | 未修改；原候选上限及 `lower_bound` 标记继续生效。不能将结果另行宣称为完整候选评价或严格50/50 |

全局损失为：

\[
L = \frac{\sum_{i=1}^{50}\sum_{v=1}^{N_i}\sum_{c=1}^{512}(\hat u_{ivc}-u_{ivc})^2}{52820\times512}.
\]

每个 rank 计算自己对象的分子，仍除以上述**全局**分母；随后用 `all_reduce(SUM)` 合并梯度。没有再除以 world size，也没有把不同大小 mesh 改为等权。精确算术下，它与原单卡优化问题相同。单次更新仍覆盖全50条，各 rank不各自计为一次独立有效更新。

## 数值验证

| 检查 | 条件 | 已观察结果 | 证据边界 |
|---|---|---|---|
| CPU实际配方语义门 | 50个合成小 mesh，非零 gates/head，1/2/4 rank各3步；lr=1e-4、warmup=500、EMA=.999 | 模型、Adam、EMA、loss、grad norm通过预定容差 | 验证全局分母、SUM和更新顺序；不等于真实2.33B长期轨迹验证 |
| 早期CPU压力门 | lr=.001、warmup=1、EMA=.9；原严格阈值 | 2 rank第二步约 `6.03e-6` 最大参数差，失败记录保留 | actual通过不覆盖stress失败；旧阈值未放宽 |
| 部分重计算CPU门 | 原两层tiny，分别重计算0/1/2层，非零 gates/head | output、gradient、clip norm、AdamW后参数及optimizer state均bitwise相同 | 只覆盖所测CPU小模型，不外推GPU/大模型逐位一致 |
| 完整恢复CPU门 | 2 rank：连续4步，对照2步保存后恢复2步 | model、Adam、EMA、各rank RNG、游标精确相同；recipe/SHA拒绝、STOP、完成保护、早停标记和速度硬停通过 | 真实37GB级保存/恢复结果另行归档 |
| GPU BF16小模型 | A100-SXM4-80GB，50个合成mesh/748 tokens，312,200参数，非零 gates/head；fresh Adam、update=500对应lr=1e-4 | 2/4 rank均有差异，未通过沿用的CPU严格阈值 | BF16分组计算/归约确实影响数值；不能声称与单卡逐位等价 |

CPU实际配方参数阈值保持 `atol=2e-6, rtol=5e-5`；Adam状态阈值保持 `atol=2e-7, rtol=1e-4`。压力失败后增加梯度、参数更新量和Adam分母诊断，没有修改这些阈值。

GPU原始证据：[world1.json](../results/gpu_numerics/world1.json)、[world2.json](../results/gpu_numerics/world2.json)、[world4.json](../results/gpu_numerics/world4.json)。相对L2定义为 `||实际−参考||₂ / ||参考||₂`。“参数更新量”以本次Adam前后差值为基准，不能用整体权重范数替代。

| 分布式Flash vs 单卡Flash | 梯度相对L2 | 更新后整体参数相对L2 | 本次参数更新量相对L2 | 最大参数绝对差 | 原CPU阈值 |
|---|---:|---:|---:|---:|---|
| 1 rank | 0 | 0 | 0 | 0 | 通过 |
| 2 rank | 0.0020645296（0.206%） | 0.0000274623 | 0.0296071320（2.961%） | 0.0001987517 | 未通过 |
| 4 rank | 0.0018923820（0.189%） | 0.0000348336 | 0.0375541403（3.755%） | 0.0001988932 | 未通过 |

所测小模型中，单卡Flash与单卡SDPA的loss、gradient、参数更新相同。这只覆盖该环境和该测试，不代表所有形状或真实2.33B输入都相同。

条件attention的key bias没有QK norm，精确算术下公共key偏置被softmax平移不变性消去；GPU报告确实观察到这些坐标约 `1e-6` 的非零梯度及Adam更新。不过两段条件key bias对**总梯度误差平方L2**的可推得上界仅为0.002883%（2卡）/0.003560%（4卡），因此它们不是主要梯度误差来源。现有JSON不足以算出它们对总Adam更新差异的贡献。不能据此归因全部多卡差异或豁免失败；更完整解读见 [INTERPRETATION.md](../results/gpu_numerics/INTERPRETATION.md)。

## 执行与恢复边界

`checkpoint_policy.py` 只决定前N个Flow block是否重计算；条件编码器保持原策略，层顺序、参数和checkpoint key不变。省略参数时仍全层重计算。最终N值以启动配置及其SHA为准。Run A/B共同使用冻结后的执行配置。

恢复记录包含model、AdamW、EMA、update、各rank Python/NumPy/Torch RNG、下一有效update、固定UID顺序和随机批次seed。恢复先验证checkpoint大小/SHA256、不可变配方、world size以及原源码/适配器哈希。`--stop-after-updates`只限定单次进程长度，不改变max-updates、warmup或LR公式。

`latest.json` / `final.json` 是提交指针；完整checkpoint刷盘后计算SHA，再原子提交指针。默认只清理本实验上一份已提交且未被final保护的代文件。当前没有“最佳模型”自动标记机制。有效更新超过30秒时保存完整状态后退出，已完成的更新计数保留。

## 证据位置与当前状态

服务器前期准备目录：`/guohaoran/nexus_topology_flow_overfit50_20261015/preflight_20261015`。

- 实际配方CPU门：`logs/distributed_cpu_actual.log`。
- 早期压力门：`distributed_cpu_gate/`中的原始记录；未根据猜测补造日志文件名。
- 最终恢复CPU门：`logs/resume_cpu_gate_final.log`，结束标记 `DISTRIBUTED_RESUME_GATE_OK`。
- 部分重计算门：`logs/checkpoint_policy_cpu_gate.log`；本地摘要 [checkpoint_policy_cpu_gate.json](../tools/checkpoint_policy_cpu_gate.json)。
- GPU小模型数值报告：本地 `results/gpu_numerics/`，上列三个JSON已直接核读。
- 真实2.33B完整checkpoint的保存、SHA和恢复有界smoke已通过，细节见本文最后的最终验证补充。

已执行内容是性能测试、数值检查和有界启动/恢复验证。尚无本轮正式10,000步Run A/B结果、最终Edge/Face分数或sampler sweep结论。测速和小模型一致性证据不能替代生成质量评价。

## 最终真实模型验证补充

2.33B A完整保存3步后恢复至4步，B从S0迁移902张量后完成3步完整保存；SHA及游标/LR已核验。详见[full_checkpoint_verification.json](../results/full_checkpoint_verification.json)。测试权重经再次读回SHA验证后清理；正式A/B仍未启动。真实模型非零头Flash/SDPA：maxabs=1.335144e-5、relative RMS=0.00534095，见[smoke_B_u3_backend.json](../results/smoke_B_u3_backend.json)。
