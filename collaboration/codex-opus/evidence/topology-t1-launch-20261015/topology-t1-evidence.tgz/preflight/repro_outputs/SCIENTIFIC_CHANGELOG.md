# T1 前期准备变更记录

日期：2026-10-15。原始任务源：`leoguohr/suxen` / `topology-overfit50-20261015` / `72c993772a91482a3660faa7c83993bfd566cbfe`。

**状态：原T1研究代码和科学定义保持不变，新增独立执行适配器；已开展性能和恢复测试。正式Run A/Run B的10,000步训练尚未启动。**

## 保持不变的研究选择

- 固定50条mesh、52,820顶点、原顶点顺序、真实点云条件与缓存/标准化来源。
- 原2.33B系统、latent512、冻结OwnAE-v2 step36220、Run A fresh和Run B S0兼容权重初始化。
- 原posterior sampling、50对象分层时间、Flow noise、velocity target及全token/channel等权MSE。
- 原AdamW、clip、warmup/decay、EMA和BF16 autocast；未打开TF32。
- 原probe、raw/EMA milestone、sampler与Decoder/Edge/Face评分代码。原候选上限及lower_bound字段保留。

源码清单：[SOURCE_FILES.json](../SOURCE_FILES.json)。没有编辑其中的train.py、model.py、data.py、metrics.py、sampling.py、evaluate.py或vendor实现。

## 新增执行代码及影响

| 文件 | 实际变更 | 与研究结果相关的边界 |
|---|---|---|
| [benchmark_distributed.py](../tools/benchmark_distributed.py) | 独立1/2/4 rank测速；完整mesh分片；全局分母；FP32梯度SUM；原clip/AdamW/EMA；阶段时间和峰值显存 | 每步仍全50条；测速不作为正式训练起点；多卡浮点顺序不同，差异单独报告 |
| [checkpoint_policy.py](../tools/checkpoint_policy.py) | 可选只重计算前N个Flow block，默认全层；原参数和条件编码器不变 | 激活重计算执行策略；CPU非零gates/head测试逐位相同，不能无条件外推GPU |
| [train_distributed.py](../tools/train_distributed.py) | 调用原模型、数据、优化/评价函数；分布式update及rank0评价；完整恢复、原子提交、SHA、STOP/信号、30秒硬停和输出锁 | 改变执行入口和持久化形式；不改变全局样本集、优化目标、LR时间轴或评价定义 |
| [test_benchmark_distributed.py](../tools/test_benchmark_distributed.py) | 分开保留stress与actual配方门；显式静态rendezvous端口 | 未放宽原阈值，actual通过不覆盖stress失败 |
| [test_train_distributed.py](../tools/test_train_distributed.py) | 连续4步vs 2+2恢复，检查model/Adam/EMA/RNG/cursor；recipe/SHA拒绝、STOP、完成保护、速度停止及早停标记 | 合成小模型有界验证；早停测试使用明确标记的人工状态夹具，不构成生成成功证据 |
| [test_gpu_numerics.py](../tools/test_gpu_numerics.py) | 非零gates/head的GPU BF16单/多卡及Flash/SDPA对照 | 明确报告未通过原CPU阈值的差异，不以放宽阈值改判为相同 |

冻结runtime SHA256：

| 文件 | SHA256 |
|---|---|
| train_distributed.py | `995c8d3493c8eec6f009f7416ba00ce404a63c1e3433c632a9759beec3edba57` |
| benchmark_distributed.py | `6fb8972ca43943de388a004d48a9741cb034aafafce2f8ce20b4617e518669e3` |
| checkpoint_policy.py | `8b1027eb0260b413371b3629b67ab70204da1204c863ab3a5ae84dee70bb4543` |

最终启动以部署后的launch_manifest.json和实际配置哈希为准；若文件变化，应更新清单及相应验证，不能混用不同执行器源码产生的恢复点。

## 验证中的发现与处理

1. **原压力门失败保留。** lr=.001、warmup=1的CPU压力条件，在2 rank第二步有约6.03e-6参数差。增加梯度、Adam状态和参数更新诊断；原参数容差atol=2e-6、rtol=5e-5未变。随后使用实际T1的lr=1e-4、warmup=500、EMA=.999，在1/2/4 rank各3步通过既定比较。
2. **多卡BF16非逐位等价。** 2 rank相对单卡的梯度相对L2为0.0020645296，本次参数更新量相对L2为0.0296071320；4 rank分别为0.0018923820、0.0375541403。两项检查均未通过原CPU严格阈值。原始数据：[results/gpu_numerics](../results/gpu_numerics)。
3. **Flash/SDPA观察范围有限。** 所测非零gates/head小模型的两条单卡路径在记录量上相同；不宣称所有形状都相同。理论零key bias的浮点残差不构成全部误差的解释，细节见[数值解读](../results/gpu_numerics/INTERPRETATION.md)。
4. **恢复后的报告错误已修复。** 最终评价中断后，早期执行器草稿会丢失passed_early。现保存并恢复该字段；不改变模型、优化器或更新数。合成状态夹具验证通过。
5. **恢复和停止门通过小模型验证。** 连续4步与2+2恢复的model、Adam、EMA、各rank RNG及游标精确相同；recipe变更和SHA错误拒绝恢复，STOP阻止推进，完成输出不重复启动，速度停止前提交完整checkpoint。
6. **rendezvous端口冲突属于启动问题。** 曾有并行torchrun --standalone端口冲突，未记为模型错误。测试驱动已改显式静态master地址/端口，正式两组进程使用不同端口。

## 断点和预算契约

完整checkpoint保留原键model/optimizer/ema/update/final_stage/config/args，新增distributed保存不可变配方、源码哈希、各rank RNG、游标和早停标记。原evaluate.py可读取manifest指向的.pt文件。

保存顺序是完整文件刷盘→SHA256→原子提交latest.json→清理本实验上一非final代；最终完成提交final.json。当前没有自动最佳模型标记，其他实验文件不在清理范围。

--stop-after-updates仅限制本次进程的有效更新数，不改变max-updates、warmup或训练顺序。有效更新超过30秒时先保存再退出；STOP/信号在有效更新或评价边界处理。整个AIStation任务的总时间/GPU预算由外层启动器记录执行，不由测速结果隐式追加。

## 当前状态及证据边界

服务器证据目录：`/guohaoran/nexus_topology_flow_overfit50_20261015/preflight_20261015`。

- 实际配方门：logs/distributed_cpu_actual.log。
- 最终恢复门：logs/resume_cpu_gate_final.log，末行包括early_pass_resume=1和speed_stop_saved=1。
- 原压力记录：distributed_cpu_gate/，继续保留失败状态。
- 部分重计算CPU门：[checkpoint_policy_cpu_gate.json](../tools/checkpoint_policy_cpu_gate.json)。

真实2.33B完整checkpoint写入、SHA校验和恢复有界smoke已通过；最终路径、大小、SHA与测试权重清理状态见本文最后的验证补充。

本轮尚无正式T1最终生成分数或成功率。没有因测速改变模型容量、数据、AE权重、latent统计或评分定义。完整可比性限制见[COMPARABILITY_REPORT.md](COMPARABILITY_REPORT.md)。

## 最终真实模型验证补充

2.33B A完整保存3步后恢复至4步，B从S0迁移902张量后完成3步完整保存；SHA及游标/LR已核验。详见[full_checkpoint_verification.json](../results/full_checkpoint_verification.json)。测试权重经再次读回SHA验证后清理；正式A/B仍未启动。真实模型非零头Flash/SDPA：maxabs=1.335144e-5、relative RMS=0.00534095，见[smoke_B_u3_backend.json](../results/smoke_B_u3_backend.json)。
