"""CPU-only, immutable evidence snapshot for original single-GPU Topology T1 runs."""
import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import re
import statistics
import tarfile

COMMIT = '72c993772a91482a3660faa7c83993bfd566cbfe'
EVENTS = {
    'launch': ('topology-t1-launch-20261015', '20261015-topology-002a-codex-t1-launch.md', 'topology: T1 launch'),
    'startup': ('topology-t1-20261015', '20261015-topology-002-codex-t1-startup.md', 'topology: T1 startup'),
    'suspended': ('topology-t1-suspended-20261015', '20261015-topology-002b-codex-t1-suspended.md', 'topology: T1 suspended for instance migration'),
}
SECRET = re.compile(rb'gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|Authorization:\s*(?:Bearer|Basic)\s+[A-Za-z0-9+/=]{16,}')


def encoded(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def digest(content):
    return hashlib.sha256(content).hexdigest()


def jsonfile(path):
    return json.loads(path.read_text()) if path.is_file() else None


def jsonlines(path):
    if not path.is_file():
        return [], False
    data = path.read_bytes()
    complete = data.endswith(b'\n') or not data
    lines = data.splitlines()
    if not complete:
        lines = lines[:-1]  # A concurrently-written last row is not evidence yet.
    return [json.loads(line) for line in lines if line.strip()], not complete


def build(args):
    root, preflight = args.root.resolve(strict=True), args.preflight.resolve(strict=True)
    output = args.output.resolve()
    assert not output.exists(), 'Use a new bundle folder'
    evidence_name, message_name, title = EVENTS[args.event]
    files, missing = {}, []

    def add(path, name=None, optional=False, content=None):
        path = Path(path)
        if content is None:
            if not path.is_file():
                if optional:
                    missing.append(str(path))
                    return
                raise FileNotFoundError(path)
            assert not path.is_symlink(), path
            content = path.read_bytes()
        name = name or str(path.relative_to(root))
        assert name not in files and '..' not in Path(name).parts and not Path(name).is_absolute()
        assert Path(name).suffix in ('.json', '.jsonl', '.md', '.txt', '.py', '.sh', '.log', '.sha256')
        assert len(content) < 25 << 20 and not SECRET.search(content), 'Oversized or credential-bearing evidence'
        files[name] = content

    def pre(name, optional=False):
        path = preflight / name
        add(path, 'preflight/' + name, optional=optional)
        return path

    cpu = pre('logs/cpu_gate.log').read_text()
    assert 'CPU_GATE_OK' in cpu, 'Original CPU gate is not passed'
    cache_text = pre('logs/cache_check.log').read_text()
    assert 'CACHE_OK' in cache_text
    cache = json.JSONDecoder().raw_decode(cache_text.lstrip())[0]
    mu = jsonfile(pre('eval_mu/results.json'))['results']['mu']
    expected = {'edge': {'tp': 154973, 'fp': 125, 'fn': 5}, 'face': {'tp': 102878, 'fp': 870, 'fn': 12}}
    matched = all(mu[k][m] == n for k, counts in expected.items() for m, n in counts.items()) and mu['objects'] == 50
    assert matched, 'VAE mu self-check differs from archived counts'
    tolerance = jsonfile(pre('tolerance/results.json'))['results']
    speed = jsonfile(pre('single_original/speed_check.json'))
    pre('single_original/config.json')
    pre('smoke_B_u3_backend.json', optional=True)
    pre('asset_sha256.txt', optional=True)
    pre('SOURCE_FILES.json', optional=True)
    for name in ('LOG.md', 'SCIENTIFIC_CHANGELOG.md', 'COMPARABILITY_REPORT.md'):
        pre('repro_outputs/' + name, optional=True)

    if args.launch_record:
        launch = jsonfile(args.launch_record)
        add(args.launch_record, 'launch/launch_record.json')
    else:
        launch = None
    for path in args.extra:
        add(path, 'launch/' + path.name)

    runs = {}
    for label, directory in [('A', args.run_a or root / 'A_fresh'), ('B', args.run_b or root / 'B_s0warm')]:
        directory = directory.resolve()
        rows, partial_train = jsonlines(directory / 'train.jsonl')
        probes, partial_probe = jsonlines(directory / 'probes.jsonl')
        cutoff = 500 if args.event == 'startup' else None
        selected = [r for r in rows if cutoff is None or r['update'] <= cutoff]
        selected_probes = [r for r in probes if cutoff is None or r['update'] <= cutoff]
        by_update = {r['update']: r for r in selected}
        by_probe = {r['update']: r for r in selected_probes}
        assert len(by_update) == len(selected), 'Duplicate optimizer updates in run ' + label
        required = [100, 250, 500]
        ready = all(u in by_update and len(by_update[u].get('t_bin_mse', [])) == 10 for u in required) and all(u in by_probe for u in [250, 500])
        if args.event == 'startup':
            assert ready and set(by_update) == set(range(1, 501)), 'Startup requires complete actual updates1-500 and probes250/500 for both runs'
        if rows:
            add(directory / 'train.jsonl', f'runs/{label}/train.jsonl', content=b''.join(encoded(r).replace(b'\n', b'') + b'\n' for r in selected))
        if probes:
            add(directory / 'probes.jsonl', f'runs/{label}/probes.jsonl', content=b''.join(encoded(r).replace(b'\n', b'') + b'\n' for r in selected_probes))
        for pattern in ('config*.json', 'status.json', 'latest.json', 'final.json', 'failure.json', 'evals.jsonl'):
            for path in sorted(directory.glob(pattern)):
                add(path, f'runs/{label}/' + path.name)
        for logname in ('run.log', 'train.log'):
            path = directory / logname
            if path.is_file():
                content = b'\n'.join(path.read_bytes().splitlines()[-250:]) + b'\n'
                add(path, f'runs/{label}/' + logname, content=content)
        config = jsonfile(directory / 'config.json')
        seconds = [r['seconds'] for r in selected if r['update'] > 3 and r.get('seconds', 0) > 0]
        peak = [r.get('peak_gib', r.get('peak_allocated_gib')) for r in selected]
        peak = [p for p in peak if p is not None]
        runs[label] = dict(directory=str(directory), latest_complete_log_update=max([r['update'] for r in rows], default=0),
            reported_updates=len(selected), first_loss=selected[0]['loss'] if selected else None,
            last_loss=selected[-1]['loss'] if selected else None,
            largest_grad_norm=max([r['grad_norm'] for r in selected], default=None),
            seconds_per_update_median=statistics.median(seconds) if seconds else None,
            peak_allocated_gib=max(peak) if peak else None,
            selected_t_bins={str(u): by_update[u]['t_bin_mse'] for u in required if u in by_update},
            selected_probes={str(u): by_probe[u] for u in [250, 500] if u in by_probe},
            first500_ready=ready, incomplete_last_train_row_ignored=partial_train,
            incomplete_last_probe_row_ignored=partial_probe, status=jsonfile(directory / 'status.json'),
            config=config, checkpoint_sidecar=jsonfile(directory / 'latest.json'))

    state = dict(event=args.event, title=title, source_commit=COMMIT, created_utc=datetime.now(timezone.utc).isoformat(),
        source_mode='frozen source snapshot', root=str(root), preflight=str(preflight),
        architecture='S0 DiT 36x1536 and VecSet8x2048; original train.py, one GPU per run',
        cpu_gate_passed=True, cache_check=cache, mu_exact_counts_matched=matched, mu=mu,
        tolerance=tolerance, single_gpu_speed_check=speed, launch_record=launch, runs=runs,
        missing_optional_files=missing, claim_boundary='Training/probe evidence; no claim of successful full-cohort flow generation.')
    add(Path('STATUS.json'), 'STATUS.json', content=encoded(state))
    lines = [f'# {title}', '', f'- Frozen source commit: `{COMMIT}`.',
        f'- Persistent output root: `{root}`.',
        '- Runtime: original single-GPU train.py; Run A and Run B each use one A100. No four-card DDP throughput or 70 GiB occupancy is claimed for this launch.',
        '- Fixed 50 objects, 52,820 GT vertex tokens; point-cloud/normal and GT-vertex conditions. This is Topology Flow, separate from Vertex Diffusion.',
        f'- Event: **{args.event}**. This report does not establish final Flow reconstruction/generation success.', '', '## Preflight', '',
        f'- Original CPU gate: passed. Cache: {cache["objects"]}/50 objects, `d9_center_max_offset={cache["d9_center_max_offset"]}`.',
        '- Mu decoding exactly matches edge TP/FP/FN=154973/125/5 and face TP/FP/FN=102878/870/12.',
        f'- Original single-GPU 20-update speed check: {speed["seconds_per_update_median"]:.4f} s/update, peak allocated {speed["peak_gib_max"]:.3f} GiB; chunk_tokens=0, activation checkpointing enabled.',
        f'- Raw compute estimate for 10,000 updates: {speed["hours_for_max_updates"]:.2f} hours per run, excluding startup, probes, checkpoint saves and evaluations.',
        f'- Speed-check Flash/SDPA comparison: `{json.dumps(speed["attention_backends"])}`. The fresh zero-output head can make this comparison trivial; the nonzero warm-start follow-up is included separately when available.',
        '', '## Frozen VAE decoder noise tolerance', '', '|alpha|edge micro-F1|face micro-F1|joint strict / 50|overflow objects|normalized latent RMSE|', '|---:|---:|---:|---:|---:|---:|']
    for _, value in sorted(tolerance.items(), key=lambda kv: kv[1]['alpha']):
        lines.append(f'|{value["alpha"]}|{value["edge"]["micro_f1"]:.9f}|{value["face"]["micro_f1"]:.9f}|{value["joint_strict"]}/50|{len(value["overflow_objects"])}|{value["latent_rmse_token_weighted"]:.9f}|')
    lines += ['', 'The tested alpha grid brackets the face-F1<0.99 transition; it does not identify a precise tolerance threshold or prove Flow quality.', '', '## Actual A/B training evidence', '', '|run|latest complete logged update|reported loss first / last|max grad norm|median s/update|peak allocated GiB|', '|---|---:|---|---:|---:|---:|']
    for label, run in runs.items():
        lines.append(f'|{label}|{run["latest_complete_log_update"]}|{run["first_loss"]} / {run["last_loss"]}|{run["largest_grad_norm"]}|{run["seconds_per_update_median"]}|{run["peak_allocated_gib"]}|')
    lines += ['', 'For startup reports, loss, gradient and speed summaries use only updates1-500; latest logged update may already be higher.']
    for label, run in runs.items():
        lines += ['', f'### Run {label}: selected t-bin MSE and probes', '']
        for update, bins in run['selected_t_bins'].items():
            lines.append(f'- Update {update}, 10 uniform t bins: `{json.dumps(bins)}`.')
        for update, probe in run['selected_probes'].items():
            lines.append(f'- Update {update}, raw Euler20 seed0 latent RMSE on six fixed size-stratified probe objects: `{json.dumps(probe["raw"]["latent_rmse"], sort_keys=True)}`.')
        if not run['first500_ready']:
            lines.append('- First500 startup evidence is incomplete; no first500 comparison is claimed.')
    lines += ['', 'The probe covers six objects, not the full 50-object topology evaluation. Loss/t-bin values are training diagnostics. Read raw files for checkpoint-save status; a log update is not itself a durable checkpoint.', '', '## Launch / migration record', '', '```json', json.dumps(launch, indent=2), '```', '', '## Evidence boundaries', '', '- Earlier preflight evidence is reused with source hashes and original paths. Current-run metrics are drawn only from these formal run directories.', '- Old experimental/checkpoint directories were read only. No checkpoint or prediction tensor is included in this publication.', '- All original model/loss/sampler code remains frozen. Reporting scripts are external to the source snapshot.', '']
    report = '\n'.join(lines).encode()
    add(Path('REPORT.md'), 'REPORT.md', content=report)
    for name in ('build_topology_report.py', 'publish_topology_report.py'):
        add(Path(__file__).with_name(name), 'scripts/' + name)
    manifest = [{'path': n, 'bytes': len(c), 'sha256': digest(c)} for n, c in sorted(files.items())]
    output.mkdir(parents=True)
    payload = output / 'payload'; payload.mkdir()
    archive_name = 'topology-t1-evidence.tgz'
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode='w:gz') as archive:
        for name, content in sorted(files.items()):
            info = tarfile.TarInfo(name); info.size = len(content); info.mtime = 0
            archive.addfile(info, io.BytesIO(content))
    artifacts = {archive_name: buffer.getvalue(), 'REPORT.md': report, 'STATUS.json': encoded(state), 'FILE_MANIFEST.json': encoded(manifest)}
    for name, content in artifacts.items():
        (payload / name).write_bytes(content)
    upload = [{'path': n, 'bytes': len(c), 'sha256': digest(c)} for n, c in sorted(artifacts.items())]
    (output / 'UPLOAD_MANIFEST.json').write_bytes(encoded(upload))
    (output / 'PUBLICATION_TARGET.json').write_bytes(encoded(dict(evidence_name=evidence_name, message_name=message_name, title=title, archive=archive_name)))
    print(json.dumps(dict(bundle=str(output), event=args.event, files=len(files), archive_bytes=len(artifacts[archive_name]), updates={k:v['latest_complete_log_update'] for k,v in runs.items()})))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--preflight', type=Path, required=True)
    parser.add_argument('--event', choices=EVENTS, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--run-a', type=Path)
    parser.add_argument('--run-b', type=Path)
    parser.add_argument('--launch-record', type=Path)
    parser.add_argument('--extra', type=Path, action='append', default=[])
    build(parser.parse_args())
