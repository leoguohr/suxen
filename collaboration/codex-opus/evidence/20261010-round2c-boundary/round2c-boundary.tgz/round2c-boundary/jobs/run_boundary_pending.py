"""CPU-only Part C for completed final and Part B evaluations; never changes sources."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path('/guohaoran/tmp/nexus_vertex_dense_round2c_20261010')
OLD = Path('/guohaoran/tmp/nexus_vertex_dense_round2_20261009')
CODE = ROOT / 'repo_07bd772/vertex/dense_overfit50_20261009'
COMMIT = 'd7e7117f93b3cd5ec676fc36932d48e90ae2c702'
PY = '/guohaoran/envs/nexus-algo/bin/python'
JOBS = ('J1_item', 'J2_token', 'J3_token_lr5e-6', 'J4_token_copies8',
        'J5_token_fine2', 'J6_token_selfcorrect')
PART_B = (JOBS[2], JOBS[0], JOBS[1], JOBS[4])
JSONS = ('summary.json', 'evaluation.json', 'generation_manifest.json', 'progress.json')


def read(path):
    return json.loads(path.read_text())


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def main():
    cases = {}
    for job in JOBS:
        for weights in ('raw', 'ema'):
            path = OLD / 'runs' / job / 'evals' / f'u009000_{weights}'
            cases[str(path)] = (f'{job}_u009000_{weights}', weights, 20, 9000, 'final')
    for job in PART_B:
        for weights in ('raw', 'ema'):
            for steps in (1, 50):
                name = f'{job}_{weights}_s{steps}'
                cases[str(ROOT / 'decode_test' / name)] = (name, weights, steps, None, 'part_b')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--eval-dir', choices=[p for p, c in cases.items() if c[4] == 'part_b'])
    args = parser.parse_args()
    if args.eval_dir:
        cases = {args.eval_dir: cases[args.eval_dir]}
    (ROOT / 'part_c_followup').mkdir(parents=True, exist_ok=True)
    lock = (ROOT / 'part_c_followup/.boundary.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX)
    assert subprocess.check_output(['git', '-C', str(CODE), 'rev-parse', 'HEAD'], text=True).strip() == COMMIT
    assert subprocess.run(['git', '-C', str(CODE), 'diff', '--quiet', 'HEAD', '--', 'analyze_boundary.py']).returncode == 0
    script = CODE / 'analyze_boundary.py'
    label_manifest = CODE / 'data/prepared_d9/manifest.json'
    manifest = read(label_manifest)
    uids = manifest['train_uids']
    assert len(uids) == len(set(uids)) == 50
    pairs = {(seed, uid) for seed in (97029000, 97029001) for uid in uids}
    label_paths = {label_manifest}
    for record in manifest['records']:
        label_paths.update((CODE / 'data/prepared_d9' / record['label_file'],
                            CODE / 'data' / record['source_label_file']))
    code_identity = {'commit': COMMIT, 'script_sha256': sha(script),
                     'labels_sha256': {str(p): sha(p) for p in sorted(label_paths)}}
    for source, (name, weights, steps, expected_update, kind) in cases.items():
        folder = Path(source)
        missing = [file for file in JSONS if not (folder / file).is_file()]
        if missing:
            print(json.dumps({'case': name, 'state': 'waiting', 'missing': missing}), flush=True)
            continue
        summary, scored, generated, progress = [read(folder / file) for file in JSONS]
        assert progress['expected'] == 100, source
        if progress['generated'] < 100:
            print(json.dumps({'case': name, 'state': 'waiting', 'generated': progress['generated']}), flush=True)
            continue
        assert summary['trees'] == scored['trees'] == progress['generated'] == 100, source
        assert summary['weights'] == scored['weights'] == weights, source
        input_files = {file: folder / file for file in JSONS}
        if kind == 'part_b':
            assert summary['steps_per_depth'] == scored['steps_per_depth'] == steps, source
            assert summary['checkpoint_sha256'] == scored['checkpoint_sha256'], source
        else:
            config_path = folder.parents[1] / 'config.json'
            config = read(config_path)
            assert config['eval_steps'] == steps and config['uids'] == uids, str(config_path)
            assert summary['run_output'] == scored['run_output'] == str(folder.parents[1]), source
            input_files['run/config.json'] = config_path
        update = summary['update']
        assert update == scored['update'] and (expected_update is None or update == expected_update), source
        for rows in (scored['rows'], generated['rows']):
            assert len(rows) == 100 and {(r['seed'], r['uid']) for r in rows} == pairs, source
        assert summary['native_final_sets_exact'] == scored['native_final_sets_exact'] == sum(r['native_final_set_exact'] for r in scored['rows'])
        assert summary['full_trees_exact'] == scored['full_trees_exact'] == sum(r['all_levels_exact'] for r in scored['rows'])
        names = {f'seed-{seed}_{uid}.npz' for seed, uid in pairs}
        assert {p.name for p in (folder / 'predictions').glob('*.npz')} == names, source
        for row in generated['rows']:
            prediction = folder / 'predictions' / f"seed-{row['seed']}_{row['uid']}.npz"
            assert not prediction.is_symlink() and sha(prediction) == row['prediction_sha256'], str(prediction)
        input_hashes = {file: sha(path) for file, path in input_files.items()}
        identity = {'code': code_identity, 'eval_dir': source, 'input_json_sha256': input_hashes}
        output = ROOT / 'part_c_followup' / name
        result, log, receipt = [output / file for file in ('boundary.json', 'boundary.log', 'receipt.json')]
        existed = output.exists()
        if existed:
            assert all(p.is_file() for p in (result, log, receipt)), f'Partial output; preserve {output}'
            previous = read(receipt)
            assert previous['identity'] == identity, f'Changed input/code; preserve {output}'
            assert previous['result_sha256'] == sha(result) and previous['log_sha256'] == sha(log), str(output)
        else:
            output.mkdir(parents=True)
            command = [PY, str(script), '--eval-dir', source, '--output', str(result)]
            env = os.environ | {'CUDA_VISIBLE_DEVICES': '', 'OMP_NUM_THREADS': '8',
                                'PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION': 'python'}
            with log.open('x') as stream:
                done = subprocess.run(command, cwd=CODE, env=env, stdout=stream, stderr=subprocess.STDOUT)
            assert done.returncode == 0, f'Boundary failed ({done.returncode}); preserve {output}'
        reports = read(result)
        assert len(reports) == 1 and reports[0]['eval_dir'] == source and reports[0]['trees'] == 100, str(result)
        report = reports[0]
        curve = [report['exact_within_cells'][str(k)] for k in (0, 1, 2, 4, 8)]
        assert all(isinstance(v, int) and 0 <= v <= 100 for v in curve) and curve == sorted(curve), str(result)
        assert curve[0] == summary['native_final_sets_exact'], str(result)
        assert input_hashes == {file: sha(path) for file, path in input_files.items()}, 'Input changed during analysis'
        if not existed:
            record = {'identity': identity, 'command': command, 'return_code': 0, 'kind': kind,
                      'update': update, 'weights': weights, 'steps_per_depth': steps,
                      'full_trees_exact': summary['full_trees_exact'],
                      'native_final_sets_exact': summary['native_final_sets_exact'],
                      'trees': 100, 'result_sha256': sha(result), 'log_sha256': sha(log)}
            receipt.write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
        print(json.dumps({'case': name, 'state': 'verified_existing' if existed else 'complete',
                          'receipt': str(receipt), 'exact_within_cells': report['exact_within_cells']}), flush=True)


if __name__ == '__main__':
    main()
