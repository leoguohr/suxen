# Round2C Part B: deferred decoding checks

Preparation only. No GPU evaluation or old-job changes were performed. The frozen source is `d7e7117f93b3cd5ec676fc36932d48e90ae2c702` in a separate checkout.

Deploy this external launcher under `/guohaoran/tmp/nexus_vertex_dense_round2c_20261010/jobs/`. The remote checkout must be `/guohaoran/tmp/nexus_vertex_dense_round2c_20261010/repo_07bd772` and the existing interpreter must be `/guohaoran/envs/nexus-algo/bin/python`.

Run Part B in order: `J3_token_lr5e-6`, `J1_item`, `J2_token`, then `J5_token_fine2` later. Each predecessor's decoding status must be complete. Submit each invocation in an AIStation pod with an allocated idle 80GB GPU; a finished training pod may have exited and released its allocation, so its former GPU UUID alone does not grant access. The launcher does not create an allocation or select a GPU automatically.

```bash
/guohaoran/envs/nexus-algo/bin/python -u /guohaoran/tmp/nexus_vertex_dense_round2c_20261010/jobs/run_decode_test.py \
  --job J3_token_lr5e-6 --gpu GPU-<full-UUID-of-allocated-idle-GPU>
```

All new outputs stay under `/guohaoran/tmp/nexus_vertex_dense_round2c_20261010/decode_test`. Original jobs, outputs and locks remain untouched.

Before evaluation, the launcher requires the formal job's `status.json` state `complete`, matching `JOB_COMPLETE` line, nonempty `final.pt`, and raw/EMA 100-tree evaluations at the actual final update. It accepts early completion; it does not assume update 9000. All saved configurations must say `eval_steps=20`. Final training summaries do not embed a step count or checkpoint SHA, so their identity is established by configs, matching update/receipts and the trainer's finalization boundary.

The exact evaluation order is EMA/1 step, raw/1 step, EMA/50 steps, raw/50 steps, followed by the s1 EMA/raw CPU cascade. Fixed cohort: the source manifest's 50 UIDs × seeds 97029000/97029001. `--hash-checkpoint` adds identity metadata without changing decoding. The launcher hashes the approximately 37GB checkpoint once; each evaluator hashes it again, so allow storage I/O time alongside the roughly 40-minute 50-step evaluations.

The requested UUID must be visible in the allocated pod. Before GPU work, `nvidia-smi` must show no compute PID and no more than 256MiB used memory; unsupported/unparseable queries fail. This is an occupancy check, not proof of a platform allocation or a reservation against other users. Platform allocation must provide exclusivity.

Existing decoding outputs skip only after validating the same checkpoint SHA, final update, weights, step count, exact100 seed/UID pairs, aggregate counts and all prediction hashes. A partial, mismatched or failed output stops the launcher; it deletes nothing. Existing cascade output additionally requires matching source commit, s1 manifest hashes and cascade JSON hash. After interruption, inspect any partial output; repair requires separate authorization. This launcher does not resume partial `evaluate.py` runs.

Own state is `<job>_decode_status.json`: `checking`, `evaluating`, `cascade`, `complete`, `failed`, or `interrupted`. It records exact commands, checkpoint SHA, GPU checks, case results and cascade identity. Its new per-job lock prevents duplicate decoding launchers for that job. SIGTERM/SIGINT forwards termination only to the launcher's registered child process group and exits 143; original training processes are never signalled.

This launcher does not publish. Later messages 012+ should put these summaries and cascade log/JSON beside the job's final 20-step raw/EMA summaries. Checkpoints and `predictions/` remain on the server.

## Part C CPU follow-up

The same independent checkout is now pinned to d7e7117. Training and evaluation implementations are unchanged. After each validated Part B case, the launcher runs `run_boundary_pending.py --eval-dir <case>` with CUDA hidden. This includes raw/EMA at both 1 and 50 steps.

Run `CUDA_VISIBLE_DEVICES= PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION=python OMP_NUM_THREADS=8 /guohaoran/envs/nexus-algo/bin/python /guohaoran/tmp/nexus_vertex_dense_round2c_20261010/jobs/run_boundary_pending.py` for a CPU-only scan of all six u9000 raw/EMA evaluations plus all Part B outputs. Missing/incomplete source evaluations wait; partial analyzer outputs fail and remain preserved. Completed analyses skip only when input/code/output identities match. Outputs are under `part_c_followup/`; publish new log/JSON/receipts to codex-opus-exchange. Positive cell tolerances never replace strict vertex-set or all-depth tree acceptance.
