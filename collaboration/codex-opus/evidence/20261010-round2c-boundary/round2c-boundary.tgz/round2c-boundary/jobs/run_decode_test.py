"""Round2C Part B only. Run on a separately allocated, explicitly named idle GPU."""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time

ROOT = Path('/guohaoran/tmp/nexus_vertex_dense_round2c_20261010')
OLD = Path('/guohaoran/tmp/nexus_vertex_dense_round2_20261009')
CODE = ROOT / 'repo_07bd772/vertex/dense_overfit50_20261009'
COMMIT = 'd7e7117f93b3cd5ec676fc36932d48e90ae2c702'
PY = '/guohaoran/envs/nexus-algo/bin/python'
ORDER = ('J3_token_lr5e-6', 'J1_item', 'J2_token', 'J5_token_fine2')
SEEDS = (97029000, 97029001)


def read(path):
    return json.loads(path.read_text())


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(16 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def fingerprint(path):
    st = path.stat()
    return (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns)


def validate(folder, update, weights, pairs, checkpoint=None, digest=None, steps=None):
    summary, scored, manifest, progress = [read(folder / (name + '.json')) for name in
                                           ('summary', 'evaluation', 'generation_manifest', 'progress')]
    assert summary['update'] == scored['update'] == update
    assert summary['weights'] == scored['weights'] == weights
    assert summary['trees'] == scored['trees'] == progress['generated'] == progress['expected'] == 100
    assert len(scored['rows']) == len(manifest['rows']) == 100
    for rows in (scored['rows'], manifest['rows']):
        keys = [(row['seed'], row['uid']) for row in rows]
        assert len(set(keys)) == 100 and set(keys) == pairs
    assert summary['full_trees_exact'] == scored['full_trees_exact'] == sum(row['all_levels_exact'] for row in scored['rows'])
    assert summary['native_final_sets_exact'] == scored['native_final_sets_exact'] == sum(row['native_final_set_exact'] for row in scored['rows'])
    assert summary['per_depth'] == scored['per_depth']
    assert len(summary['per_depth']) == 9
    for depth, aggregate in enumerate(summary['per_depth'], 1):
        levels = [row['levels'][depth - 1] for row in scored['rows']]
        assert aggregate['depth'] == depth and all(level['depth'] == depth for level in levels)
        assert aggregate['full_level_exact'] == sum(level['exact'] for level in levels)
        for key in ('global_cells_tp', 'global_cells_fp', 'global_cells_fn'):
            assert aggregate[key] == sum(level[key] for level in levels)
    if checkpoint is not None:
        for record in (summary, scored):
            assert record['checkpoint'] == str(checkpoint) and record['checkpoint_sha256'] == digest
            assert record['steps_per_depth'] == steps
    names = {f'seed-{seed}_{uid}.npz' for seed, uid in pairs}
    assert {path.name for path in (folder / 'predictions').glob('*.npz')} == names
    for row in manifest['rows']:
        path = folder / 'predictions' / f"seed-{row['seed']}_{row['uid']}.npz"
        assert not path.is_symlink() and sha(path) == row['prediction_sha256']
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--job', required=True, choices=ORDER)
    parser.add_argument('--gpu', required=True, help='Full GPU UUID from the allocated platform pod')
    args = parser.parse_args()
    assert re.fullmatch(r'GPU-[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}', args.gpu), 'Supply a full GPU UUID; no index/automatic choice'
    out = ROOT / 'decode_test'
    out.mkdir(parents=True, exist_ok=True)
    lock = (out / (args.job + '.lock')).open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    state_path = out / (args.job + '_decode_status.json')
    state = {'state': 'checking', 'job': args.job, 'gpu_uuid': args.gpu, 'code_commit': COMMIT,
             'started_unix': time.time(), 'cases': [], 'gpu_checks': []}
    process = None

    def save():
        tmp = state_path.with_suffix('.json.tmp')
        tmp.write_text(json.dumps(state, indent=2, allow_nan=False) + '\n')
        tmp.replace(state_path)

    def stop(signum, frame):
        if process is not None and process.poll() is None:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
        state.update(state='interrupted', ended_unix=time.time())
        save()
        raise SystemExit(143)

    def run(command, log, env):
        nonlocal process
        with log.open('x') as stream:
            process = subprocess.Popen(command, cwd=CODE, env=env, stdout=stream,
                                       stderr=subprocess.STDOUT, start_new_session=True)
            try:
                return_code = process.wait()
            finally:
                process = None
        assert return_code == 0, f'Own evaluation/analysis failed ({return_code}); preserve {log}'

    def idle_gpu():
        prefix = ['nvidia-smi', '-i', args.gpu]
        pids = subprocess.check_output(prefix + ['--query-compute-apps=pid', '--format=csv,noheader,nounits'], text=True).strip()
        line = subprocess.check_output(prefix + ['--query-gpu=uuid,memory.used,memory.total', '--format=csv,noheader,nounits'], text=True).strip()
        uuid, used, total = [item.strip() for item in line.split(',')]
        assert uuid == args.gpu and not pids, 'Requested GPU has a compute process; refuse'
        assert float(used) <= 256 and float(total) >= 75 * 1024, 'Requested GPU is occupied or not 80GB class; refuse'
        state['gpu_checks'].append({'unix': time.time(), 'uuid': uuid, 'memory_used_mib': float(used), 'memory_total_mib': float(total), 'compute_pids': []})
        save()

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    save()
    try:
        assert subprocess.check_output(['git', '-C', str(CODE), 'rev-parse', 'HEAD'], text=True).strip() == COMMIT
        assert subprocess.run(['git', '-C', str(CODE), 'diff', '--quiet', 'HEAD', '--', '.']).returncode == 0
        position = ORDER.index(args.job)
        if position:
            assert read(out / (ORDER[position - 1] + '_decode_status.json'))['state'] == 'complete', 'Run preceding Part B job first'
        job = OLD / 'runs' / args.job
        finished = read(job / 'status.json')
        assert finished['state'] == 'complete', 'Formal job is not complete'
        update = int(finished['update'])
        checkpoint = job / 'final.pt'
        assert checkpoint.is_file() and checkpoint.stat().st_size > 0 and finished['final'] == str(checkpoint)
        marker = f'JOB_COMPLETE updates={update} final={checkpoint}'
        assert any(marker in path.read_text().splitlines() for path in (OLD / 'job_logs' / args.job).glob('console-*.log')), 'No matching JOB_COMPLETE log'
        configs = [read(path) for path in job.glob('config*.json')]
        uids = read(CODE / 'data/prepared_d9/manifest.json')['train_uids']
        assert len(uids) == len(set(uids)) == 50 and configs
        assert all(config['eval_steps'] == 20 and config['uids'] == uids for config in configs)
        pairs = {(seed, uid) for seed in SEEDS for uid in uids}
        receipts = {(row['update'], row['weights']): row for row in map(json.loads, (job / 'evals.jsonl').read_text().splitlines())}
        baseline = {}
        for weights in ('raw', 'ema'):
            summary = validate(job / 'evals' / f'u{update:06d}_{weights}', update, weights, pairs)
            receipt = receipts[(update, weights)]
            assert summary['run_output'] == str(job) and receipt['full_trees_exact'] == summary['full_trees_exact']
            assert receipt['per_depth_exact'] == [row['full_level_exact'] for row in summary['per_depth']]
            baseline[weights] = summary
        idle_gpu()
        original = fingerprint(checkpoint)
        digest = sha(checkpoint)
        assert fingerprint(checkpoint) == original
        state.update(final_update=update, checkpoint=str(checkpoint), checkpoint_sha256=digest, final_20step=baseline)
        env = os.environ.copy()
        env.update(CUDA_VISIBLE_DEVICES=args.gpu, PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION='python', OMP_NUM_THREADS='8')
        env.pop('NEXUS_SKIP_COARSE_PROBES', None)
        for weights, steps in (('ema', 1), ('raw', 1), ('ema', 50), ('raw', 50)):
            folder = out / f'{args.job}_{weights}_s{steps}'
            row = {'weights': weights, 'steps': steps, 'output': str(folder)}
            state['cases'].append(row)
            if folder.exists():
                summary = validate(folder, update, weights, pairs, checkpoint, digest, steps)
                row.update(state='validated_existing', summary=summary)
            else:
                idle_gpu()
                assert fingerprint(checkpoint) == original
                command = [PY, '-u', 'evaluate.py', '--checkpoint', str(checkpoint), '--weights', weights,
                           '--steps', str(steps), '--hash-checkpoint', '--output', str(folder)]
                row.update(state='running', command=command, started_unix=time.time())
                state['state'] = 'evaluating'
                save()
                run(command, folder.with_suffix('.log'), env)
                assert fingerprint(checkpoint) == original
                assert 'EVALUATION_COMPLETE' in folder.with_suffix('.log').read_text()
                row.update(state='complete', return_code=0, ended_unix=time.time(), summary=validate(folder, update, weights, pairs, checkpoint, digest, steps))
            save()
            # Analyze each completed output on CPU before the next GPU case.
            boundary_command = [PY, str(ROOT / 'jobs/run_boundary_pending.py'), '--eval-dir', str(folder)]
            row['boundary_command'] = boundary_command
            subprocess.run(boundary_command, check=True, env=env | {'CUDA_VISIBLE_DEVICES': ''})
            row['boundary_cpu_complete'] = True
            save()
        cascade = out / (args.job + '_s1_cascade.json')
        receipt = cascade.with_suffix('.receipt.json')
        inputs = [out / (args.job + '_' + weights + '_s1') for weights in ('ema', 'raw')]
        input_hashes = {str(path): sha(path / 'generation_manifest.json') for path in inputs}
        identity = {'checkpoint_sha256': digest, 'code_commit': COMMIT, 'input_manifest_sha256': input_hashes}
        if cascade.exists() or receipt.exists():
            previous = read(receipt)
            assert previous['identity'] == identity and previous['cascade_sha256'] == sha(cascade), 'Partial or mismatched cascade output; refuse'
        else:
            command = [PY, 'analyze_cascade.py', '--eval-dir', str(inputs[0]), '--eval-dir', str(inputs[1]), '--output', str(cascade)]
            state.update(state='cascade', cascade_command=command)
            save()
            run(command, cascade.with_suffix('.log'), env | {'CUDA_VISIBLE_DEVICES': ''})
            receipt.write_text(json.dumps({'identity': identity, 'command': command, 'return_code': 0, 'cascade_sha256': sha(cascade)}, indent=2) + '\n')
        reports = read(cascade)
        assert len(reports) == 2 and [row['eval_dir'] for row in reports] == [str(path) for path in inputs]
        assert all(row['trees'] == 100 for row in reports)
        state.update(state='complete', ended_unix=time.time(), cascade=str(cascade), cascade_identity=identity)
        save()
        print('DECODE_TEST_COMPLETE', args.job, update, digest, flush=True)
    except Exception as error:
        state.update(state='failed', error=repr(error), ended_unix=time.time())
        save()
        raise


if __name__ == '__main__':
    main()
