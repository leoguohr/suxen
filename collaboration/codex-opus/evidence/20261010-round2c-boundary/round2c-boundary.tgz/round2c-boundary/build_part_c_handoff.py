"""Package Part C CPU results and the deferred CPU analysis integration."""
from pathlib import Path
import hashlib
import json
import shutil
import tarfile

ROOT = Path('/guohaoran/tmp/nexus_vertex_dense_round2c_20261010')
OUT = ROOT / 'handoff012'
NAME = 'round2c-boundary'
MESSAGE = '20261010-012-codex-round2c-boundary.md'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    stage = OUT / NAME
    stage.mkdir(parents=True, exist_ok=False)
    sources = [ROOT / 'part_c' / name for name in
               ('round2_boundary.json', 'round2_boundary.log', 'part_c_receipt.json')]
    sources += [ROOT / name for name in ('run_part_c.py', 'build_part_c_handoff.py', 'STATE.json')]
    sources += [ROOT / 'jobs' / name for name in
                ('run_boundary_pending.py', 'run_decode_test.py', 'README.md', 'boundary_integration_checks.json')]
    code = ROOT / 'repo_07bd772/vertex/dense_overfit50_20261009'
    sources += [code / name for name in ('analyze_boundary.py', 'CODEX_PROMPT_ROUND2C.md')]
    for source in sources:
        relative = source.relative_to(ROOT) if source.is_relative_to(ROOT / 'jobs') else Path(source.name)
        target = stage / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    receipt = json.loads((stage / 'part_c_receipt.json').read_text())
    reports = json.loads((stage / 'round2_boundary.json').read_text())
    assert len(reports) == len(receipt['inputs']) == 6
    text = ['# Codex → Opus: Round2C Part C boundary check', '',
            'Executed the unmodified analyzer from `d7e7117f93b3cd5ec676fc36932d48e90ae2c702` in the same independent checkout. '
            'The six requested evaluations contain 600 trees with verified prediction hashes, 50 UIDs and seeds 97029000/97029001 per evaluation. '
            'CPU only; no torch/model/GPU execution or training changes.', '',
            '| Evaluation | Full-tree strict | Final-set strict (0 cells) | ≤1 cell | ≤2 cells | ≤4 cells | ≤8 cells | Wrong count | Incomplete |',
            '|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    for item, result in zip(receipt['inputs'], reports):
        assert result['eval_dir'] == item['eval_dir'] and result['trees'] == 100
        values = result['exact_within_cells']
        assert values['0'] == item['native_final_sets_exact']
        cells = ' | '.join(str(values[str(k)]) + '/100' for k in (0, 1, 2, 4, 8))
        text.append(f"| {item['run']} u{item['update']} raw | {item['full_trees_exact']}/100 | {cells} | "
                    f"{result['count_mismatch_trees']} | {result['incomplete_trees']} |")
    text += ['', '| Evaluation | Matched one-cell pairs, single-vertex GT cell | Diagonal pairs | Share within 0.1 crossed cell face | Share within 0.25 | Median crossed-face distance |',
             '|---|---:|---:|---:|---:|---:|']
    def fmt(value):
        return 'n/a' if value is None else f'{value:.4f}'
    for item, result in zip(receipt['inputs'], reports):
        text.append(f"| {item['run']} u{item['update']} | {result['shifted_pairs_single_vertex']} | {result['shifted_pairs_diagonal']} | "
                    f"{fmt(result['crossing_distance_share_le_0.1'])} | {fmt(result['crossing_distance_share_le_0.25'])} | "
                    f"{fmt(result['crossing_distance_median'])} |")
    text += ['', 'Metric boundaries:', '',
             '- Zero-cell exact is the final D9 vertex-set metric; all-depth full-tree exact is reported separately.',
             '- Positive tolerances require equal set counts and a one-to-one Chebyshev-distance matching of unmatched FN/FP cells. These are diagnostics, not replacements for strict acceptance. Predictions are not repaired.',
             '- Positions inside a D9 cell are estimated from D15 label-cell centers: ((v & 63) + 0.5) / 64. These are not original floating-point vertices.',
             '- Crossed-face statistics include matched pairs from count-mismatched trees. Multi-axis distances use the maximum across moved axes. The script\'s uniform 10%/25% reference is not a matched null model for the mixed diagonal population.', '',
             f"Analyzer time: {receipt['seconds']:.2f} seconds. The log, JSON, input/label/code hashes and exact command are in the archive.", '',
             'Deferred integration:', '',
             '- `jobs/run_boundary_pending.py` scans all six u009000 raw/EMA evaluations and all 16 Part B outputs; incomplete evaluations wait. Validated analyses are deduplicated by input/code/output hashes.',
             '- The Part B launcher invokes the CPU boundary helper after each validated output. Its pinned commit was updated because the shared independent checkout advanced; evaluator/training code is unchanged.',
             '- The previous deferred-evaluation automation no longer exists. A new hourly CPU-only follow-up (nexus-round2c) covers final/Part B outputs and publication; it does not launch GPU jobs. All 28 future inputs currently wait. The prepared Part B launcher will perform boundary analysis when externally started. This turn did not launch GPU work.', '',
             '[Compressed log, JSON and provenance](../evidence/20261010-round2c-boundary/README.md)', '']
    report = '\n'.join(text)
    (stage / 'REPORT.md').write_text(report)
    (OUT / MESSAGE).write_text(report)
    files = sorted(path for path in stage.rglob('*') if path.is_file())
    assert all(path.suffix not in {'.pt', '.npz'} and 'predictions' not in path.parts for path in files)
    (stage / 'SHA256SUMS').write_text(''.join(f'{sha(path)}  {path.relative_to(stage)}\n' for path in files))
    archive = OUT / (NAME + '.tgz')
    with tarfile.open(archive, 'w:gz') as tar:
        for path in sorted(stage.rglob('*')):
            if path.is_file():
                tar.add(path, arcname=NAME + '/' + str(path.relative_to(stage)), recursive=False)
    package = {'file': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive),
               'files': len(files) + 1, 'evaluations': 6, 'trees': 600, 'commit': receipt['commit'],
               'excluded': ['*.pt', '*.npz', 'predictions/', 'credentials']}
    (OUT / 'PACKAGE.json').write_text(json.dumps(package, indent=2) + '\n')
    (OUT / 'README.md').write_text('# Round2C boundary evidence\n\n[Compressed records](' + archive.name +
                                 ') · [Manifest](PACKAGE.json)\n\nSHA256: `' + package['sha256'] + '`\n')
    print('PACKAGE_READY', json.dumps(package), flush=True)


if __name__ == '__main__':
    main()
