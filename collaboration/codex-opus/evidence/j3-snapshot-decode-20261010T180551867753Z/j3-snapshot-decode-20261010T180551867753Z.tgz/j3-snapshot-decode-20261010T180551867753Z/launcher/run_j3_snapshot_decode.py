"""Evaluate one frozen J3 snapshot; never reads or controls running training jobs.

python run_j3_snapshot_decode.py --snapshot-dir /path/to/snapshot --gpu GPU-<full-UUID>
The snapshot directory contains checkpoint.pt and CHECKPOINT_IDENTITY.json.
"""
import argparse
import fcntl
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time

from run_decode_test import CODE, COMMIT, PY, SEEDS, fingerprint, read, sha, validate


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--snapshot-dir', type=Path, required=True)
    parser.add_argument('--gpu', required=True, help='Full UUID of the allocated idle GPU')
    args = parser.parse_args()
    assert re.fullmatch(r'GPU-[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}', args.gpu), 'Full GPU UUID required'
    snapshot = args.snapshot_dir.resolve(strict=True)
    lock = (snapshot / '.decode.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    state_path = snapshot / 'decode_status.json'
    state = {'state': 'checking', 'gpu_uuid': args.gpu, 'code_commit': COMMIT,
             'started_unix': time.time(), 'cases': [], 'gpu_checks': []}
    process = None

    def save():
        temporary = state_path.with_suffix('.json.tmp')
        temporary.write_text(json.dumps(state, indent=2, allow_nan=False) + '\n')
        temporary.replace(state_path)

    def stop(signum, frame):
        if process is not None and process.poll() is None:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
        state.update(state='interrupted', ended_unix=time.time())
        save()
        raise SystemExit(143)

    def run(command, log, env):
        nonlocal process
        with log.open('x') as stream:
            process = subprocess.Popen(command, cwd=CODE, env=env, stdout=stream,
                                       stderr=subprocess.STDOUT, start_new_session=True)
            try:
                return_code = process.wait()
            finally:
                process = None
        assert return_code == 0, f'Child failed ({return_code}); preserve {log}'

    def idle_gpu():
        prefix = ['nvidia-smi', '-i', args.gpu]
        pids = subprocess.check_output(prefix + ['--query-compute-apps=pid', '--format=csv,noheader,nounits'], text=True).strip()
        line = subprocess.check_output(prefix + ['--query-gpu=uuid,memory.used,memory.total', '--format=csv,noheader,nounits'], text=True).strip()
        uuid, used, total = [item.strip() for item in line.split(',')]
        assert uuid == args.gpu and not pids, 'Allocated GPU has a compute process; refuse'
        assert float(used) <= 256 and float(total) >= 75 * 1024, 'Allocated GPU is occupied or not 80GB class; refuse'
        state['gpu_checks'].append({'unix': time.time(), 'uuid': uuid, 'memory_used_mib': float(used),
                                    'memory_total_mib': float(total), 'compute_pids': []})
        save()

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    save()
    try:
        assert subprocess.check_output(['git', '-C', str(CODE), 'rev-parse', 'HEAD'], text=True).strip() == COMMIT
        assert subprocess.run(['git', '-C', str(CODE), 'diff', '--quiet', 'HEAD', '--', '.']).returncode == 0
        identity_path = snapshot / 'CHECKPOINT_IDENTITY.json'
        identity = read(identity_path)
        checkpoint = snapshot / 'checkpoint.pt'
        declared = Path(identity['checkpoint'])
        if not declared.is_absolute():
            declared = snapshot / declared
        assert declared == checkpoint and checkpoint.is_file() and not checkpoint.is_symlink()
        assert identity['code_commit'] == COMMIT and identity['has_model'] is True and identity['has_ema'] is True
        assert identity['source_path'].endswith('/J3_token_lr5e-6/latest.pt') and identity['source_stat']
        update, digest = identity['update'], identity['sha256']
        assert isinstance(update, int) and update > 0 and re.fullmatch('[0-9a-f]{64}', digest)
        original = fingerprint(checkpoint)
        assert sha(checkpoint) == digest and fingerprint(checkpoint) == original, 'Frozen checkpoint identity mismatch'
        manifest_path = CODE / 'data/prepared_d9/manifest.json'
        manifest = read(manifest_path)
        uids = manifest['train_uids']
        assert len(uids) == len(set(uids)) == 50
        assert identity['source_config']['uids'] == uids and identity['source_config']['eval_steps'] == 20
        pairs = {(seed, uid) for seed in SEEDS for uid in uids}
        labels = {manifest_path}
        for record in manifest['records']:
            labels.update((CODE / 'data/prepared_d9' / record['label_file'], CODE / 'data' / record['source_label_file']))
        label_hashes = {str(path): sha(path) for path in sorted(labels)}
        state.update(checkpoint=str(checkpoint), checkpoint_sha256=digest, update=update,
                     checkpoint_identity_sha256=sha(identity_path), checkpoint_identity=identity)
        env = os.environ | {'CUDA_VISIBLE_DEVICES': args.gpu, 'OMP_NUM_THREADS': '8',
                            'PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION': 'python'}
        env.pop('NEXUS_SKIP_COARSE_PROBES', None)
        output = snapshot / 'decode_test'
        output.mkdir(exist_ok=True)
        for steps in (1, 20, 50):
            for weights in ('ema', 'raw'):
                folder = output / f'{weights}_s{steps}'
                log, receipt = folder.with_suffix('.log'), folder.with_suffix('.receipt.json')
                command = [PY, '-u', 'evaluate.py', '--checkpoint', str(checkpoint), '--weights', weights,
                           '--steps', str(steps), '--hash-checkpoint', '--output', str(folder)]
                case_identity = {'checkpoint_sha256': digest, 'update': update, 'weights': weights,
                                 'steps_per_depth': steps, 'code_commit': COMMIT, 'labels_sha256': label_hashes}
                row = {'weights': weights, 'steps': steps, 'output': str(folder), 'command': command, 'analyses': []}
                state['cases'].append(row)
                assert fingerprint(checkpoint) == original, 'Frozen checkpoint changed'
                existed = folder.exists() or log.exists() or receipt.exists()
                if existed:
                    assert folder.is_dir() and log.is_file() and receipt.is_file(), f'Partial evaluation; preserve {folder}'
                    previous = read(receipt)
                    assert previous['identity'] == case_identity and previous['command'] == command, f'Mismatched evaluation; preserve {folder}'
                    assert previous['log_sha256'] == sha(log), f'Changed evaluation log; preserve {log}'
                    row.update(state='validated_existing', started_unix=previous['started_unix'], ended_unix=previous['ended_unix'])
                else:
                    idle_gpu()
                    row.update(state='running', started_unix=time.time())
                    state['state'] = 'evaluating'
                    save()
                    run(command, log, env)
                    row.update(state='complete', return_code=0, ended_unix=time.time())
                assert fingerprint(checkpoint) == original, 'Frozen checkpoint changed'
                assert 'EVALUATION_COMPLETE' in log.read_text(), f'Incomplete evaluation log; preserve {log}'
                summary = validate(folder, update, weights, pairs, checkpoint, digest, steps)
                row['summary'] = summary
                inputs = {name: sha(folder / name) for name in ('summary.json', 'evaluation.json', 'generation_manifest.json', 'progress.json')}
                if existed:
                    assert previous['input_json_sha256'] == inputs, f'Changed evaluation JSON; preserve {folder}'
                else:
                    receipt.write_text(json.dumps({'identity': case_identity, 'command': command, 'return_code': 0,
                                                  'started_unix': row['started_unix'], 'ended_unix': row['ended_unix'],
                                                  'input_json_sha256': inputs, 'log_sha256': sha(log)}, indent=2) + '\n')
                save()
                for kind in ('boundary', 'cascade'):
                    script = CODE / f'analyze_{kind}.py'
                    result, analysis_log, analysis_receipt = [folder / f'{kind}{suffix}' for suffix in ('.json', '.log', '.receipt.json')]
                    analysis_identity = {'evaluation': case_identity, 'input_json_sha256': inputs, 'script_sha256': sha(script)}
                    analysis_command = [PY, str(script), '--eval-dir', str(folder), '--output', str(result)]
                    analysis = {'kind': kind, 'command': analysis_command, 'output': str(result)}
                    row['analyses'].append(analysis)
                    analysis_existed = any(path.exists() for path in (result, analysis_log, analysis_receipt))
                    if analysis_existed:
                        assert all(path.is_file() for path in (result, analysis_log, analysis_receipt)), f'Partial analysis; preserve {folder}/{kind}.*'
                        prior = read(analysis_receipt)
                        assert prior['identity'] == analysis_identity and prior['command'] == analysis_command
                        assert prior['result_sha256'] == sha(result) and prior['log_sha256'] == sha(analysis_log)
                        analysis.update(state='validated_existing', started_unix=prior['started_unix'], ended_unix=prior['ended_unix'])
                    else:
                        state['state'] = kind
                        analysis.update(state='running', started_unix=time.time())
                        save()
                        run(analysis_command, analysis_log, env | {'CUDA_VISIBLE_DEVICES': ''})
                        analysis.update(state='complete', return_code=0, ended_unix=time.time())
                    reports = read(result)
                    assert len(reports) == 1 and reports[0]['eval_dir'] == str(folder) and reports[0]['trees'] == 100
                    if kind == 'boundary':
                        curve = [reports[0]['exact_within_cells'][str(k)] for k in (0, 1, 2, 4, 8)]
                        assert all(isinstance(value, int) and 0 <= value <= 100 for value in curve) and curve == sorted(curve)
                        assert curve[0] == summary['native_final_sets_exact']
                    else:
                        assert set(reports[0]['per_depth']) == {str(depth) for depth in range(1, 10)}
                        assert all('dead_parents' in values for values in reports[0]['per_depth'].values())
                    assert inputs == {name: sha(folder / name) for name in inputs}, 'Evaluation input changed during analysis'
                    if not analysis_existed:
                        analysis_receipt.write_text(json.dumps({'identity': analysis_identity, 'command': analysis_command,
                                                              'return_code': 0, 'started_unix': analysis['started_unix'],
                                                              'ended_unix': analysis['ended_unix'], 'result_sha256': sha(result),
                                                              'log_sha256': sha(analysis_log)}, indent=2) + '\n')
                    save()
        assert fingerprint(checkpoint) == original, 'Frozen checkpoint changed'
        state.update(state='complete', ended_unix=time.time())
        save()
        print('J3_SNAPSHOT_DECODE_COMPLETE', update, digest, flush=True)
    except Exception as error:
        state.update(state='failed', error=repr(error), ended_unix=time.time())
        save()
        raise


if __name__ == '__main__':
    main()
