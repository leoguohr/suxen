"""Run Part E once, then invoke the shared completion publisher once."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time

PY = '/guohaoran/envs/nexus-algo/bin/python'
JOBS = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--snapshot-dir', type=Path, required=True)
    parser.add_argument('--gpu', required=True)
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    credential = json.load(sys.stdin)
    snapshot = args.snapshot_dir.resolve(strict=True)
    command = [PY, '-u', str(JOBS / 'run_j3_part_e.py'), '--phase', 'gpu',
               '--snapshot-dir', str(snapshot), '--gpu', args.gpu]
    if not args.run:
        assert not (snapshot / 'PART_E_GPU_LAUNCH.json').exists(), 'Already launched'
        wrapper = [PY, '-u', str(Path(__file__).resolve()), '--run',
                   '--snapshot-dir', str(snapshot), '--gpu', args.gpu]
        with (snapshot / 'part_e/pipeline.log').open('x') as log:
            child = subprocess.Popen(wrapper, stdin=subprocess.PIPE, stdout=log,
                                     stderr=subprocess.STDOUT, start_new_session=True)
        child.stdin.write(json.dumps(credential).encode())
        child.stdin.close()
        receipt = {'pid': child.pid, 'hostname': os.uname().nodename,
                   'started_unix': time.time(), 'gpu': args.gpu,
                   'evaluation_command': command,
                   'publication': 'One completion callback; no schedule or polling'}
        (snapshot / 'PART_E_GPU_LAUNCH.json').write_text(json.dumps(receipt, indent=2) + '\n')
        print(json.dumps(receipt), flush=True)
        return
    result = subprocess.run(command, stdin=subprocess.DEVNULL)
    receipt = {'evaluation_return_code': result.returncode, 'ended_unix': time.time()}
    (snapshot / 'PART_E_GPU_EXIT.json').write_text(json.dumps(receipt, indent=2) + '\n')
    published = subprocess.run(
        [PY, '-u', str(JOBS / 'publish_j3_snapshot_decode.py'), '--snapshot-dir', str(snapshot)],
        input=json.dumps(credential).encode())
    receipt.update(publication_return_code=published.returncode, publication_ended_unix=time.time())
    (snapshot / 'PART_E_PIPELINE_EXIT.json').write_text(json.dumps(receipt, indent=2) + '\n')
    raise SystemExit(result.returncode or published.returncode)


if __name__ == '__main__':
    main()
