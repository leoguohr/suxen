"""One-shot server publication. --snapshot-dir PATH; stdin is JSON {"token": ...}."""
import argparse
import base64
from datetime import datetime, timezone
import fcntl
import hashlib
import io
import json
import math
from pathlib import Path
import re
import subprocess
import sys
import tarfile
import urllib.error
import urllib.request

API = 'https://api.github.com/repos/leoguohr/suxen'
BRANCH = 'codex-opus-exchange'
PREFIX = 'collaboration/codex-opus/'
SEEDS = (97029000, 97029001)
JSONS = ('summary.json', 'evaluation.json', 'generation_manifest.json', 'progress.json')
PART_E_COMMIT = 'e7c85bf2b82fdc6ee15eb59be20486ffc7853fa4'
PART_E_GATE = 'cpu_gate_e7c85bf'
PART_C = (('J1_item', 5400), ('J2_token', 5400), ('J3_token_lr5e-6', 5400), ('J5_token_fine2', 3600), ('J6_token_selfcorrect', 5400), ('J3_token_lr5e-6', 3600))
SOURCE_FILES = ('tests/test_cpu.py', 'common.py', 'samplers.py', 'evaluate.py', 'analyze_boundary.py')
BOUNDARIES = tuple(f'euler_{weights}_s{steps}' for steps in (1, 20, 50) for weights in ('ema', 'raw')) + ('dpm2m_ema_s20', 'dpm2m_raw_s20', 'partc_J1_u005400_raw', 'partc_J2_u005400_raw', 'partc_J3_u005400_raw', 'partc_J5_u003600_raw', 'partc_J6_u005400_raw', 'partc_J3_u003600_raw')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def api(path, token, data=None, method=None):
    request = urllib.request.Request(API + path, data=None if data is None else encoded(data), method=method,
        headers={'Authorization': 'Bearer ' + token, 'Accept': 'application/vnd.github+json',
                 'Content-Type': 'application/json', 'User-Agent': 'nexus-j3-snapshot-publication'})
    with urllib.request.urlopen(request, timeout=120) as response:
        return json.load(response)


def maybe_run_part_e(snapshot):
    approval = snapshot / 'PART_E_APPROVED.json'
    launch, exited = snapshot / 'PART_E_LAUNCH.json', snapshot / 'PART_E_EXIT.json'
    if not approval.exists():
        return True
    record = {'state': 'checking', 'started_utc': datetime.now(timezone.utc).isoformat()}
    try:
        approved = json.loads(approval.read_text())
        identity = json.loads((snapshot / 'CHECKPOINT_IDENTITY.json').read_text())
        assert approved['approved'] is True and approved['code_commit'] == PART_E_COMMIT
        assert approved['checkpoint_sha256'] == identity['sha256'] and approved['update'] == identity['update']
        assert approved['resource_change_approved'] is True
        for field in ('gpu_uuid', 'euler_gpu_uuid'):
            assert re.fullmatch(r'GPU-[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}', approved[field])
        euler_state = json.loads((snapshot / 'decode_status.json').read_text())
        assert approved['euler_gpu_uuid'] == euler_state['gpu_uuid']
        state_path = snapshot / 'part_e/status.json'
        state = json.loads(state_path.read_text()) if state_path.exists() else {'state': 'not_started'}
        if state['state'] not in ('gpu_complete', 'complete', 'failed', 'interrupted') or euler_state['state'] not in ('complete', 'failed', 'interrupted'):
            (snapshot / 'PART_E_HANDOFF.json').write_bytes(encoded({'state': 'deferred', 'euler_state': euler_state['state'], 'part_e_state': state['state'], 'reason': 'Other worker completion callback owns the next attempt; no polling'}))
            return False
        if state['state'] in ('complete', 'failed', 'interrupted') or launch.exists():
            return True
        if euler_state['state'] != 'complete':
            record.update(state='skipped', reason='Original six-case evaluation did not complete')
        else:
            command = [sys.executable, '-u', str(Path(__file__).with_name('run_j3_part_e.py')), '--phase', 'boundary', '--snapshot-dir', str(snapshot)]
            record.update(state='launched', command=command)
            with launch.open('x') as stream:
                stream.write(encoded(record).decode())
            with (snapshot / 'part_e_hook.log').open('x') as log:
                result = subprocess.run(command, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
            record.update(state='exited', return_code=result.returncode)
    except (AssertionError, KeyError, TypeError, ValueError, OSError) as error:
        record.update(state='failed', error=type(error).__name__ + ': Part E invocation failed')
    record['ended_utc'] = datetime.now(timezone.utc).isoformat()
    exited.write_bytes(encoded(record))
    return True


def collect_part_e(snapshot, files, report, add, read):
    for name in ('PART_E_APPROVED.json', 'PART_E_LAUNCH.json', 'PART_E_EXIT.json', 'PART_E_HANDOFF.json', 'PART_E_GPU_LAUNCH.json', 'PART_E_GPU_EXIT.json', 'PART_E_PIPELINE_EXIT.json', 'part_e_hook.log', 'part_e/status.json', 'part_e/pipeline.log', f'part_e/{PART_E_GATE}.log', f'part_e/{PART_E_GATE}.receipt.json'):
        if (snapshot / name).exists():
            add(snapshot / name)
    add(Path(__file__).with_name('run_j3_part_e.py'), 'launcher/run_j3_part_e.py')
    starter = Path(__file__).with_name('start_j3_part_e.py')
    if starter.exists():
        add(starter, 'launcher/start_j3_part_e.py')
    state = read('part_e/status.json') if 'part_e/status.json' in files else {'state': 'not_started'}
    assert state['state'] in ('complete', 'failed', 'interrupted', 'gpu_complete', 'not_started'), 'Part E is still active; refuse publication'
    part = {'state': state['state'], 'code_commit': PART_E_COMMIT, 'cpu_gate_validated': False, 'cases': [], 'boundaries': []}
    if 'PART_E_EXIT.json' in files:
        invocation = read('PART_E_EXIT.json')
        part['boundary_invocation'] = invocation
        if invocation['state'] == 'failed' or invocation.get('return_code', 0) != 0:
            part['state'] = 'failed'
    part['resource_change'] = {key: read('PART_E_APPROVED.json')[key] for key in ('gpu_uuid', 'euler_gpu_uuid', 'resource_change_approved')}
    report['part_e'] = part
    identity = read('CHECKPOINT_IDENTITY.json')
    pairs = {(seed, uid) for seed in SEEDS for uid in identity['source_config']['uids']}
    part['source_identity_validated'] = state.get('code_commit') == PART_E_COMMIT and state.get('euler_code_commit') == identity['code_commit'] and state.get('checkpoint_sha256') == identity['sha256'] and state.get('update') == identity['update'] and state.get('gpu_uuid') == part['resource_change']['gpu_uuid']
    code = snapshot.parents[1] / 'repo_2449388/vertex/dense_overfit50_20261009'
    for name in SOURCE_FILES:
        if (code / name).exists():
            add(code / name, 'part_e/source/' + name)
    try:
        gate = read(f'part_e/{PART_E_GATE}.receipt.json')
        assert gate['code_commit'] == PART_E_COMMIT and gate['return_code'] == 0
        assert gate['log_sha256'] == sha(files[f'part_e/{PART_E_GATE}.log']) and b'ALL CPU TESTS PASSED' in files[f'part_e/{PART_E_GATE}.log']
        assert all(gate['source_files_sha256'][name] == sha(files['part_e/source/' + name]) for name in SOURCE_FILES)
        part['cpu_gate_validated'] = True
    except (AssertionError, KeyError, TypeError, ValueError):
        pass
    for weights in ('ema', 'raw'):
        key = weights + '_dpm2m_s20'
        prefix = 'part_e/decode_test/' + key
        folder = snapshot / prefix
        for path in [folder / name for name in JSONS] + [folder.with_suffix('.log'), folder.with_suffix('.receipt.json')]:
            if path.exists():
                add(path)
        row = {'case': key, 'sampler': 'dpm2m', 'code_commit': PART_E_COMMIT, 'evaluation_validated': False, 'expected_trees': 100}
        part['cases'].append(row)
        try:
            summary, scored, manifest, progress = [read(prefix + '/' + name) for name in JSONS]
            assert summary['trees'] == scored['trees'] == progress['generated'] == progress['expected'] == 100
            for item in (summary, scored):
                assert item['update'] == identity['update'] and item['weights'] == weights and item['steps_per_depth'] == 20 and item['sampler'] == 'dpm2m'
                assert item['checkpoint_sha256'] == identity['sha256'] and item['checkpoint'] == str(snapshot / 'checkpoint.pt')
            for item in (scored, manifest):
                keys = [(value['seed'], value['uid']) for value in item['rows']]
                assert len(keys) == len(set(keys)) == 100 and set(keys) == pairs
            for field, item_field in (('full_trees_exact', 'all_levels_exact'), ('native_final_sets_exact', 'native_final_set_exact')):
                assert summary[field] == scored[field] == sum(item[item_field] for item in scored['rows'])
            assert summary['per_depth'] == scored['per_depth'] and len(summary['per_depth']) == 9
            hashes = {name: sha(files[prefix + '/' + name]) for name in JSONS}
            receipt = read(prefix + '.receipt.json')
            expected = {'checkpoint_sha256': identity['sha256'], 'update': identity['update'], 'weights': weights, 'steps_per_depth': 20, 'sampler': 'dpm2m', 'code_commit': PART_E_COMMIT}
            assert receipt['return_code'] == 0 and receipt['input_json_sha256'] == hashes
            assert all(receipt['identity'][name] == value for name, value in expected.items())
            assert receipt['log_sha256'] == sha(files[prefix + '.log']) and b'EVALUATION_COMPLETE' in files[prefix + '.log']
            row.update(evaluation_validated=True, trees=100, summary=summary)
        except (AssertionError, KeyError, TypeError, ValueError):
            row['validation_error'] = 'Incomplete or inconsistent Part E evaluation evidence'
    for key in BOUNDARIES:
        prefix = 'part_e/boundary/' + key + '/boundary'
        for suffix in ('.json', '.log', '.receipt.json'):
            if (snapshot / (prefix + suffix)).exists():
                add(snapshot / (prefix + suffix))
        row = {'case': key, 'validated': False, 'expected_trees': 100}
        part['boundaries'].append(row)
        try:
            values, receipt = read(prefix + '.json'), read(prefix + '.receipt.json')
            assert len(values) == 1 and values[0]['trees'] == 100
            value, provenance = values[0], receipt['identity']
            assert receipt['return_code'] == 0 and provenance['code_commit'] == PART_E_COMMIT
            assert value['eval_dir'] == provenance['eval_dir'] and provenance['input_json_sha256'] and provenance['labels_sha256']
            if key.startswith('euler_'):
                source = snapshot / 'decode_test' / key.removeprefix('euler_')
            elif key.startswith('dpm2m_'):
                source = snapshot / 'part_e/decode_test' / (key.split('_')[1] + '_dpm2m_s20')
            else:
                sources = {f'partc_{job.split("_")[0]}_u{update:06d}_raw': snapshot.parents[1].parent / 'nexus_vertex_dense_round2_20261009/runs' / job / 'evals' / f'u{update:06d}_raw' for job, update in PART_C}
                source = sources[key]
            assert provenance['eval_dir'] == str(source)
            assert provenance['script_sha256'] == sha(files['part_e/source/analyze_boundary.py'])
            assert provenance['input_json_sha256'] == {name: sha((source / name).read_bytes()) for name in JSONS}
            assert receipt['result_sha256'] == sha(files[prefix + '.json']) and receipt['log_sha256'] == sha(files[prefix + '.log'])
            curve = [value['exact_within_cells'][str(k)] for k in (0, 1, 2, 4, 8)]
            assert all(type(v) is int and 0 <= v <= 100 for v in curve) and curve == sorted(curve)
            assert type(value['incomplete_trees']) is int and 0 <= value['incomplete_trees'] <= 100
            for metric in ('vertex_hausdorff_median', 'vertex_hausdorff_max', 'vertex_chamfer_mean', 'vertex_chamfer_max'):
                v = value[metric]
                row[metric] = str(v) if isinstance(v, float) and not math.isfinite(v) else v
            denominators = receipt['distance_denominators']
            assert denominators['all_trees'] == 100 and denominators['missing_depth9_excluded'] == value['incomplete_trees']
            assert denominators['distance_trees'] == 100 - value['incomplete_trees']
            assert 0 <= denominators['empty_prediction_infinite_distance'] <= denominators['distance_trees']
            assert denominators['finite_chamfer_mean_trees'] == denominators['distance_trees'] - denominators['empty_prediction_infinite_distance']
            row['finite_chamfer_denominator'] = denominators['finite_chamfer_mean_trees']
            row['distance_denominators'] = denominators
            row.update(validated=True, trees=100, incomplete_trees=value['incomplete_trees'], distance_considered_trees=100-value['incomplete_trees'], exact_within_cells=value['exact_within_cells'])
        except (AssertionError, KeyError, TypeError, ValueError, OSError):
            row['validation_error'] = 'Incomplete or inconsistent new boundary evidence'
    part['all_validated'] = part['source_identity_validated'] and part['cpu_gate_validated'] and all(r['evaluation_validated'] for r in part['cases']) and all(r['validated'] for r in part['boundaries'])
    if state['state'] == 'complete' and not part['all_validated']:
        part['state'] = 'validation_failed'
    files['PART_E_REPORT.json'] = encoded(part)


def collect(snapshot):
    files = {}
    def add(path, name=None):
        assert path.is_file() and not path.is_symlink(), 'Missing file or symlink: ' + str(path)
        assert path.stat().st_size <= 16 << 20, 'Oversized evidence: ' + str(path)
        files[name or str(path.relative_to(snapshot))] = path.read_bytes()
    def read(name):
        return json.loads(files[name])
    for name in ('CHECKPOINT_IDENTITY.json', 'decode_status.json'):
        add(snapshot / name)
    identity, state = read('CHECKPOINT_IDENTITY.json'), read('decode_status.json')
    assert state['state'] in ('complete', 'failed', 'interrupted'), 'Evaluation must have stopped before publishing'
    assert identity['source_path'].endswith('/J3_token_lr5e-6/latest.pt')
    assert re.fullmatch('[0-9a-f]{64}', identity['sha256']) and type(identity['update']) is int
    uids = identity['source_config']['uids']
    assert len(uids) == len(set(uids)) == 50
    pairs = {(seed, uid) for seed in SEEDS for uid in uids}
    rows = []
    for steps in (1, 20, 50):
        for weights in ('ema', 'raw'):
            key = f'{weights}_s{steps}'
            folder = snapshot / 'decode_test' / key
            for path in [folder.with_suffix('.log'), folder.with_suffix('.receipt.json')] + [folder / name for name in JSONS] + [folder / (kind + suffix) for kind in ('boundary', 'cascade') for suffix in ('.json', '.log', '.receipt.json')]:
                if path.exists():
                    add(path)
            row = {'case': key, 'evaluation_validated': False, 'analyses_validated': False, 'expected_trees': 100}
            rows.append(row)
            try:
                records = [read(f'decode_test/{key}/{name}') for name in JSONS]
                summary, scored, manifest, progress = records
                assert summary['trees'] == scored['trees'] == progress['generated'] == progress['expected'] == 100
                for record in (summary, scored):
                    assert record['update'] == identity['update'] and record['weights'] == weights and record['steps_per_depth'] == steps
                    assert record['checkpoint_sha256'] == identity['sha256'] and record['checkpoint'] == str(snapshot / 'checkpoint.pt')
                for record in (scored, manifest):
                    keys = [(item['seed'], item['uid']) for item in record['rows']]
                    assert len(keys) == len(set(keys)) == 100 and set(keys) == pairs
                for field, item_field in (('full_trees_exact', 'all_levels_exact'), ('native_final_sets_exact', 'native_final_set_exact')):
                    assert summary[field] == scored[field] == sum(item[item_field] for item in scored['rows'])
                assert summary['per_depth'] == scored['per_depth'] and len(summary['per_depth']) == 9
                hashes = {name: sha(files[f'decode_test/{key}/{name}']) for name in JSONS}
                receipt = read(f'decode_test/{key}.receipt.json')
                assert receipt['return_code'] == 0 and receipt['input_json_sha256'] == hashes
                expected = {'checkpoint_sha256': identity['sha256'], 'update': identity['update'], 'weights': weights, 'steps_per_depth': steps, 'code_commit': identity['code_commit']}
                assert all(receipt['identity'][name] == value for name, value in expected.items())
                assert receipt['log_sha256'] == sha(files[f'decode_test/{key}.log']) and b'EVALUATION_COMPLETE' in files[f'decode_test/{key}.log']
                row.update(evaluation_validated=True, trees=100, summary=summary)
                for kind in ('boundary', 'cascade'):
                    prefix = f'decode_test/{key}/{kind}'
                    reports, receipt2 = read(prefix + '.json'), read(prefix + '.receipt.json')
                    assert len(reports) == 1 and reports[0]['trees'] == 100 and reports[0]['eval_dir'] == str(folder)
                    assert receipt2['return_code'] == 0 and receipt2['identity']['input_json_sha256'] == hashes
                    assert receipt2['identity']['evaluation'] == receipt['identity']
                    assert receipt2['result_sha256'] == sha(files[prefix + '.json']) and receipt2['log_sha256'] == sha(files[prefix + '.log'])
                    row[kind] = reports[0]
                row['analyses_validated'] = True
            except (AssertionError, KeyError, TypeError, ValueError) as error:
                row['validation_error'] = type(error).__name__ + ': incomplete or inconsistent evidence'
    complete = all(row['evaluation_validated'] and row['analyses_validated'] for row in rows)
    assert state['state'] != 'complete' or complete, 'Complete status has incomplete or inconsistent evidence'
    for name in ('run_j3_snapshot_decode.py', 'run_decode_test.py', 'publish_j3_snapshot_decode.py'):
        add(Path(__file__).with_name(name), 'launcher/' + name)
    files['LAUNCH_COMMANDS.json'] = encoded({'cases': state['cases'], 'gpu_uuid': state.get('gpu_uuid')})
    report = {'state': state['state'], 'all_six_validated': complete, 'update': identity['update'], 'checkpoint_sha256': identity['sha256'], 'cases': rows}
    if (snapshot / 'PART_E_APPROVED.json').exists():
        collect_part_e(snapshot, files, report, add, read)
    files['REPORT.json'] = encoded(report)
    return files, report


def publish(snapshot, token):
    files, report = collect(snapshot)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    name = 'j3-snapshot-decode-' + stamp
    title = 'J3 current snapshot decoding — ' + stamp
    table = ['| Case | Verified trees | Exact trees | Exact final sets | Analyses |', '|---|---:|---:|---:|---|']
    for row in report['cases']:
        summary = row.get('summary', {})
        table.append(f"| {row['case']} | {row.get('trees', 'unverified')}/100 | {summary.get('full_trees_exact', 'unverified')} | {summary.get('native_final_sets_exact', 'unverified')} | {'complete' if row['analyses_validated'] else 'partial/unverified'} |")
    text = f"# {title}\n\nStatus: **{report['state']}**; all six evaluation + analysis sets validated: **{report['all_six_validated']}**.\n\nFrozen update: {report['update']}; checkpoint SHA256: `{report['checkpoint_sha256']}`.\n\n" + '\n'.join(table) + '\n\nEach complete case uses the same 50 UIDs × 2 seeds. Unverified or partial cases are not counted as 100-tree results. Boundary and cascade results, per-case logs and provenance are included. No checkpoints, predictions or datasets are included. This is one snapshot; later training updates are outside this report.\n'
    if 'part_e' in report:
        part = report['part_e']
        euler_commit = json.loads(files['CHECKPOINT_IDENTITY.json'])['code_commit']
        text += f"\n## Part E\n\nStatus: **{part['state']}**; CPU gate verified: **{part['cpu_gate_validated']}**; all 2 DPM2M evaluations and 14 new boundary reports verified: **{part['all_validated']}**. Euler source remains `{euler_commit}`; DPM2M and new boundary source is `{PART_E_COMMIT}`.\n\n| DPM2M case | Verified trees | Exact trees | Exact final sets |\n|---|---:|---:|---:|\n"
        for row in part['cases']:
            summary = row.get('summary', {})
            text += f"| {row['case']} | {row.get('trees', 'unverified')}/100 | {summary.get('full_trees_exact', 'unverified')} | {summary.get('native_final_sets_exact', 'unverified')} |\n"
        text += '\n| New boundary case | Verified trees | Distance considered | Finite Chamfer denominator |\n|---|---:|---:|---|\n'
        for row in part['boundaries']:
            text += f"| {row['case']} | {row.get('trees', 'unverified')}/100 | {row.get('distance_considered_trees', 'unverified')} | {row.get('finite_chamfer_denominator', 'unverified')} |\n"
        text += '\nDistances compare D9 cell centres in [-1,1]; they are not paper surface metrics. Missing-D9 trees are excluded from distance statistics, and Chamfer means use the finite subset. Infinity is retained in raw analyzer evidence and represented explicitly in PART_E_REPORT.json. The six historical Part C inputs are separate checkpoint cohorts.\n'
        resource = part['resource_change']
        text += f"\nThe additional GPU was explicitly authorized: Euler used `{resource['euler_gpu_uuid']}`; DPM2M used `{resource['gpu_uuid']}`. This resource difference is recorded alongside the sampler and code-commit differences.\n"
    files['README.md'] = text.encode()
    forbidden = re.compile(rb'gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|Authorization:\s*(?:Bearer|Basic)\s+[A-Za-z0-9+/=]{16,}')
    for path, content in files.items():
        assert token.encode() not in content and not forbidden.search(content), 'Credential detected in evidence'
    assert sum(map(len, files.values())) <= 64 << 20, 'Evidence exceeds lightweight package limit'
    files['SHA256SUMS'] = ''.join(f'{sha(content)}  {path}\n' for path, content in sorted(files.items())).encode()
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode='w:gz') as archive:
        for path, content in sorted(files.items()):
            entry = tarfile.TarInfo(name + '/' + path)
            entry.size, entry.mode = len(content), 0o644
            archive.addfile(entry, io.BytesIO(content))
    bundle = buffer.getvalue()
    package = {'name': name + '.tgz', 'sha256': sha(bundle), 'bytes': len(bundle), 'files': len(files)}
    destination = snapshot / 'publication' / name
    destination.mkdir(parents=True, exist_ok=False)
    artifact = {name + '.tgz': bundle, 'PACKAGE.json': encoded(package), 'README.md': text.encode()}
    for path, content in artifact.items():
        (destination / path).write_bytes(content)
    evidence = PREFIX + 'evidence/' + name + '/'
    message = PREFIX + 'messages/' + name + '.md'
    payload = {evidence + path: content for path, content in artifact.items()}
    payload[message] = (text + f'\n[Download evidence](../evidence/{name}/{name}.tgz) · [SHA256 manifest](../evidence/{name}/PACKAGE.json)\n').encode()
    def blob(path, content):
        result = api('/git/blobs', token, {'encoding': 'base64', 'content': base64.b64encode(content).decode()})
        assert result['sha'] == hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\0' + content).hexdigest()
        return {'path': path, 'mode': '100644', 'type': 'blob', 'sha': result['sha']}
    entries = [blob(path, content) for path, content in payload.items()]
    for attempt in range(4):
        head = api('/git/ref/heads/' + BRANCH, token)['object']['sha']
        parent = api('/git/commits/' + head, token)
        readme = base64.b64decode(api('/contents/' + PREFIX + 'README.md?ref=' + head, token)['content'])
        readme += f'\n- [{title}](messages/{name}.md)\n'.encode()
        tree = api('/git/trees', token, {'base_tree': parent['tree']['sha'], 'tree': entries + [blob(PREFIX + 'README.md', readme)]})
        commit = api('/git/commits', token, {'message': title, 'tree': tree['sha'], 'parents': [head]})['sha']
        try:
            api('/git/refs/heads/' + BRANCH, token, {'sha': commit, 'force': False}, 'PATCH')
            break
        except urllib.error.HTTPError as error:
            if error.code not in (409, 422) or attempt == 3:
                raise
    payload[PREFIX + 'README.md'] = readme
    for path, content in payload.items():
        with urllib.request.urlopen(f'https://raw.githubusercontent.com/leoguohr/suxen/{commit}/{path}', timeout=120) as response:
            assert sha(response.read()) == sha(content), 'Public readback mismatch'
    receipt = {'commit': commit, 'parent': head, 'branch': BRANCH, 'package': package, 'public_readback_verified': True,
               'message_url': f'https://github.com/leoguohr/suxen/blob/{commit}/{message}'}
    (destination / 'GITHUB_PUBLISH.json').write_bytes(encoded(receipt))
    if 'part_e' in report:
        (snapshot / 'PART_E_PUBLISHED.json').write_bytes(encoded(receipt))
    print('PUBLISH_VERIFIED', json.dumps(receipt), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--snapshot-dir', required=True, type=Path)
    args = parser.parse_args()
    token = json.load(sys.stdin)['token']
    assert isinstance(token, str) and len(token) >= 20 and not any(char.isspace() for char in token)
    snapshot = args.snapshot_dir.resolve(strict=True)
    with (snapshot / '.publish.lock').open('a') as publication_lock:
        fcntl.flock(publication_lock, fcntl.LOCK_EX)
        if (snapshot / 'PART_E_PUBLISHED.json').exists():
            print('PART_E_ALREADY_PUBLISHED', flush=True)
            raise SystemExit(0)
        if not maybe_run_part_e(snapshot):
            print('PUBLICATION_DEFERRED_TO_OTHER_WORKER_COMPLETION', flush=True)
            raise SystemExit(0)
        with (snapshot / '.decode.lock').open('a') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            publish(snapshot, token)
