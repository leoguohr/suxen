"""Part E GPU add-on, then CPU boundaries after all eight evaluations; no polling or training controls."""
import argparse
import fcntl
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time

from run_decode_test import ROOT, COMMIT as EULER_COMMIT, OLD, PY, SEEDS, fingerprint, read, sha, validate

COMMIT = 'e7c85bf2b82fdc6ee15eb59be20486ffc7853fa4'
CODE = ROOT / 'repo_2449388/vertex/dense_overfit50_20261009'
JSONS = ('summary.json', 'evaluation.json', 'generation_manifest.json', 'progress.json')
PART_C = (('J1_item', 5400), ('J2_token', 5400), ('J3_token_lr5e-6', 5400),
          ('J5_token_fine2', 3600), ('J6_token_selfcorrect', 5400), ('J3_token_lr5e-6', 3600))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--snapshot-dir', type=Path, required=True)
    parser.add_argument('--phase', choices=('gpu', 'boundary'), required=True)
    parser.add_argument('--gpu')
    args = parser.parse_args()
    if args.phase == 'gpu':
        assert args.gpu and re.fullmatch(r'GPU-[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}', args.gpu)
    snapshot = args.snapshot_dir.resolve(strict=True)
    lock = (snapshot / '.part_e.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    out = snapshot / 'part_e'
    out.mkdir(exist_ok=True)
    state_path = out / 'status.json'
    prior_state = read(state_path) if state_path.exists() else {}
    state = {'state': 'checking', 'code_commit': COMMIT, 'euler_code_commit': EULER_COMMIT,
             'phase': args.phase, 'gpu_uuid': args.gpu, 'started_unix': time.time(), 'cases': [], 'boundaries': [], 'gpu_checks': []}
    if args.phase == 'boundary':
        assert prior_state.get('state') in ('gpu_complete', 'complete'), 'Both DPM evaluations must finish first'
        state = prior_state | {'state': 'checking_boundary', 'phase': 'boundary', 'boundary_started_unix': time.time(), 'boundaries': []}
    env = os.environ | {'PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION': 'python', 'OMP_NUM_THREADS': '8',
                        'CUDA_VISIBLE_DEVICES': args.gpu or '', 'GIT_NO_LAZY_FETCH': '1'}
    env.pop('NEXUS_SKIP_COARSE_PROBES', None)
    cpu_env = env | {'CUDA_VISIBLE_DEVICES': ''}
    process = None

    def save():
        temporary = state_path.with_suffix('.json.tmp')
        temporary.write_text(json.dumps(state, indent=2, allow_nan=False) + '\n')
        temporary.replace(state_path)

    def git(*arguments):
        return subprocess.check_output(['git', '-C', str(CODE), *arguments], env=cpu_env)

    def run(command, log, child_env, cwd=CODE):
        nonlocal process
        with log.open('x') as stream:
            process = subprocess.Popen(command, cwd=cwd, env=child_env, stdout=stream,
                                       stderr=subprocess.STDOUT, start_new_session=True)
            try:
                code = process.wait()
            finally:
                process = None
        assert code == 0, f'Child failed ({code}); preserve {log}'

    def stop(signum, frame):
        if process is not None and process.poll() is None:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
        state.update(state='interrupted', ended_unix=time.time())
        save()
        raise SystemExit(143)

    def idle_gpu():
        prefix = ['nvidia-smi', '-i', args.gpu]
        pids = subprocess.check_output(prefix + ['--query-compute-apps=pid', '--format=csv,noheader,nounits'], text=True).strip()
        line = subprocess.check_output(prefix + ['--query-gpu=uuid,memory.used,memory.total', '--format=csv,noheader,nounits'], text=True).strip()
        uuid, used, total = [value.strip() for value in line.split(',')]
        assert uuid == args.gpu and not pids and float(used) <= 256 and float(total) >= 75 * 1024, 'Same allocated GPU must be idle'
        state['gpu_checks'].append({'unix': time.time(), 'uuid': uuid, 'memory_used_mib': float(used), 'compute_pids': []})
        save()

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    save()
    try:
        identity_path = snapshot / 'CHECKPOINT_IDENTITY.json'
        identity = read(identity_path)
        if args.phase == 'boundary':
            euler_state = read(snapshot / 'decode_status.json')
            assert euler_state['state'] == 'complete', 'All six Euler evaluations must finish first'
            assert euler_state['update'] == 7075 and euler_state['checkpoint_sha256'] == identity['sha256']
        assert identity['update'] == 7075 and identity['code_commit'] == EULER_COMMIT
        assert identity['has_model'] is True and identity['has_ema'] is True
        checkpoint, digest = snapshot / 'checkpoint.pt', identity['sha256']
        assert not checkpoint.is_symlink() and identity['checkpoint'] == str(checkpoint)
        original, identity_hash = fingerprint(checkpoint), sha(identity_path)
        if args.phase == 'gpu':
            assert sha(checkpoint) == digest and fingerprint(checkpoint) == original
        else:
            assert state['checkpoint_sha256'] == digest
        state.update(checkpoint=str(checkpoint), checkpoint_sha256=digest, update=7075, checkpoint_identity_sha256=identity_hash)
        manifest = read(CODE / 'data/prepared_d9/manifest.json')
        uids = manifest['train_uids']
        assert len(uids) == len(set(uids)) == 50 and identity['source_config']['uids'] == uids
        pairs = {(seed, uid) for seed in SEEDS for uid in uids}
        assert git('rev-parse', 'HEAD').decode().strip() == COMMIT, 'Use the separate pinned Part E checkout'
        git('diff', '--quiet', 'HEAD', '--', '.')
        gate_log, gate_receipt = out / 'cpu_gate_e7c85bf.log', out / 'cpu_gate_e7c85bf.receipt.json'
        gate = read(gate_receipt)
        assert gate['code_commit'] == COMMIT and gate['return_code'] == 0
        assert gate['log_sha256'] == sha(gate_log) and 'ALL CPU TESTS PASSED' in gate_log.read_text()
        required = {'tests/test_cpu.py', 'common.py', 'samplers.py', 'evaluate.py', 'analyze_boundary.py'}
        assert required <= set(gate['source_files_sha256']), 'CPU gate source hashes missing'
        assert all(sha(CODE / name) == value for name, value in gate['source_files_sha256'].items())
        state['cpu_gate'] = gate
        boundary_cases = []
        if args.phase == 'boundary':
            for steps in (1, 20, 50):
                for weights in ('ema', 'raw'):
                    folder = snapshot / 'decode_test' / f'{weights}_s{steps}'
                    validate(folder, 7075, weights, pairs, checkpoint, digest, steps)
                    receipt = read(folder.with_suffix('.receipt.json'))
                    assert receipt['identity']['code_commit'] == EULER_COMMIT and receipt['return_code'] == 0
                    assert receipt['input_json_sha256'] == {name: sha(folder / name) for name in JSONS}
                    assert receipt['log_sha256'] == sha(folder.with_suffix('.log'))
                    boundary_cases.append((f'euler_{weights}_s{steps}', folder, 7075, weights, steps))
        labels = {CODE / 'data/prepared_d9/manifest.json'}
        for record in manifest['records']:
            labels.update((CODE / 'data/prepared_d9' / record['label_file'], CODE / 'data' / record['source_label_file']))
        label_hashes = {str(path): sha(path) for path in sorted(labels)}
        (out / 'decode_test').mkdir(exist_ok=True)
        for weights in ('ema', 'raw'):
            folder = out / 'decode_test' / f'{weights}_dpm2m_s20'
            log, receipt = folder.with_suffix('.log'), folder.with_suffix('.receipt.json')
            command = [PY, '-u', 'evaluate.py', '--checkpoint', str(checkpoint), '--weights', weights,
                       '--sampler', 'dpm2m', '--steps', '20', '--hash-checkpoint', '--output', str(folder)]
            case_identity = {'checkpoint_sha256': digest, 'update': 7075, 'weights': weights, 'steps_per_depth': 20,
                             'sampler': 'dpm2m', 'code_commit': COMMIT, 'labels_sha256': label_hashes}
            row = {'weights': weights, 'steps': 20, 'sampler': 'dpm2m', 'output': str(folder), 'command': command}
            if args.phase == 'gpu':
                state['cases'].append(row)
            existed = any(path.exists() for path in (folder, log, receipt))
            if existed:
                assert folder.is_dir() and log.is_file() and receipt.is_file(), f'Partial DPM evaluation; preserve {folder}'
                previous = read(receipt)
                assert previous['identity'] == case_identity and previous['command'] == command and previous['return_code'] == 0
                assert previous['log_sha256'] == sha(log)
                row.update(state='validated_existing', started_unix=previous['started_unix'], ended_unix=previous['ended_unix'])
            else:
                assert args.phase == 'gpu', f'Missing completed DPM evaluation: {folder}'
                idle_gpu()
                assert fingerprint(checkpoint) == original
                state['state'] = 'evaluating'
                row.update(state='running', started_unix=time.time())
                save()
                run(command, log, env)
                row.update(state='complete', ended_unix=time.time())
            assert fingerprint(checkpoint) == original and 'EVALUATION_COMPLETE' in log.read_text()
            summary = validate(folder, 7075, weights, pairs, checkpoint, digest, 20)
            assert summary['sampler'] == read(folder / 'evaluation.json')['sampler'] == 'dpm2m'
            row['summary'] = summary
            inputs = {name: sha(folder / name) for name in JSONS}
            if existed:
                assert previous['input_json_sha256'] == inputs
            else:
                receipt.write_text(json.dumps({'identity': case_identity, 'command': command, 'return_code': 0,
                                              'started_unix': row['started_unix'], 'ended_unix': row['ended_unix'],
                                              'input_json_sha256': inputs, 'log_sha256': sha(log)}, indent=2) + '\n')
            boundary_cases.append((f'dpm2m_{weights}_s20', folder, 7075, weights, 20))
            save()
        if args.phase == 'gpu':
            assert fingerprint(checkpoint) == original and sha(identity_path) == identity_hash
            state.update(state='gpu_complete', gpu_ended_unix=time.time())
            save()
            print('J3_PART_E_GPU_COMPLETE', 7075, digest, flush=True)
            return
        for job, update in PART_C:
            boundary_cases.append((f'partc_{job.split("_")[0]}_u{update:06d}_raw', OLD / 'runs' / job / 'evals' / f'u{update:06d}_raw', update, 'raw', 20))
        (out / 'boundary').mkdir(exist_ok=True)
        for name, source, update, weights, steps in boundary_cases:
            summary = validate(source, update, weights, pairs)
            if name.startswith('partc_'):
                config = read(source.parents[1] / 'config.json')
                assert config['eval_steps'] == 20 and config['uids'] == uids
            inputs = {name: sha(source / name) for name in JSONS}
            script = CODE / 'analyze_boundary.py'
            analysis_identity = {'code_commit': COMMIT, 'script_sha256': sha(script), 'labels_sha256': label_hashes,
                                 'eval_dir': str(source), 'input_json_sha256': inputs}
            folder = out / 'boundary' / name
            result, log, receipt = [folder / ('boundary' + suffix) for suffix in ('.json', '.log', '.receipt.json')]
            command = [PY, str(script), '--eval-dir', str(source), '--output', str(result)]
            row = {'case': name, 'eval_dir': str(source), 'output': str(result), 'command': command}
            state['boundaries'].append(row)
            existed = folder.exists()
            if existed:
                assert all(path.is_file() for path in (result, log, receipt)), f'Partial boundary analysis; preserve {folder}'
                previous = read(receipt)
                assert previous['identity'] == analysis_identity and previous['command'] == command and previous['return_code'] == 0
                assert previous['result_sha256'] == sha(result) and previous['log_sha256'] == sha(log)
                row.update(state='validated_existing', started_unix=previous['started_unix'], ended_unix=previous['ended_unix'])
            else:
                folder.mkdir()
                state['state'] = 'boundary'
                row.update(state='running', started_unix=time.time())
                save()
                run(command, log, cpu_env)
                row.update(state='complete', ended_unix=time.time())
            reports = read(result)
            assert len(reports) == 1 and reports[0]['eval_dir'] == str(source) and reports[0]['trees'] == 100
            assert reports[0]['exact_within_cells']['0'] == summary['native_final_sets_exact']
            assert all(key in reports[0] for key in ('vertex_hausdorff_median', 'vertex_hausdorff_max', 'vertex_hausdorff_trees_le_cells', 'vertex_chamfer_mean', 'vertex_chamfer_max'))
            import numpy as np
            missing = empty = 0
            for prediction in (source / 'predictions').glob('*.npz'):
                with np.load(prediction, allow_pickle=False) as values:
                    if 'depth9_parents' not in values:
                        missing += 1
                    elif not values['depth9_occupancy'].astype(bool).any():
                        empty += 1
            assert missing == reports[0]['incomplete_trees']
            denominator = {'all_trees': 100, 'missing_depth9_excluded': missing, 'distance_trees': 100 - missing,
                           'empty_prediction_infinite_distance': empty, 'finite_chamfer_mean_trees': 100 - missing - empty}
            row['distance_denominators'] = denominator
            assert inputs == {name: sha(source / name) for name in inputs}
            if not existed:
                receipt.write_text(json.dumps({'identity': analysis_identity, 'command': command, 'return_code': 0,
                                              'started_unix': row['started_unix'], 'ended_unix': row['ended_unix'],
                                              'result_sha256': sha(result), 'log_sha256': sha(log),
                                              'distance_denominators': denominator}, indent=2) + '\n')
            save()
        assert fingerprint(checkpoint) == original and sha(identity_path) == identity_hash
        state.update(state='complete', ended_unix=time.time())
        save()
        print('J3_PART_E_COMPLETE', 7075, digest, flush=True)
    except Exception as error:
        state.update(state='failed', error=repr(error), ended_unix=time.time())
        save()
        raise


if __name__ == '__main__':
    main()
