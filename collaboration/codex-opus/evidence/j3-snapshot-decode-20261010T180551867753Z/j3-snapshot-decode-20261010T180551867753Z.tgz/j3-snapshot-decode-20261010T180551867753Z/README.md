# J3 current snapshot decoding — 20261010T180551867753Z

Status: **complete**; all six evaluation + analysis sets validated: **True**.

Frozen update: 7075; checkpoint SHA256: `e3660429282d326f69f2d1fd780c4c6bb8d403f72aed56cb07dbba5a4295b168`.

| Case | Verified trees | Exact trees | Exact final sets | Analyses |
|---|---:|---:|---:|---|
| ema_s1 | 100/100 | 62 | 63 | complete |
| raw_s1 | 100/100 | 45 | 46 | complete |
| ema_s20 | 100/100 | 70 | 70 | complete |
| raw_s20 | 100/100 | 59 | 59 | complete |
| ema_s50 | 100/100 | 60 | 60 | complete |
| raw_s50 | 100/100 | 54 | 54 | complete |

Each complete case uses the same 50 UIDs × 2 seeds. Unverified or partial cases are not counted as 100-tree results. Boundary and cascade results, per-case logs and provenance are included. No checkpoints, predictions or datasets are included. This is one snapshot; later training updates are outside this report.

## Part E

Status: **complete**; CPU gate verified: **True**; all 2 DPM2M evaluations and 14 new boundary reports verified: **True**. Euler source remains `427498e88912f351ff50b70aef5888999b2af26b`; DPM2M and new boundary source is `e7c85bf2b82fdc6ee15eb59be20486ffc7853fa4`.

| DPM2M case | Verified trees | Exact trees | Exact final sets |
|---|---:|---:|---:|
| ema_dpm2m_s20 | 100/100 | 63 | 63 |
| raw_dpm2m_s20 | 100/100 | 56 | 56 |

| New boundary case | Verified trees | Distance considered | Finite Chamfer denominator |
|---|---:|---:|---|
| euler_ema_s1 | 100/100 | 100 | 100 |
| euler_raw_s1 | 100/100 | 100 | 100 |
| euler_ema_s20 | 100/100 | 100 | 100 |
| euler_raw_s20 | 100/100 | 100 | 100 |
| euler_ema_s50 | 100/100 | 100 | 100 |
| euler_raw_s50 | 100/100 | 100 | 100 |
| dpm2m_ema_s20 | 100/100 | 100 | 100 |
| dpm2m_raw_s20 | 100/100 | 100 | 100 |
| partc_J1_u005400_raw | 100/100 | 100 | 100 |
| partc_J2_u005400_raw | 100/100 | 100 | 100 |
| partc_J3_u005400_raw | 100/100 | 100 | 100 |
| partc_J5_u003600_raw | 100/100 | 100 | 100 |
| partc_J6_u005400_raw | 100/100 | 100 | 100 |
| partc_J3_u003600_raw | 100/100 | 100 | 100 |

Distances compare D9 cell centres in [-1,1]; they are not paper surface metrics. Missing-D9 trees are excluded from distance statistics, and Chamfer means use the finite subset. Infinity is retained in raw analyzer evidence and represented explicitly in PART_E_REPORT.json. The six historical Part C inputs are separate checkpoint cohorts.

The additional GPU was explicitly authorized: Euler used `GPU-1184d5f2-03ec-a69d-1167-78a5f40624fe`; DPM2M used `GPU-208b1847-4ab0-f090-b8d4-f21ebd908b00`. This resource difference is recorded alongside the sampler and code-commit differences.
