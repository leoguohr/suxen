# Historical saved predictions for nexus_2k_001093

- Target: depth6 (18,31,35), parent (9,15,17), child bit3; GT=1; threshold=0.5.
- Actual shared start: Round1 A/final.pt (update749, SHA 1bd4ced48296b45c80d54386171652a6f9eb9c09e8fc976965caad62899b55f9).
- S0@34000 is its ancestor. S1 is an independent sweep comparison.
- CPU array recomputation agrees with every available evaluation row; no model replay.

## When the target miss was observed

- J5 raw: target present in both seeds at updates1800,3600,5400,7200; missing in both at9000.
- Each official seed therefore brackets the observed regression between7200 and9000. Intermediate predictions are not available; the exact transition update is unknown.
- Round1 A, the direct common initialization, retains the target for both official seeds. Earlier S0@34000 misses it for97029000 but retains it for97029001. Thus this is not a continuously missing bit inherited unchanged from S0.
- J2 retains this bit in every inspected milestone and terminal prediction. A correct target bit does not imply a correct complete tree.
- Round1 A/B/C raw and D raw/EMA all retain the bit; all ten of these whole trees still fail elsewhere.

| Source | Update / cumulative | Weights | Seed | Estimate | Target | Whole tree | First mismatch |
|---|---:|---|---:|---:|---|---|---:|
| sweep/S0 | 10000 / 34000 | raw | 97029000 | 0.0225583762 | miss | fail | 3 |
| sweep/S0 | 10000 / 34000 | raw | 97029001 | 1.00412154 | occupied | fail | 3 |
| sweep/S1 | 10000 / 34000 | raw | 97029000 | parent absent | parent absent | fail | 1 |
| sweep/S1 | 10000 / 34000 | raw | 97029001 | 1.04613888 | occupied | fail | 4 |
| round1/A | 749 / None | raw | 97029000 | 1.00468564 | occupied | fail | 6 |
| round1/A | 749 / None | raw | 97029001 | 1.00310254 | occupied | fail | 6 |
| round1/B | 749 / None | raw | 97029000 | 1.01584566 | occupied | fail | 5 |
| round1/B | 749 / None | raw | 97029001 | 1.01989925 | occupied | fail | 6 |
| round1/C | 749 / None | raw | 97029000 | 0.971404076 | occupied | fail | 2 |
| round1/C | 749 / None | raw | 97029001 | 0.992580891 | occupied | fail | 4 |
| round1/D | 608 / None | ema | 97029000 | 1.01582551 | occupied | fail | 6 |
| round1/D | 608 / None | ema | 97029001 | 1.01228201 | occupied | fail | 6 |
| round1/D | 608 / None | raw | 97029000 | 1.02701902 | occupied | fail | 6 |
| round1/D | 608 / None | raw | 97029001 | 1.02556336 | occupied | fail | 6 |
| round2_milestones/J5_token_fine2 | 1800 / None | raw | 97029000 | 1.00064671 | occupied | fail | 6 |
| round2_milestones/J5_token_fine2 | 1800 / None | raw | 97029001 | 0.998414874 | occupied | fail | 6 |
| round2_milestones/J5_token_fine2 | 3600 / None | raw | 97029000 | 1.0004611 | occupied | fail | 6 |
| round2_milestones/J5_token_fine2 | 3600 / None | raw | 97029001 | 1.0038836 | occupied | fail | 6 |
| round2_milestones/J5_token_fine2 | 5400 / None | raw | 97029000 | 1.01181448 | occupied | fail | 7 |
| round2_milestones/J5_token_fine2 | 5400 / None | raw | 97029001 | 1.01306319 | occupied | fail | 7 |
| round2_milestones/J5_token_fine2 | 7200 / None | raw | 97029000 | 1.01388979 | occupied | fail | 6 |
| round2_milestones/J5_token_fine2 | 7200 / None | raw | 97029001 | 1.01423514 | occupied | fail | 6 |
| round2_terminal_supplement/J5_token_fine2 | 9000 / None | raw | 97029000 | 0.000550400466 | miss | fail | 6 |
| round2_terminal_supplement/J5_token_fine2 | 9000 / None | raw | 97029001 | 7.50161707e-05 | miss | fail | 6 |
| round2_terminal_supplement/J5_token_fine2 | 9000 / None | ema | 97029000 | 0.000355202705 | miss | fail | 6 |
| round2_terminal_supplement/J5_token_fine2 | 9000 / None | ema | 97029001 | 0.000172680244 | miss | fail | 6 |
| round2_milestones/J2_token | 1800 / None | raw | 97029000 | 1.00663853 | occupied | fail | 6 |
| round2_milestones/J2_token | 1800 / None | raw | 97029001 | 1.00603211 | occupied | fail | 6 |
| round2_milestones/J2_token | 3600 / None | raw | 97029000 | 1.00231647 | occupied | fail | 6 |
| round2_milestones/J2_token | 3600 / None | raw | 97029001 | 1.00388348 | occupied | fail | 6 |
| round2_milestones/J2_token | 5400 / None | raw | 97029000 | 1.00239301 | occupied | fail | 6 |
| round2_milestones/J2_token | 5400 / None | raw | 97029001 | 1.00290704 | occupied | fail | 7 |
| round2_milestones/J2_token | 7200 / None | raw | 97029000 | 1.00610232 | occupied | fail | 2 |
| round2_milestones/J2_token | 7200 / None | raw | 97029001 | 1.00564146 | occupied | fail | 5 |
| round2_terminal_supplement/J2_token | 9000 / None | raw | 97029000 | 1.00404012 | occupied | pass | None |
| round2_terminal_supplement/J2_token | 9000 / None | raw | 97029001 | 1.00349283 | occupied | fail | 8 |
| round2_terminal_supplement/J2_token | 9000 / None | ema | 97029000 | 1.0036633 | occupied | pass | None |
| round2_terminal_supplement/J2_token | 9000 / None | ema | 97029001 | 1.00193036 | occupied | fail | 8 |

## Limits

- Saved milestones are sparse; earliest observed failure does not identify the exact update when the miss began.
- Identical seeds do not establish identical actual noise when generated parent sets/orders differ.
- Round2 milestone arrays do not store actual noise; these are historical observations, not paired causal tests.
- Terminal raw/EMA rows are supplemental; EMA and raw histories are reported separately.

## Missing historical outputs

- /guohaoran/tmp/nexus_vertex_dense_overfit50_20261009/A/eval_ema: EMA evaluation not present; no claim it was run
- /guohaoran/tmp/nexus_vertex_dense_overfit50_20261009/B/eval_ema: EMA evaluation not present; no claim it was run
- /guohaoran/tmp/nexus_vertex_dense_overfit50_20261009/C/eval_ema: EMA evaluation not present; no claim it was run
