"""Read saved arrays for Round3 Part D item 1; CPU only, no model loading."""
import argparse
import datetime
import hashlib
import io
import json
import os
from pathlib import Path
import re

import numpy as np

UID = 'nexus_2k_001093'
TARGET = (18, 31, 35)
PARENT = (9, 15, 17)
BIT = 3
OFFSETS = np.array([[i >> 2 & 1, i >> 1 & 1, i & 1] for i in range(8)])
BASE = Path('/guohaoran/tmp')
ROUND1 = BASE / 'nexus_vertex_dense_overfit50_20261009'
ROUND2 = BASE / 'nexus_vertex_dense_round2_20261009'
SWEEP = BASE / 'nexus_vertex_arch_sweep_recovery_20261007b'
WORK = BASE / 'nexus_vertex_round3_batch2A_eval_20261015/repo/vertex/dense_overfit50_20261009'


def cellset(a):
    return set(map(tuple, np.asarray(a, dtype=np.int64).reshape(-1, 3).tolist()))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert os.environ.get('CUDA_VISIBLE_DEVICES') == ''
    out = args.output.resolve()
    assert str(out).startswith('/guohaoran/')
    out.mkdir(parents=True, exist_ok=True)
    inputs, missing, records = {}, [], []

    def read(path, kind):
        path = Path(path)
        data = path.read_bytes()
        inputs[str(path)] = dict(path=str(path), kind=kind, bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
        return data

    def jread(path, kind):
        return json.loads(read(path, kind))

    def nread(path, kind):
        with np.load(io.BytesIO(read(path, kind)), allow_pickle=False) as f:
            return {k: f[k].copy() for k in f.files}

    manifest = jread(WORK / 'data/prepared_d9/manifest.json', 'training_manifest')
    m = next(r for r in manifest['records'] if r['uid'] == UID)
    label_path = WORK / 'data/prepared_d9' / m['label_file']
    label = nread(label_path, 'D9_training_label')
    assert inputs[str(label_path)]['sha256'] == m['label_sha256']
    gt = {d: cellset(label['leaves'] >> (9-d)) for d in range(1, 10)}
    assert TARGET in gt[6] and tuple(np.array(PARENT)*2 + OFFSETS[BIT]) == TARGET
    # Verify the identical label used in Round1 and the current prepared dataset.
    old_label = ROUND1 / 'source/vertex/dense_overfit50_20261009/data/prepared_d9' / m['label_file']
    old = nread(old_label, 'Round1_training_label')
    assert np.array_equal(old['leaves'], label['leaves'])

    cp1 = jread(ROUND1 / 'CHECKPOINTS_VERIFIED_20261009.json', 'historical_checkpoint_hash_record')
    cp1meta = jread(ROUND1 / 'CHECKPOINT_METADATA_20261009.json', 'historical_checkpoint_metadata')
    cp1init = jread(ROUND1 / 'checkpoint_local_copy.json', 'historical_S0_copy_verification')
    config2 = {j: jread(ROUND2 / 'runs' / j / 'config.json', 'training_config')
               for j in ['J5_token_fine2', 'J2_token']}
    cp1byname = {r['run']: r for r in cp1['rows']}
    assert config2['J5_token_fine2']['init_sha'] == config2['J2_token']['init_sha'] == cp1byname['A']['sha256']

    def analyze_levels(arrays, row, metadata, source_files):
        per_depth = []
        previous = {(0, 0, 0)}
        for d in range(1, 10):
            a = arrays[d]
            p, occ, est = a['parents'], a['occupancy'], a['estimate']
            assert p.shape == (len(p), 3) and len(cellset(p)) == len(p)
            assert cellset(p) == previous, f'Own-parent expansion mismatch: {source_files}, d{d}'
            est = est.reshape(len(p), 8)
            assert occ.shape == est.shape and np.isfinite(est).all()
            assert np.array_equal(est >= .5, occ)
            generated = cellset((p[:, None] * 2 + OFFSETS)[occ.astype(bool)])
            if 'predicted_cells' in a:
                assert generated == cellset(a['predicted_cells'])
            per_depth.append(dict(depth=d, exact=generated == gt[d], tp=len(generated & gt[d]),
                                  fp=len(generated - gt[d]), fn=len(gt[d] - generated)))
            previous = generated
        exact = all(r['exact'] for r in per_depth)
        first = next((r['depth'] for r in per_depth if not r['exact']), None)
        assert exact == row['all_levels_exact'] and first == row['first_mismatch_depth']
        assert per_depth[-1]['exact'] == row['native_final_set_exact']
        assert len(previous) == row['predicted_n']
        for got, saved in zip(per_depth, row['levels']):
            assert got['exact'] == saved['exact']
            for key in ['tp', 'fp', 'fn']:
                assert got[key] == saved['global_cells_' + key]
        p = arrays[6]['parents']
        idx = np.flatnonzero(np.all(p == np.array(PARENT), axis=1))
        assert len(idx) <= 1
        estimates = arrays[6]['estimate'].reshape(len(p), 8)[idx[0]] if len(idx) else None
        siblings = [{'bit': b, 'cell': (np.array(PARENT)*2 + OFFSETS[b]).tolist(),
                     'gt': int(tuple(np.array(PARENT)*2 + OFFSETS[b]) in gt[6]),
                     'estimate': None if estimates is None else float(estimates[b])}
                    for b in range(8)]
        value = None if estimates is None else float(estimates[BIT])
        result = dict(metadata, target_estimate=value, parent_present=bool(len(idx)),
                      target_status='parent absent' if value is None else ('occupied' if value >= .5 else 'miss'),
                      target_predicted_occupied=None if value is None else value >= .5,
                      whole_tree_pass=exact, final_leaf_set_exact=per_depth[-1]['exact'],
                      first_mismatch_depth=first, predicted_n=len(previous), per_depth=per_depth,
                      siblings=siblings, evaluation_row_matches_recomputed_arrays=True,
                      source_files=[inputs[str(p)] for p in source_files])
        records.append(result)
        print(result['id'], 'estimate=', value if value is not None else 'parent absent',
              'tree_pass=', exact, 'first_mismatch=', first, flush=True)

    def dense_group(folder, group, name, checkpoint_sha=None):
        evalfile = folder / 'evaluation.json'
        if not evalfile.exists():
            missing.append(dict(group=group, path=str(evalfile), reason='evaluation absent'))
            return
        evaluation = jread(evalfile, 'saved_evaluation')
        preds = sorted((folder / 'predictions').glob('seed-*_' + UID + '.npz'))
        if not preds:
            missing.append(dict(group=group, path=str(folder / 'predictions'), reason='target predictions absent'))
        expected_seeds = {r['seed'] for r in evaluation['rows'] if r['uid'] == UID}
        found_seeds = set()
        for path in preds:
            seed = int(re.search(r'seed-(\d+)_', path.name).group(1))
            found_seeds.add(seed)
            a = nread(path, 'saved_prediction_not_uploaded')
            rows = [r for r in evaluation['rows'] if r['uid'] == UID and r['seed'] == seed]
            assert len(rows) == 1
            row = rows[0]
            levels = {d: {k: a[f'depth{d}_{k}'] for k in ['parents', 'occupancy', 'estimate', 'predicted_cells']}
                      for d in range(1, 10)}
            steps = evaluation.get('steps_per_depth', 20)
            md = dict(id=f'{group}/{name}/{folder.name}/seed-{seed}', group=group, branch=name,
                      evaluation_folder=str(folder), evaluation_file=str(evalfile), seed=seed,
                      weights=evaluation['weights'], update=evaluation.get('update'),
                      cumulative_step=evaluation.get('step'), sampler=evaluation.get('sampler', 'euler'),
                      steps_per_depth=steps, threshold=.5,
                      checkpoint_sha256=evaluation.get('checkpoint_sha256') or checkpoint_sha,
                      checkpoint_sha_source='saved evaluation' if evaluation.get('checkpoint_sha256') else
                        ('historical verification record, not rehashed this run' if checkpoint_sha else 'not recorded in evaluation'),
                      actual_noise_available=any('noise' in k for k in a),
                      evaluation_sha256=inputs[str(evalfile)]['sha256'])
            if group == 'round2_milestones':
                assert config2[name]['eval_steps'] == steps
            analyze_levels(levels, row, md, [path])
            assert cellset(a['integer_vertices']) == cellset(levels[9]['predicted_cells'])
        for seed in sorted(expected_seeds-found_seeds):
            missing.append(dict(group=group, path=str(folder), seed=seed, reason='evaluation row exists but prediction absent'))

    # The requested historical sweep evaluations retain one NPZ per layer.
    sweep_identity = {}
    for branch in ['S0', 'S1']:
        folder = SWEEP / 'runs' / branch / 'evaluation'
        identity = jread(folder.parent / 'endpoint_reference.json', 'sweep_endpoint_identity')
        sweep_identity[branch] = identity['checkpoint_reference']
        evaluation = jread(folder / 'evaluation.json', 'saved_evaluation')
        for row in [r for r in evaluation['rows'] if r['uid'] == UID]:
            seed = row['seed']
            native = folder / f'native/seed-{seed}' / UID
            generation = jread(native / 'generation.json', 'native_generation_metadata')
            assert generation['threshold'] == .5 and generation['steps_per_level'] == 20
            files = [native / f'depth-{d}.npz' for d in range(1, 10)]
            arrays = {d: nread(files[d-1], 'saved_layer_prediction_not_uploaded') for d in range(1, 10)}
            for d, path in enumerate(files, 1):
                assert inputs[str(path)]['sha256'] == generation['levels'][d-1]['sha256']
            final = nread(native / 'prediction.npz', 'saved_final_prediction_not_uploaded')
            assert inputs[str(native / 'prediction.npz')]['sha256'] == row['prediction_sha256']
            assert cellset(final['integer_vertices']) == cellset(arrays[9]['predicted_cells'])
            md = dict(id=f'sweep/{branch}/step34000/seed-{seed}', group='sweep', branch=branch,
                      evaluation_folder=str(folder), seed=seed, weights='raw', update=10000, cumulative_step=34000,
                      sampler='euler', steps_per_depth=20, threshold=.5,
                      checkpoint_sha256=identity['checkpoint_reference']['sha256'],
                      checkpoint_sha_source='historical endpoint identity, not rehashed this run',
                      actual_noise_available=True, evaluation_sha256=inputs[str(folder/'evaluation.json')]['sha256'])
            analyze_levels(arrays, row, md, files + [native/'prediction.npz'])
    assert cp1init['sha256'] == sweep_identity['S0']['sha256']

    # Inventory all prediction folders inside the nominated Round1 root, not the full shared disk.
    round1_found = []
    for directory, dirs, files in os.walk(ROUND1):
        dirs[:] = [d for d in dirs if d not in ['source', '.git', '__pycache__']]
        p = Path(directory)
        if p.name == 'predictions' and any(name.endswith(UID + '.npz') for name in files):
            round1_found.append(p.parent)
            dirs[:] = []
    for folder in sorted(round1_found):
        branch = folder.relative_to(ROUND1).parts[0]
        dense_group(folder, 'round1', branch, cp1byname.get(branch, {}).get('sha256'))
    for branch in 'ABC':
        if not (ROUND1 / branch / 'eval_ema/evaluation.json').exists():
            missing.append(dict(group='round1', path=str(ROUND1/branch/'eval_ema'),
                                reason='EMA evaluation not present; no claim it was run'))

    for branch in ['J5_token_fine2', 'J2_token']:
        for update in [1800, 3600, 5400, 7200]:
            dense_group(ROUND2 / 'runs' / branch / 'evals' / f'u{update:06d}_raw', 'round2_milestones', branch)
        # A terminal raw/EMA pair bounds persistence; supplemental to requested milestones.
        for weights in ['raw', 'ema']:
            dense_group(ROUND2 / 'runs' / branch / 'evals' / f'u009000_{weights}',
                        'round2_terminal_supplement', branch)

    lineage = dict(common_start='Round1 A/final.pt at its own update 749',
                   common_start_sha256=config2['J5_token_fine2']['init_sha'],
                   ancestor='S0 cumulative step 34000 -> Round1 A update 749 -> J2 and J5',
                   S1_role='Independent architecture-sweep comparison; not an ancestor of J2/J5',
                   checkpoint_tensors_not_read_or_rehashed=True,
                   round1_S0_init_copy_record=cp1init,
                   round1_A_metadata=next(r for r in cp1meta['rows'] if r['run']=='A'))
    j5raw = [r for r in records if r['branch']=='J5_token_fine2' and r['weights']=='raw']
    temporal = []
    for seed in sorted({r['seed'] for r in j5raw}):
        stream = sorted((r for r in j5raw if r['seed']==seed), key=lambda r:r['update'])
        first_miss = next((r for r in stream if r['target_status']!='occupied'), None)
        earlier = [r for r in stream if first_miss and r['update']<first_miss['update'] and r['target_status']=='occupied']
        temporal.append(dict(seed=seed,
                             last_observed_present_update=earlier[-1]['update'] if earlier else None,
                             first_observed_missing_update=first_miss['update'] if first_miss else None,
                             first_observed_missing_estimate=first_miss['target_estimate'] if first_miss else None,
                             exact_transition_update_unknown=True))
    result = dict(title='Round3 Part D: 001093 follow-up / historical predictions', uid=UID,
                  created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  scope='CPU saved-array recomputation only; no GPU, model forward, checkpoint read, training or repository edits',
                  target_depth6_cell=list(TARGET), depth5_parent=list(PARENT), child_bit=BIT, training_target=1,
                  label_sha256=inputs[str(label_path)]['sha256'], lineage=lineage,
                  rows=records, missing=missing, discovery_roots=[str(ROUND1), str(SWEEP)],
                  J5_raw_first_observed_miss_intervals=temporal,
                  total_predictions=len(records),
                  interpretation_limits=[
                      'Saved milestones are sparse; earliest observed failure does not identify the exact update when the miss began.',
                      'Identical seeds do not establish identical actual noise when generated parent sets/orders differ.',
                      'Round2 milestone arrays do not store actual noise; these are historical observations, not paired causal tests.',
                      'Terminal raw/EMA rows are supplemental; EMA and raw histories are reported separately.'])
    (out/'history.json').write_text(json.dumps(result, indent=2, allow_nan=False)+'\n')
    (out/'input_manifest_history.json').write_text(json.dumps(list(inputs.values()), indent=2)+'\n')
    lines=['# Historical saved predictions for nexus_2k_001093', '',
           '- Target: depth6 (18,31,35), parent (9,15,17), child bit3; GT=1; threshold=0.5.',
           '- Actual shared start: Round1 A/final.pt (update749, SHA '+lineage['common_start_sha256']+').',
           '- S0@34000 is its ancestor. S1 is an independent sweep comparison.',
           '- CPU array recomputation agrees with every available evaluation row; no model replay.', '',
           '## When the target miss was observed', '',
           '- J5 raw: target present in both seeds at updates1800,3600,5400,7200; missing in both at9000.',
           '- Each official seed therefore brackets the observed regression between7200 and9000. Intermediate predictions are not available; the exact transition update is unknown.',
           '- Round1 A, the direct common initialization, retains the target for both official seeds. Earlier S0@34000 misses it for97029000 but retains it for97029001. Thus this is not a continuously missing bit inherited unchanged from S0.',
           '- J2 retains this bit in every inspected milestone and terminal prediction. A correct target bit does not imply a correct complete tree.',
           '- Round1 A/B/C raw and D raw/EMA all retain the bit; all ten of these whole trees still fail elsewhere.', '',
           '| Source | Update / cumulative | Weights | Seed | Estimate | Target | Whole tree | First mismatch |',
           '|---|---:|---|---:|---:|---|---|---:|']
    for r in records:
        value='parent absent' if r['target_estimate'] is None else f"{r['target_estimate']:.9g}"
        lines.append(f"| {r['group']}/{r['branch']} | {r['update']} / {r['cumulative_step']} | {r['weights']} | {r['seed']} | {value} | {r['target_status']} | {'pass' if r['whole_tree_pass'] else 'fail'} | {r['first_mismatch_depth']} |")
    lines += ['', '## Limits', ''] + ['- '+x for x in result['interpretation_limits']]
    lines += ['', '## Missing historical outputs', ''] + ['- '+x['path']+': '+x['reason'] for x in missing]
    (out/'history.md').write_text('\n'.join(lines)+'\n')
    print('HISTORY_CPU_OK',len(records),'predictions;',len(inputs),'input files;',len(missing),'missing folders/records',flush=True)


if __name__ == '__main__':
    main()
