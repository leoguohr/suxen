# Recurring cells: per-seed appendix

Cells recurring in at least 2/10 twenty-step trees. TSV files include all 12 observations and all sibling estimates.

| UID | Depth | Cell | GT | Twenty-step errors | Type / propagation |
|---|---:|---|---:|---:|---|
| nexus_2k_000167 | 6 | (59, 47, 36) | 0 | 10/10 | {'direct_fp_correct_parent': 10} |
| nexus_2k_000167 | 7 | (118, 94, 73) | 0 | 7/10 | {'propagated_fp_wrong_parent': 7} |
| nexus_2k_000167 | 7 | (118, 95, 72) | 0 | 3/10 | {'propagated_fp_wrong_parent': 3} |
| nexus_2k_000167 | 7 | (118, 95, 73) | 0 | 2/10 | {'propagated_fp_wrong_parent': 2} |
| nexus_2k_000167 | 8 | (236, 189, 146) | 0 | 7/10 | {'propagated_fp_wrong_parent': 7, 'parent_absent_gt_empty': 3} |
| nexus_2k_000167 | 8 | (236, 191, 144) | 0 | 3/10 | {'parent_absent_gt_empty': 7, 'propagated_fp_wrong_parent': 3} |
| nexus_2k_000167 | 8 | (236, 191, 146) | 0 | 2/10 | {'parent_absent_gt_empty': 8, 'propagated_fp_wrong_parent': 2} |
| nexus_2k_000167 | 9 | (472, 379, 293) | 0 | 7/10 | {'propagated_fp_wrong_parent': 7, 'parent_absent_gt_empty': 3} |
| nexus_2k_000167 | 9 | (472, 383, 289) | 0 | 3/10 | {'parent_absent_gt_empty': 7, 'propagated_fp_wrong_parent': 3} |
| nexus_2k_000167 | 9 | (472, 383, 293) | 0 | 2/10 | {'parent_absent_gt_empty': 8, 'propagated_fp_wrong_parent': 2} |
| nexus_2k_001232 | 6 | (19, 3, 31) | 1 | 2/10 | {'direct_fn_existing_parent': 2} |
| nexus_2k_001232 | 7 | (31, 102, 23) | 1 | 10/10 | {'direct_fn_existing_parent': 10} |
| nexus_2k_001232 | 7 | (38, 6, 63) | 1 | 2/10 | {'inherited_fn_absent_parent': 2} |
| nexus_2k_001232 | 8 | (62, 205, 47) | 1 | 10/10 | {'inherited_fn_absent_parent': 10} |
| nexus_2k_001232 | 8 | (62, 221, 46) | 1 | 3/10 | {'direct_fn_existing_parent': 3} |
| nexus_2k_001232 | 8 | (77, 12, 126) | 1 | 2/10 | {'inherited_fn_absent_parent': 2} |
| nexus_2k_001232 | 9 | (124, 411, 94) | 1 | 10/10 | {'inherited_fn_absent_parent': 10} |
| nexus_2k_001232 | 9 | (124, 442, 93) | 1 | 3/10 | {'inherited_fn_absent_parent': 3} |
| nexus_2k_001232 | 9 | (155, 25, 253) | 1 | 2/10 | {'inherited_fn_absent_parent': 2} |
| nexus_2k_001232 | 7 | (14, 30, 29) | 0 | 10/10 | {'direct_fp_correct_parent': 10} |
| nexus_2k_001232 | 8 | (28, 61, 59) | 0 | 2/10 | {'propagated_fp_wrong_parent': 2} |
| nexus_2k_001232 | 8 | (29, 60, 59) | 0 | 5/10 | {'propagated_fp_wrong_parent': 5} |
| nexus_2k_001232 | 8 | (29, 61, 59) | 0 | 3/10 | {'propagated_fp_wrong_parent': 3} |
| nexus_2k_001232 | 8 | (62, 221, 47) | 0 | 3/10 | {'direct_fp_correct_parent': 3} |
| nexus_2k_001232 | 9 | (57, 122, 119) | 0 | 2/10 | {'parent_absent_gt_empty': 8, 'propagated_fp_wrong_parent': 2} |
| nexus_2k_001232 | 9 | (58, 121, 119) | 0 | 5/10 | {'propagated_fp_wrong_parent': 5, 'parent_absent_gt_empty': 5} |
| nexus_2k_001232 | 9 | (59, 122, 119) | 0 | 3/10 | {'parent_absent_gt_empty': 7, 'propagated_fp_wrong_parent': 3} |
| nexus_2k_001232 | 9 | (124, 442, 95) | 0 | 3/10 | {'parent_absent_gt_empty': 7, 'propagated_fp_wrong_parent': 3} |

## Stable new errors (10/10 at 20 steps)

| UID / cell | Steps | Seed | Estimate | Tree pass |
|---|---:|---:|---:|---|
| nexus_2k_000167 d6 (59, 47, 36) | 5 | 97029000 | 0.9863399267 | False |
| nexus_2k_000167 d6 (59, 47, 36) | 5 | 97029001 | 0.9882791638 | False |
| nexus_2k_000167 d6 (59, 47, 36) | 20 | 97029000 | 0.9976682663 | False |
| nexus_2k_000167 d6 (59, 47, 36) | 20 | 97029001 | 0.9976539612 | False |
| nexus_2k_000167 d6 (59, 47, 36) | 20 | 97029002 | 1.002176285 | False |
| nexus_2k_000167 d6 (59, 47, 36) | 20 | 97029003 | 1.000411987 | False |
| nexus_2k_000167 d6 (59, 47, 36) | 20 | 97029004 | 0.999548912 | False |
| nexus_2k_000167 d6 (59, 47, 36) | 20 | 97029005 | 1.002778053 | False |
| nexus_2k_000167 d6 (59, 47, 36) | 20 | 97029006 | 0.9961151481 | False |
| nexus_2k_000167 d6 (59, 47, 36) | 20 | 97029007 | 1.000774622 | False |
| nexus_2k_000167 d6 (59, 47, 36) | 20 | 97029008 | 0.9974917173 | False |
| nexus_2k_000167 d6 (59, 47, 36) | 20 | 97029009 | 0.9990769625 | False |
| nexus_2k_001232 d7 (31, 102, 23) | 5 | 97029000 | 0.01566489413 | False |
| nexus_2k_001232 d7 (31, 102, 23) | 5 | 97029001 | 0.004552125931 | False |
| nexus_2k_001232 d7 (31, 102, 23) | 20 | 97029000 | -3.337324597e-05 | False |
| nexus_2k_001232 d7 (31, 102, 23) | 20 | 97029001 | -0.0002304986119 | False |
| nexus_2k_001232 d7 (31, 102, 23) | 20 | 97029002 | 0.001076271757 | False |
| nexus_2k_001232 d7 (31, 102, 23) | 20 | 97029003 | -0.0005535557866 | False |
| nexus_2k_001232 d7 (31, 102, 23) | 20 | 97029004 | 0.0007852911949 | False |
| nexus_2k_001232 d7 (31, 102, 23) | 20 | 97029005 | 0.002604186535 | False |
| nexus_2k_001232 d7 (31, 102, 23) | 20 | 97029006 | -0.0002104714513 | False |
| nexus_2k_001232 d7 (31, 102, 23) | 20 | 97029007 | -0.000142775476 | False |
| nexus_2k_001232 d7 (31, 102, 23) | 20 | 97029008 | 0.0001802816987 | False |
| nexus_2k_001232 d7 (31, 102, 23) | 20 | 97029009 | 4.639849067e-05 | False |
| nexus_2k_001232 d7 (14, 30, 29) | 5 | 97029000 | 0.9719957709 | False |
| nexus_2k_001232 d7 (14, 30, 29) | 5 | 97029001 | 0.9838218093 | False |
| nexus_2k_001232 d7 (14, 30, 29) | 20 | 97029000 | 0.9993394613 | False |
| nexus_2k_001232 d7 (14, 30, 29) | 20 | 97029001 | 1.000716567 | False |
| nexus_2k_001232 d7 (14, 30, 29) | 20 | 97029002 | 0.9991754293 | False |
| nexus_2k_001232 d7 (14, 30, 29) | 20 | 97029003 | 0.9986773729 | False |
| nexus_2k_001232 d7 (14, 30, 29) | 20 | 97029004 | 0.9994322658 | False |
| nexus_2k_001232 d7 (14, 30, 29) | 20 | 97029005 | 0.9995471835 | False |
| nexus_2k_001232 d7 (14, 30, 29) | 20 | 97029006 | 1.001091003 | False |
| nexus_2k_001232 d7 (14, 30, 29) | 20 | 97029007 | 1.000468254 | False |
| nexus_2k_001232 d7 (14, 30, 29) | 20 | 97029008 | 1.001618981 | False |
| nexus_2k_001232 d7 (14, 30, 29) | 20 | 97029009 | 0.9994683266 | False |
