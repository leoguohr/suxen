"""Validate and package the CPU-only Part D evidence without model/prediction tensors."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = Path('/guohaoran/tmp/nexus_vertex_round3_batch2A_eval_20261015/repo')
COMMIT = 'e7e3a326a65bc550be695104ae69e0d3435bd446'


def encoded(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(name):
    return json.loads((ROOT / name).read_text())


def main():
    assert str(ROOT).startswith('/guohaoran/') and os.environ.get('CUDA_VISIBLE_DEVICES') == ''
    bundle = ROOT / 'publication'
    assert not bundle.exists(), 'Do not overwrite a publication'
    git = lambda *a: subprocess.check_output(['git', *a], cwd=REPO, text=True).strip()
    assert git('rev-parse', 'HEAD') == COMMIT and git('status', '--porcelain') == ''
    history, density, recurrence = [read(n + '.json') for n in ('history', 'density', 'recurrence')]
    assert history['total_predictions'] == 38 and len(history['rows']) == 38
    assert density['complete'] and density['condition_slots'] == 8192
    assert density['occupied_d6_cells'] == len(density['all_occupied_d6_cells']) == 1152
    assert all(density['verification'].values())
    assert recurrence['prediction_count'] == 36 and all(recurrence['checks'].values())
    assert read('recurrence_cells.json')['recurrence_source_sha256'] == sha(ROOT / 'recurrence.json')
    inputs = {}

    def verify(value):
        if isinstance(value, list):
            for item in value:
                verify(item)
        elif isinstance(value, dict):
            if 'path' in value and 'sha256' in value:
                p = Path(value['path'])
                assert p.is_file() and p.suffix not in ('.pt', '.pth'), 'Unexpected missing or model input'
                expected = value['sha256']
                if str(p) not in inputs:
                    assert sha(p) == expected, 'Input changed: ' + str(p)
                    if 'bytes' in value:
                        assert p.stat().st_size == value['bytes']
                    inputs[str(p)] = dict(path=str(p), sha256=expected, bytes=p.stat().st_size)
                else:
                    assert inputs[str(p)]['sha256'] == expected
            for item in value.values():
                if isinstance(item, (list, dict)):
                    verify(item)

    for name in ('history', 'density', 'recurrence'):
        verify(read('input_manifest_' + name + '.json'))
    prediction_npz = {x['path'] for x in read('input_manifest_history.json') if 'prediction' in x['kind']}
    prediction_npz.update(x['path'] for x in read('input_manifest_recurrence.json')['inputs'] if 'prediction' in x['kind'])
    assert len(prediction_npz) == 110 and prediction_npz <= inputs.keys()
    compact = []
    stable = []
    for s in recurrence['summaries']:
        compact.append({k: v for k, v in s.items() if k != 'candidate_cells'})
        for c in s['candidate_cells']:
            if c['direct_error_count_20_steps'] == 10:
                stable.append({'uid': s['uid'], **{k: v for k, v in c.items() if k != 'observations'}})
    assert len(stable) == 3
    status = dict(title='Round3 Part D: 001093 follow-up', complete=True,
        scope='CPU saved-array and geometric analysis; no training, GPU, model forward, checkpoint load or repo change',
        code_commit=COMMIT, history_prediction_trees=38, recurrence_prediction_trees=36, saved_prediction_npz_files=110,
        verified_unique_input_files=len(inputs), condition_points=8192, occupied_depth6_cells=1152,
        onset_intervals=history['J5_raw_first_observed_miss_intervals'],
        density_target=density['target'], density_summaries=density['summaries'],
        recurrence_summary=compact, stable_direct_errors=stable, missing_history=history['missing'])
    (ROOT / 'STATUS.json').write_bytes(encoded(status))
    (ROOT / 'VERIFICATION.json').write_bytes(encoded(dict(
        all_input_hashes_rechecked=True, repo_clean_at_commit=COMMIT,
        prediction_trees_recomputed=74, prediction_npz_files=110, inputs=list(inputs.values()),
        density_independent_distance_checks=density['verification']['independent_direct_distance_checks_all_vertices'],
        no_model_checkpoints_read=True, no_gpu=True)))
    intro = '''# Round3 Part D: 001093 follow-up

CPU-only analysis of 74 saved full-tree trajectories (110 NPZ files, including separately stored sweep layers), the original 8192-point training condition, and hash-bound labels. No training, GPU, model forward, checkpoint loading, repository edits, new generation or repair.

## Findings

- **J5's target bit regressed between saved raw updates 7200 and 9000, in both official seeds.** The four requested earlier milestones all retain it. No intermediate saved prediction identifies the exact transition update.
- **The target is not persistently absent from the common start.** Round1 A/final (update 749) retains it in both seeds. Its S0 ancestor misses it for one seed, then Round1 A recovers it. S1 is a comparison branch, not the J2/J5 initializer.
- **Local condition sampling is sparse, but the target cell is not unusually empty by the requested cell-count comparison:** 1 point, versus other-cell min/p05/median 0/0/1; 499/1151 other occupied cells have fewer points. This does not establish the cause of the miss.
- **J2's three all-10-seed failures have different error patterns.** 001792 changes error location across seeds and passes both 5-step trees. 000167 has a stable extra bit; 001232 has a stable missing bit plus a stable extra bit. Both also have seed-dependent errors.

## Density conventions

Depth-9 integer triples identify cells. Actual decoding uses their centers `q+0.5`; original float GT vertices retain subcell offsets. Counts at radius 4 differ between these centers, so all three interpretations—including literal integer coordinates—are reported separately below. Radius neighborhoods are Euclidean and inclusive. For per-cell comparisons, union counts count each condition point once across that cell's GT vertices; per-vertex min/mean/median and all individual counts are also in `density.json`.

## Stable direct J2 errors

| UID | Depth / cell | Type / training label | 20-step errors | 5-step errors | 20-step estimate range |
|---|---|---|---:|---:|---|
'''
    for c in stable:
        kind = 'FN / 1 (present)' if c['training_target'] else 'FP / 0 (absent)'
        intro += f"| {c['uid']} | {c['depth']} / {tuple(c['cell'])} | {kind} | {c['direct_error_count_20_steps']}/10 | {c['direct_error_count_5_steps']}/2 | {c['estimate_min_20_steps']:.10g} to {c['estimate_max_20_steps']:.10g} |\n"
    intro += '''
Training labels contain the missing GT cells, including 001232 depth7 (31,102,23). The two stable false positives are correctly absent from the labels; they must not be described as missing GT. The full 12 observations and all 8 sibling estimates for each candidate are in `recurrence.json`. `recurrence_cells.json/md/tsv` and `recurrence_siblings.tsv` list all 28 repeated global error cells, explicitly distinguishing direct errors from inherited descendants.

## Detailed historical observations

'''
    report = intro + (ROOT / 'history.md').read_text().replace('# Historical saved predictions for nexus_2k_001093', '', 1)
    report += '\n## Input density results\n\n' + (ROOT / 'density.md').read_text().split('\n', 1)[1]
    report += '\n## J2 per-object results\n\n' + (ROOT / 'recurrence.md').read_text().split('## nexus_2k_001792')[0].split('\n', 1)[1]
    report += '''
## Evidence and execution

- `history.json`: 38 per-tree historical rows, 9-level verification, provenance and missing-output inventory.
- `density.json`: all 1152 occupied D6 cells and all per-vertex counts under each explicit coordinate convention.
- `recurrence.json`: 36 trees, complete per-depth FP/FN, direct/inherited classification, candidate estimates and siblings.
- `recurrence_cells.*`, `recurrence_siblings.tsv`: per-seed tables for recurring cells.
- Ad-hoc scripts, execution logs, input manifests, `VERIFICATION.json`, and `EXECUTION.txt` are included in the compressed evidence. No `.pt`, `.npz`, or `predictions/` folder is uploaded.
- Every source input hash was independently rechecked before packaging; the frozen repository remains clean at e7e3a326a65bc550be695104ae69e0d3435bd446.

Saved seeds alone do not prove identical actual noise when parent sets/order differ. Sparse historical observations bound the regression interval, not its precise cause. These outputs support follow-up analysis; no training intervention is prescribed or executed in this task.
'''
    (ROOT / 'REPORT.md').write_text(report)
    env = 'CUDA_VISIBLE_DEVICES= PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION=python OMP_NUM_THREADS=8 PYTHONDONTWRITEBYTECODE=1'
    py = '/guohaoran/envs/nexus-algo/bin/python'
    commands = [f'{env} {py} {ROOT}/history_analyze.py --output {ROOT}',
        f'{env} {py} {ROOT}/density.py --repo {REPO} --training-root /guohaoran/tmp/nexus_vertex_dense_round2_20261009 --output {ROOT}',
        f'{env} {py} {ROOT}/recurrence.py --output {ROOT}']
    commands += [f'{env} {py} {ROOT}/recurrence_appendix.py', f'{env} {py} {ROOT}/package_partd.py']
    (ROOT / 'EXECUTION.txt').write_text('\n'.join(commands) + '\n\nAll analyses ran successfully on CPU. Inspect their logs and history_execution.json for exact invocation details.\n')
    names = ['history_analyze.py', 'history.json', 'history.md', 'history.log', 'history_execution.json', 'input_manifest_history.json',
        'density.py', 'density.json', 'density.md', 'density.log', 'input_manifest_density.json',
        'recurrence.py', 'recurrence.json', 'recurrence.md', 'recurrence.log', 'input_manifest_recurrence.json',
        'recurrence_appendix.py', 'recurrence_appendix.log', 'recurrence_cells.json', 'recurrence_cells.md', 'recurrence_cells.tsv', 'recurrence_siblings.tsv',
        'package_partd.py', 'publish_partd.py', 'REPORT.md', 'STATUS.json', 'VERIFICATION.json', 'EXECUTION.txt']
    files = [ROOT / n for n in names]
    assert all(p.is_file() and p.stat().st_size < 25 << 20 for p in files)
    payload = bundle / 'payload'; payload.mkdir(parents=True)
    manifest = [dict(path=p.name, bytes=p.stat().st_size, sha256=sha(p)) for p in files]
    (payload / 'FILE_MANIFEST.json').write_bytes(encoded(manifest))
    archive = payload / 'round3-partd-001093-evidence.tgz'
    with tarfile.open(archive, 'w:gz') as tar:
        for p in files:
            tar.add(p, arcname=p.name, recursive=False)
    for n in ('REPORT.md', 'STATUS.json'):
        shutil.copy2(ROOT / n, payload / n)
    (bundle / 'UPLOAD_MANIFEST.json').write_bytes(encoded([
        dict(path=p.name, bytes=p.stat().st_size, sha256=sha(p)) for p in sorted(payload.iterdir())]))
    print(json.dumps(dict(result='PARTD_PACKAGE_VERIFIED', archive_bytes=archive.stat().st_size,
                         input_files=len(inputs), prediction_trees=74, prediction_npz_files=110, report_bytes=(ROOT / 'REPORT.md').stat().st_size)))


if __name__ == '__main__':
    main()
