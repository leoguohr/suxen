# Round3 Part D: condition density of nexus_2k_001093

- Fixed training condition: 8192 XYZ+normal slots; 8192 unique XYZ values.
- Occupied depth-6 cells: 1152; comparison cells excluding target: 1151.
- Coordinates: u=(XYZ+1)*256; depth-6 cells use [8c,8(c+1)); radii are Euclidean and inclusive.
- Main radius interpretation: true float GT vertices. D9 native decoder centers q+0.5 and literal integer q are separate checks.
- Counts do not deduplicate condition slots. No model, GPU, resampling or fitted alignment used.

| Statistic | Target | Other-cell min | p05 | median | Other cells strictly lower |
|---|---:|---:|---:|---:|---:|
| inside_cell | 1 | 0 | 0 | 1 | 499/1151 (43.354%) |
| d9_decoded_center/radius2/union_condition_slots | 0 | 0 | 0 | 0 | 0/1151 (0.000%) |
| d9_decoded_center/radius4/union_condition_slots | 2 | 0 | 0 | 1 | 848/1151 (73.675%) |
| source_float_gt/radius2/union_condition_slots | 0 | 0 | 0 | 0 | 0/1151 (0.000%) |
| source_float_gt/radius4/union_condition_slots | 2 | 0 | 0 | 1 | 852/1151 (74.023%) |

| Center convention | Vertex centers (D9 units) | Within 2 | Within 4 |
|---|---|---|---|
| source_float_gt | [[145.59100341796875, 250.17376375198364, 285.12769508361816], [148.35892486572266, 250.17376375198364, 282.05692291259766]] | [0, 0] | [2, 0] |
| d9_decoded_center | [[145.5, 250.5, 285.5], [148.5, 250.5, 282.5]] | [0, 0] | [2, 1] |
| literal_d9_integer | [[145.0, 250.0, 285.0], [148.0, 250.0, 282.0]] | [0, 0] | [0, 0] |

Every occupied cell and every vertex count is included in density.json.
The input, label and manifest hashes are verified against both J2 and J5's actual training checkouts.
Independent direct squared-distance calculations reproduce all KD-tree radius and union counts.
Radius-4 counts depend on the vertex convention: true float GT gives [2,0], decoded centers [2,1], literal integer corners [0,0].
These counts describe local sampling density; they do not establish the causal reason for the model miss.
