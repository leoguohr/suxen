"""CPU-only Round3 Part D condition-density audit; no repository imports."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from scipy.spatial import cKDTree


UID = "nexus_2k_001093"
TARGET = (18, 31, 35)
VERTICES = {(145, 250, 285), (148, 250, 282)}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def stats(values):
    a = np.asarray(values, dtype=np.float64)
    return {"n": len(a), "min": float(a.min()), "p05_linear": float(np.percentile(a, 5)),
            "median": float(np.median(a)), "max": float(a.max())}


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--repo", type=Path, required=True)
    p.add_argument("--training-root", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    here = args.repo / "vertex/dense_overfit50_20261009"
    data = here / "data"
    manifest_path = data / "prepared_d9/manifest.json"
    manifest = json.loads(manifest_path.read_text())
    record = next(r for r in manifest["records"] if r["uid"] == UID)
    paths = {
        "condition": data / record["condition_file"],
        "d9_label": data / "prepared_d9" / record["label_file"],
        "source_d15_label": data / record["source_label_file"],
    }
    expected = {"condition": record["condition_sha256"], "d9_label": record["label_sha256"],
                "source_d15_label": record["source_label_sha256"]}
    inputs = []
    for kind, path in paths.items():
        actual = sha(path)
        assert actual == expected[kind], (kind, actual, expected[kind])
        inputs.append({"role": kind, "path": str(path), "sha256": actual, "matches_manifest": True})
    inputs.append({"role": "manifest", "path": str(manifest_path), "sha256": sha(manifest_path)})
    training_identity = []
    for job, repo_name, shell in [("J2_token", "repo", "run_round2.sh"),
                                  ("J5_token_fine2", "repo_round2b", "run_round2b.sh")]:
        training = args.training_root / repo_name / "vertex/dense_overfit50_20261009"
        mpath = training / "data/prepared_d9/manifest.json"
        m = json.loads(mpath.read_text())
        r = next(x for x in m["records"] if x["uid"] == UID)
        assert r == record
        config_path = args.training_root / "runs" / job / "config.json"
        config = json.loads(config_path.read_text())
        assert config["uids"] == manifest["train_uids"]
        files = [mpath, training / "common.py", training / "dense_train.py",
                 args.training_root / "jobs" / shell, config_path]
        for key, path in paths.items():
            rel = path.relative_to(data)
            training_file = training / "data" / rel
            assert sha(training_file) == expected[key]
            files.append(training_file)
        training_identity.append({"job": job, "record_matches": True,
                                  "files": [{"path": str(f), "sha256": sha(f)} for f in files]})
    with np.load(paths["condition"], allow_pickle=False) as f:
        points = f["points"].astype(np.float64)
        normals = f["normals"].astype(np.float64)
    assert points.shape == normals.shape == (8192, 3)
    assert np.isfinite(points).all() and np.isfinite(normals).all()
    assert points.min() >= -1.0 and points.max() <= 1.0
    with np.load(paths["d9_label"], allow_pickle=False) as f:
        leaves = f["leaves"].astype(np.int64)
        assert int(f["depth"]) == 9
    with np.load(paths["source_d15_label"], allow_pickle=False) as f:
        raw_gt = f["gt_normalized"].astype(np.float64)
        d15 = f["leaves"].copy()
    unique_gt = np.unique(raw_gt, axis=0)
    gt_u = (unique_gt + 1.0) * 256.0
    gt_q = np.floor(gt_u).clip(0, 511).astype(np.int64)
    assert np.array_equal(np.unique(gt_q, axis=0), leaves)
    assert np.array_equal(np.unique(d15 >> 6, axis=0), leaves)
    cloud_u = (points + 1.0) * 256.0
    tree = cKDTree(cloud_u)
    cells = np.unique(leaves >> 3, axis=0)
    targets = leaves[np.all((leaves >> 3) == TARGET, axis=1)]
    assert set(map(tuple, targets)) == VERTICES
    rows = []
    for cell in cells:
        mask = np.all((leaves >> 3) == cell, axis=1)
        gt_mask = np.all((gt_q >> 3) == cell, axis=1)
        qs, gs, gu = leaves[mask], unique_gt[gt_mask], gt_u[gt_mask]
        lower, upper = cell * 8, (cell + 1) * 8
        inside = np.all((cloud_u >= lower) & (cloud_u < upper), axis=1)
        row = {"cell": cell.tolist(), "condition_slots_inside_half_open_cell": int(inside.sum()),
               "d9_leaves": qs.tolist(), "unique_float_gt_count": len(gs),
               "d9_leaf_count": len(qs), "neighborhoods": {}}
        # Centers are the native XYZ decoder; float GT is the source geometry.
        # Literal integer coordinates are an extra convention sensitivity check.
        for convention, centers in [("d9_decoded_center", qs.astype(np.float64) + .5),
                                    ("source_float_gt", gu),
                                    ("literal_d9_integer", qs.astype(np.float64))]:
            neighborhoods = {}
            for radius in (2, 4):
                hits = tree.query_ball_point(centers, radius, p=2, eps=0, workers=1)
                counts = [len(x) for x in hits]
                union = len(set().union(*(set(x) for x in hits)))
                neighborhoods[str(radius)] = {
                    "per_vertex_counts": counts, "per_vertex_min": min(counts),
                    "per_vertex_mean": float(np.mean(counts)), "per_vertex_median": float(np.median(counts)),
                    "union_condition_slots": union,
                }
            row["neighborhoods"][convention] = {"centers_in_d9_units": centers.tolist(),
                                               "radius": neighborhoods}
        row["source_float_gt_xyz"] = gs.tolist()
        row["source_float_gt_d9_cells"] = gt_q[gt_mask].tolist()
        rows.append(row)
    target_row = next(r for r in rows if tuple(r["cell"]) == TARGET)
    # Independent direct-distance check of every neighborhood count.
    checked_vertices = 0
    for row in rows:
        for neighborhood in row["neighborhoods"].values():
            centers = np.asarray(neighborhood["centers_in_d9_units"])
            squared = ((centers[:, None, :] - cloud_u[None, :, :]) ** 2).sum(-1)
            for radius in (2, 4):
                assert (squared <= radius ** 2).sum(1).tolist() == neighborhood["radius"][str(radius)]["per_vertex_counts"]
                assert int((squared <= radius ** 2).any(0).sum()) == neighborhood["radius"][str(radius)]["union_condition_slots"]
            checked_vertices += len(centers)
    others = [r for r in rows if tuple(r["cell"]) != TARGET]
    selectors = {"inside_cell": lambda r: r["condition_slots_inside_half_open_cell"]}
    for convention in ("d9_decoded_center", "source_float_gt", "literal_d9_integer"):
        for radius in ("2", "4"):
            for aggregate in ("per_vertex_min", "per_vertex_mean", "per_vertex_median", "union_condition_slots"):
                selectors[f"{convention}/radius{radius}/{aggregate}"] = (
                    lambda r, c=convention, d=radius, a=aggregate: r["neighborhoods"][c]["radius"][d][a])
    summaries = {}
    for name, fn in selectors.items():
        target_value = fn(target_row)
        fewer_other = sum(fn(r) < target_value for r in others)
        fewer_all = sum(fn(r) < target_value for r in rows)
        summaries[name] = {"target": target_value, "all_occupied_cells": stats([fn(r) for r in rows]),
                           "other_occupied_cells": stats([fn(r) for r in others]),
                           "strictly_fewer_other_count": fewer_other, "other_denominator": len(others),
                           "strictly_fewer_other_fraction": fewer_other / len(others),
                           "strictly_fewer_all_count": fewer_all, "all_denominator": len(rows),
                           "strictly_fewer_all_fraction": fewer_all / len(rows)}
    vertex_stats = {}
    for convention in ("d9_decoded_center", "source_float_gt", "literal_d9_integer"):
        for radius in ("2", "4"):
            all_counts = sum([r["neighborhoods"][convention]["radius"][radius]["per_vertex_counts"] for r in rows], [])
            other_counts = sum([r["neighborhoods"][convention]["radius"][radius]["per_vertex_counts"] for r in others], [])
            vertex_stats[f"{convention}/radius{radius}"] = {"all_vertices": stats(all_counts),
                                                          "other_cell_vertices": stats(other_counts)}
    source_evidence = {
        "loader": "common.py:51-75; concatenates saved points/normals, checks SHA256 and [8192,6]",
        "train_load": "J5 actual repo_round2b dense_train.py:344; load_data(device); later evaluation checkout line346",
        "train_condition": "dense_train.py:140; model.condition_encoder(batch)",
        "decode": "vendor/mini_nexus/octree.py:41-49; -1+(q+0.5)*2/512",
        "quantize": "vendor/mini_nexus/octree.py:21-32; floor((x+1)*resolution/2), clamped",
        "no_fitted_alignment": True,
    }
    result = {
        "complete": True, "uid": UID, "target_cell": list(TARGET), "target_d9_vertices": sorted([list(v) for v in VERTICES]),
        "method": {
            "coordinates": "u=(saved normalized XYZ+1)*256; one unit is one depth-9 cell width",
            "cell_inclusion": "8*c <= u < 8*(c+1), componentwise; half-open cells",
            "radii": "Euclidean ||u-center||_2 <= r for r=2,4; no fit or resampling",
            "primary_centers": "Source float GT; D9 native decoder centers q+0.5 and literal integer q separately reported",
            "slots": "All 8192 condition slots count; no point deduplication. Normals are training condition, omitted from geometric distance",
            "percentile": "numpy percentile, linear interpolation; strict fewer (<), not <=",
            "per_cell_radius_comparison": "union count plus per-vertex min/mean/median, all explicitly distinct",
        },
        "condition_slots": len(points), "unique_condition_xyz": len(np.unique(points, axis=0)),
        "duplicate_condition_slots": len(points) - len(np.unique(points, axis=0)),
        "cloud_xyz_min": points.min(axis=0).tolist(), "cloud_xyz_max": points.max(axis=0).tolist(),
        "raw_gt_records": len(raw_gt), "unique_float_gt_vertices": len(unique_gt), "d9_leaves": len(leaves),
        "d9_quantization_collisions": len(unique_gt)-len(leaves),
        "occupied_d6_cells": len(rows), "target": target_row,
        "summaries": summaries, "vertex_count_distributions": vertex_stats,
        "all_occupied_d6_cells": rows, "source_evidence": source_evidence,
        "verification": {"hashes_match_manifest": True, "matches_J2_J5_training_files": True,
                         "float_gt_requantizes_to_d9_label": True, "d15_shift6_equals_d9": True,
                         "target_training_leaves_exactly_expected_two": True,
                         "independent_direct_distance_checks_all_vertices": checked_vertices},
    }
    write(args.output / "density.json", result)
    write(args.output / "input_manifest_density.json", {"inputs": inputs, "training_identity": training_identity,
          "analysis_script_sha256": sha(__file__), "repo_code_imported": False, "cuda_used": False})
    lines = ["# Round3 Part D: condition density of nexus_2k_001093", "",
             f"- Fixed training condition: {len(points)} XYZ+normal slots; {len(np.unique(points,axis=0))} unique XYZ values.",
             f"- Occupied depth-6 cells: {len(rows)}; comparison cells excluding target: {len(others)}.",
             "- Coordinates: u=(XYZ+1)*256; depth-6 cells use [8c,8(c+1)); radii are Euclidean and inclusive.",
             "- Main radius interpretation: true float GT vertices. D9 native decoder centers q+0.5 and literal integer q are separate checks.",
             "- Counts do not deduplicate condition slots. No model, GPU, resampling or fitted alignment used.", "",
             "| Statistic | Target | Other-cell min | p05 | median | Other cells strictly lower |", "|---|---:|---:|---:|---:|---:|"]
    for name, s in summaries.items():
        if name == "inside_cell" or ("source_float_gt" in name and name.endswith("union_condition_slots")) or ("d9_decoded_center" in name and name.endswith("union_condition_slots")):
            d=s["other_occupied_cells"]
            lines.append(f"| {name} | {s['target']:g} | {d['min']:g} | {d['p05_linear']:g} | {d['median']:g} | {s['strictly_fewer_other_count']}/{s['other_denominator']} ({s['strictly_fewer_other_fraction']:.3%}) |")
    lines += ["", "| Center convention | Vertex centers (D9 units) | Within 2 | Within 4 |", "|---|---|---|---|"]
    for c in ("source_float_gt", "d9_decoded_center", "literal_d9_integer"):
        n = target_row["neighborhoods"][c]
        lines.append(f"| {c} | {n['centers_in_d9_units']} | {n['radius']['2']['per_vertex_counts']} | {n['radius']['4']['per_vertex_counts']} |")
    lines += ["", "Every occupied cell and every vertex count is included in density.json.",
              "The input, label and manifest hashes are verified against both J2 and J5's actual training checkouts.",
              "Independent direct squared-distance calculations reproduce all KD-tree radius and union counts.",
              "Radius-4 counts depend on the vertex convention: true float GT gives [2,0], decoded centers [2,1], literal integer corners [0,0].",
              "These counts describe local sampling density; they do not establish the causal reason for the model miss."]
    (args.output / "density.md").write_text("\n".join(lines)+"\n")
    print(json.dumps({"target": target_row, "inside_summary": summaries["inside_cell"],
                      "occupied_d6_cells": len(rows), "condition_slots": len(points),
                      "verification": result["verification"]}, indent=2))
    print("DENSITY_CPU_AUDIT_PASSED")


if __name__ == "__main__":
    main()
