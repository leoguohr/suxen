"""Round3 Part D, item 3: CPU-only reconstruction of J2 repeated errors."""
import argparse
from collections import Counter
import datetime
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys

import numpy as np

UIDS = ['nexus_2k_001792', 'nexus_2k_000167', 'nexus_2k_001232']
OFFSETS = np.array([[i >> 2 & 1, i >> 1 & 1, i & 1] for i in range(8)], dtype=np.int64)
SOURCE = Path('/guohaoran/tmp/nexus_vertex_round3_batch2A_eval_20261015/repo')
WORK = SOURCE / 'vertex/dense_overfit50_20261009'
ROUND2 = Path('/guohaoran/tmp/nexus_vertex_dense_round2_20261009')
BATCH1 = Path('/guohaoran/tmp/nexus_round3_eval_20261015/round3_eval')
EXPECTED_COMMIT = 'e7e3a326a65bc550be695104ae69e0d3435bd446'


def cells(a):
    return set(map(tuple, np.asarray(a, dtype=np.int64).reshape(-1, 3).tolist()))


def coords(s):
    return [list(c) for c in sorted(s)]


def parent(c):
    return tuple(int(v) // 2 for v in c)


def key(depth, c):
    return (depth, *c)


def write(path, data):
    path.write_text(json.dumps(data, indent=2, allow_nan=False) + '\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    out = args.output.resolve()
    assert str(out).startswith('/guohaoran/') and os.environ.get('CUDA_VISIBLE_DEVICES') == ''
    out.mkdir(parents=True, exist_ok=True)
    assert not (out / 'recurrence.json').exists(), 'Do not overwrite previous output'
    git = lambda *a: subprocess.check_output(['git', *a], cwd=SOURCE, text=True).strip()
    assert git('rev-parse', 'HEAD') == EXPECTED_COMMIT and git('status', '--porcelain') == ''
    inventory = {}

    def read(path, kind):
        path = Path(path)
        b = path.read_bytes()
        inventory[str(path)] = {'path': str(path), 'kind': kind, 'bytes': len(b),
                                'sha256': hashlib.sha256(b).hexdigest()}
        return b

    def js(path, kind):
        return json.loads(read(path, kind))

    def npz(path, kind):
        with np.load(io.BytesIO(read(path, kind)), allow_pickle=False) as z:
            return {k: z[k].copy() for k in z.files}

    manifest = js(WORK / 'data/prepared_d9/manifest.json', 'training_manifest')
    config = js(ROUND2 / 'runs/J2_token/config.json', 'training_config')
    assert all(u in config['uids'] for u in UIDS)
    import torch
    octree_path = WORK / 'vendor/mini_nexus/octree.py'
    read(octree_path, 'frozen_source')
    spec = importlib.util.spec_from_file_location('partd_frozen_octree', octree_path)
    octree = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = octree
    spec.loader.exec_module(octree)
    for n in ['common.py', 'evaluate.py', 'dense_train.py', 'analyze_boundary.py', 'analyze_cascade.py']:
        read(WORK / n, 'frozen_source')
    truths, training = {}, {}
    for uid in UIDS:
        record = next(r for r in manifest['records'] if r['uid'] == uid)
        path = WORK / 'data/prepared_d9' / record['label_file']
        label = npz(path, 'training_label')
        assert inventory[str(path)]['sha256'] == record['label_sha256']
        assert int(label['depth']) == 9
        leaves = label['leaves']
        truths[uid] = {d: cells(leaves >> (9-d)) for d in range(1, 10)}
        truths[uid][0] = {(0, 0, 0)}
        native = octree.build_octree_levels(torch.from_numpy(leaves.copy()), 9)
        for d, level in enumerate(native, 1):
            p, t = level.parent_codes.numpy(), level.target.numpy()
            assert cells(p) == truths[uid][d-1]
            assert cells((p[:, None] * 2 + OFFSETS)[t.astype(bool)]) == truths[uid][d]
        copies = []
        for p in sorted(ROUND2.glob('repo*/vertex/dense_overfit50_20261009/data/prepared_d9/' + uid + '.npz')):
            read(p, 'training_checkout_label_copy')
            assert inventory[str(p)]['sha256'] == record['label_sha256']
            copies.append(inventory[str(p)])
        training[uid] = {'uid_in_training_config': True, 'training_label': str(path),
                         'sha256': record['label_sha256'], 'unique_d9_vertices': len(leaves),
                         'frozen_build_octree_levels_all_depths_checked': True,
                         'training_checkout_copies': copies}

    groups = [(20, ROUND2 / 'runs/J2_token/evals/u009000_ema', [97029000, 97029001]),
              (5, BATCH1 / 'J2_ema_euler5_official', [97029000, 97029001])]
    for s in range(97029002, 97029010, 2):
        groups.append((20, BATCH1 / f'J2_ema_euler20_seeds{s}_{s+1}', [s, s+1]))
    rows, arrays = [], {}
    for steps, folder, seeds in groups:
        evaluation = js(folder / 'evaluation.json', 'evaluation')
        assert evaluation['weights'] == 'ema' and evaluation['update'] == 9000
        assert evaluation.get('steps_per_depth', steps) == steps
        assert evaluation.get('sampler', 'euler') == 'euler'
        for uid in UIDS:
            expected = {f'seed-{s}_{uid}.npz' for s in seeds}
            assert {p.name for p in (folder / 'predictions').glob(f'seed-*_{uid}.npz')} == expected
            for seed in seeds:
                path = folder / 'predictions' / f'seed-{seed}_{uid}.npz'
                a = npz(path, 'prediction_input_not_uploaded')
                saved = next(r for r in evaluation['rows'] if r['uid'] == uid and r['seed'] == seed)
                assert saved['status'] == 'complete'
                levels = []
                for d in range(1, 10):
                    p, occ, est = [a[f'depth{d}_{n}'] for n in ['parents', 'occupancy', 'estimate']]
                    ps = cells(p)
                    assert len(ps) == len(p) and p.shape == (len(p), 3)
                    assert occ.shape == (len(p), 8) and est.shape == (1, len(p), 8)
                    assert np.isfinite(est).all() and np.array_equal(est[0] >= .5, occ)
                    assert ps == ({(0, 0, 0)} if d == 1 else previous)
                    pred = cells((p[:, None] * 2 + OFFSETS)[occ.astype(bool)])
                    assert pred == cells(a[f'depth{d}_predicted_cells'])
                    gt = truths[uid][d]
                    missing, extra = gt-pred, pred-gt
                    direct_fn = {c for c in missing if parent(c) in ps}
                    inherited_fn = missing-direct_fn
                    direct_fp = {c for c in extra if parent(c) in truths[uid][d-1]}
                    propagated_fp = extra-direct_fp
                    level = {'depth': d, 'exact': pred == gt, 'tp': len(pred & gt),
                             'fp': len(extra), 'fn': len(missing), 'missing': coords(missing),
                             'extra': coords(extra), 'direct_fn_existing_parent': coords(direct_fn),
                             'inherited_fn_absent_parent': coords(inherited_fn),
                             'direct_fp_correct_parent': coords(direct_fp),
                             'propagated_fp_wrong_parent': coords(propagated_fp)}
                    sr = next(v for v in saved['levels'] if v['depth'] == d)
                    assert level['exact'] == sr['exact']
                    assert (len(pred & gt), len(extra), len(missing)) == tuple(sr[f'global_cells_{x}'] for x in ['tp', 'fp', 'fn'])
                    assert len(direct_fn) == sr['generated_parent_bits']['fn']
                    assert len(extra) == sr['generated_parent_bits']['fp']
                    levels.append(level)
                    previous = pred
                assert previous == cells(a['integer_vertices'])
                exact = all(v['exact'] for v in levels)
                first = next((v['depth'] for v in levels if not v['exact']), None)
                assert exact == saved['all_levels_exact'] and first == saved['first_mismatch_depth']
                assert levels[-1]['exact'] == saved['native_final_set_exact']
                assert len(previous) == saved['predicted_n']
                rid = f'{uid}_s{steps}_{seed}'
                assert rid not in arrays
                arrays[rid] = a
                rows.append({'id': rid, 'uid': uid, 'steps': steps, 'seed': seed, 'weights': 'ema',
                             'update': 9000, 'prediction': str(path), 'sha256': inventory[str(path)]['sha256'],
                             'evaluation': str(folder/'evaluation.json'), 'tree_pass': exact,
                             'final_leaf_set_exact': levels[-1]['exact'], 'first_mismatch_depth': first,
                             'predicted_n': len(previous), 'target_n': len(truths[uid][9]), 'levels': levels})
    rows.sort(key=lambda r: (r['uid'], r['steps'], r['seed']))
    assert len(rows) == 36 and Counter(r['uid'] for r in rows) == dict.fromkeys(UIDS, 12)

    summaries = []
    for uid in UIDS:
        own = [r for r in rows if r['uid'] == uid]
        r20 = [r for r in own if r['steps'] == 20]
        r5 = [r for r in own if r['steps'] == 5]
        assert len(r20) == 10 and len(r5) == 2
        # Track all cells that were a new/direct error at least once. Inherited downstream
        # misses and wrong-branch descendants remain explicit in every per-depth row.
        candidates = set()
        for r in own:
            for l in r['levels']:
                for field in ['direct_fn_existing_parent', 'direct_fp_correct_parent']:
                    candidates.update(key(l['depth'], tuple(c)) for c in l[field])
        candidate_rows = []
        for k in sorted(candidates):
            depth, *xyz = k
            c, par = tuple(xyz), parent(xyz)
            bit = int(np.array(xyz) % 2 @ np.array([4, 2, 1]))
            gt = int(c in truths[uid][depth])
            observations = []
            for r in own:
                a = arrays[r['id']]
                p = a[f'depth{depth}_parents']
                ix = np.flatnonzero(np.all(p == np.array(par), axis=1))
                assert len(ix) <= 1
                estimates = a[f'depth{depth}_estimate'][0, ix[0]] if len(ix) else None
                siblings = [{'bit': b, 'cell': child.tolist(), 'ground_truth': int(tuple(child) in truths[uid][depth]),
                             'estimate': float(estimates[b]) if estimates is not None else None,
                             'occupied': bool(estimates[b] >= .5) if estimates is not None else None}
                            for b, child in enumerate(np.array(par)*2 + OFFSETS)]
                present = estimates is not None
                estimate = float(estimates[bit]) if present else None
                l = r['levels'][depth-1]
                status = ('direct_false_negative' if list(c) in l['direct_fn_existing_parent'] else
                          'direct_false_positive' if list(c) in l['direct_fp_correct_parent'] else
                          'inherited_missing_parent' if not present and gt else
                          'absent_parent_gt_empty' if not present else 'correct')
                observations.append({'prediction_id': r['id'], 'steps': r['steps'], 'seed': r['seed'],
                                     'tree_pass': r['tree_pass'], 'parent_present': present,
                                     'estimate': estimate, 'status': status, 'siblings': siblings})
            rr20 = [r for r in observations if r['steps'] == 20]
            candidate_rows.append({'depth': depth, 'cell': list(c), 'parent': list(par), 'bit': bit,
                                   'training_target': gt, 'label_contains_cell': bool(gt),
                                   'direct_error_count_20_steps': sum(v['status'].startswith('direct_') for v in rr20),
                                   'direct_error_count_5_steps': sum(v['status'].startswith('direct_') for v in observations if v['steps'] == 5),
                                   'estimate_min_20_steps': min(v['estimate'] for v in rr20 if v['estimate'] is not None),
                                   'estimate_max_20_steps': max(v['estimate'] for v in rr20 if v['estimate'] is not None),
                                   'observations': observations})
        sigs = []
        for r in r20:
            l = r['levels'][r['first_mismatch_depth']-1] if r['first_mismatch_depth'] else None
            sigs.append(json.dumps({'depth': l['depth'], 'missing': l['missing'], 'extra': l['extra']}, sort_keys=True) if l else 'pass')
        direct_counts = [sum(len(l['direct_fn_existing_parent'])+len(l['direct_fp_correct_parent']) for l in r['levels']) for r in r20]
        summary = {'uid': uid, 'trees_20_steps': 10, 'passes_20_steps': sum(r['tree_pass'] for r in r20),
                   'trees_5_steps': 2, 'passes_5_steps': sum(r['tree_pass'] for r in r5),
                   'first_mismatch_histogram_20_steps': dict(Counter(str(r['first_mismatch_depth']) for r in r20)),
                   'all_20_step_first_error_signatures_identical': len(set(sigs)) == 1,
                   'first_error_signatures_20_steps': [{'signature': json.loads(k) if k != 'pass' else 'pass', 'count': v}
                                                       for k, v in Counter(sigs).items()],
                   'exactly_one_direct_erroneous_bit_in_every_20_step_tree': all(n == 1 for n in direct_counts),
                   'direct_error_counts_20_steps': direct_counts,
                   'candidate_cells': candidate_rows}
        summaries.append(summary)
    result = {'title': 'Round3 Part D: J2 repeated failures',
              'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'scope': 'CPU-only saved-array analysis; no model forwards, training, GPU, or repository changes',
              'code_commit': EXPECTED_COMMIT, 'prediction_count': len(rows),
              'threshold': 0.5, 'bit_order': '4*x_lowbit+2*y_lowbit+z_lowbit',
              'definitions': {
                  'direct_fn_existing_parent': 'GT occupied child predicted empty when its parent is generated',
                  'inherited_fn_absent_parent': 'GT child missing because its parent was absent; no estimate exists',
                  'direct_fp_correct_parent': 'new false positive child under a true GT parent',
                  'propagated_fp_wrong_parent': 'false positive child under an already erroneous generated parent; kept separate from new direct errors',
                  'same_single_cell': 'one identical direct erroneous bit across every tree; a recurring omission plus FP is not a single-cell failure'},
              'training_labels': training, 'summaries': summaries, 'predictions': rows,
              'checks': {'expected_36_predictions': True, 'labels_match_manifest_hash': True,
                         'frozen_training_octree_matches_all_gt_levels': True,
                         'thresholds_saved_cells_own_parent_chain_and_final_vertices_verified': True,
                         'all_per_depth_tp_fp_fn_and_tree_exact_match_evaluation_json': True}}
    assert git('status', '--porcelain') == ''
    write(out/'recurrence.json', result)
    write(out/'input_manifest_recurrence.json', {'inputs': sorted(inventory.values(), key=lambda v: v['path']),
                                              'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
    lines = ['# Round3 Part D: J2 repeated failures', '',
             'CPU-only recomputation: 36 saved predictions, 3 objects × (10 seeds at 20 steps + 2 official seeds at 5 steps).',
             'No training, model forward, GPU use, repository modification, or new generation.', '',
             '| Object | 20-step exact | 5-step exact | First-error depths (20 steps) | Identical first-error set across 10 seeds |',
             '|---|---:|---:|---|---|']
    for s in summaries:
        lines.append(f"| {s['uid']} | {s['passes_20_steps']}/10 | {s['passes_5_steps']}/2 | {s['first_mismatch_histogram_20_steps']} | {s['all_20_step_first_error_signatures_identical']} |")
    lines += ['', 'A recurring missed GT cell does not mean each tree has only one wrong bit. New direct errors and descendants inherited from earlier errors are separated in recurrence.json.', '']
    for s in summaries:
        lines += [f"## {s['uid']}", '', f"New direct erroneous bits per 20-step tree (seeds 97029000–97029009): {s['direct_error_counts_20_steps']}.", '',
                  '| Depth | Cell | Parent / bit | GT | Direct errors, 20 steps | Direct errors, 5 steps | 20-step estimate range |',
                  '|---:|---|---|---:|---:|---:|---|']
        for c in s['candidate_cells']:
            lines.append(f"| {c['depth']} | {tuple(c['cell'])} | {tuple(c['parent'])} / {c['bit']} | {c['training_target']} | {c['direct_error_count_20_steps']}/10 | {c['direct_error_count_5_steps']}/2 | {c['estimate_min_20_steps']:.9g} … {c['estimate_max_20_steps']:.9g} |")
        lines += ['', 'Every candidate includes all 12 per-seed estimates and all 8 sibling GT/estimate values in recurrence.json; absent parents are explicit.', '']
    lines += ['## Verification', '', '- D9 labels match the manifest SHA256 and matching training checkout copies.',
              '- The frozen build_octree_levels function reproduced all nine GT levels on CPU.',
              '- Saved estimates reproduce occupancy at >=0.5; generated parents are exactly the preceding predicted layer.',
              '- Per-layer TP/FP/FN, first mismatch, complete tree and final leaf exactness match evaluation.json.',
              '- Missing occupied cells have training target 1; extra cells have target 0 and are not mislabeled as missing GT.', '']
    (out/'recurrence.md').write_text('\n'.join(lines))
    print(json.dumps({'status': 'RECURRENCE_OK', 'predictions': len(rows), 'summary': [
        {k:v for k,v in s.items() if k != 'candidate_cells'} for s in summaries]}, indent=2))


if __name__ == '__main__':
    main()
