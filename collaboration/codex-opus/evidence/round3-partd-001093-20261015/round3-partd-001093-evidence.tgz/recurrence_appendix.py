"""Add explicit per-seed estimates/siblings for every globally recurring error cell."""
from collections import Counter
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import numpy as np

ROOT = Path('/guohaoran/tmp/nexus_vertex_round3_partd_001093_20261015')
assert os.environ.get('CUDA_VISIBLE_DEVICES') == ''
assert not (ROOT/'recurrence_cells.json').exists()
r = json.loads((ROOT/'recurrence.json').read_text())
offs = np.array([[b >> 2 & 1, b >> 1 & 1, b & 1] for b in range(8)], dtype=np.int64)
arrays, truth = {}, {}
for uid, info in r['training_labels'].items():
    data = Path(info['training_label']).read_bytes()
    assert hashlib.sha256(data).hexdigest() == info['sha256']
    with np.load(io.BytesIO(data), allow_pickle=False) as a:
        q = a['leaves']
    truth[uid] = {d:set(map(tuple, (q >> (9-d)).tolist())) for d in range(1,10)}
for row in r['predictions']:
    data = Path(row['prediction']).read_bytes()
    assert hashlib.sha256(data).hexdigest() == row['sha256']
    with np.load(io.BytesIO(data), allow_pickle=False) as a:
        arrays[row['id']] = {k:a[k].copy() for k in a.files}
results = []
flat, sibflat = [], []
for uid in r['training_labels']:
    rows = [p for p in r['predictions'] if p['uid'] == uid]
    rows20 = [p for p in rows if p['steps'] == 20]
    counters = {}
    for typ in ['missing', 'extra']:
        counters[typ] = Counter((l['depth'], *c) for p in rows20 for l in p['levels'] for c in l[typ])
    for typ, counter in counters.items():
        for (d,*c), n in sorted(counter.items()):
            if n < 2:
                continue
            par = np.array(c)//2
            bit = int((np.array(c)%2) @ np.array([4,2,1]))
            gt = int(tuple(c) in truth[uid][d])
            assert gt == int(typ == 'missing')
            observations = []
            for p in rows:
                a = arrays[p['id']]
                match = np.flatnonzero(np.all(a[f'depth{d}_parents'] == par, axis=1))
                est = a[f'depth{d}_estimate'][0,match[0]] if len(match) else None
                l = p['levels'][d-1]
                status = 'correct'
                for field in ['direct_fn_existing_parent', 'inherited_fn_absent_parent', 'direct_fp_correct_parent', 'propagated_fp_wrong_parent']:
                    if c in l[field]:
                        status = field
                if est is None and status == 'correct':
                    status = 'parent_absent_gt_empty'
                base = {'uid':uid, 'depth':d, 'cell':c, 'parent':par.tolist(), 'bit':bit,
                        'gt':gt, 'steps':p['steps'], 'seed':p['seed'], 'tree_pass':p['tree_pass'],
                        'estimate':float(est[bit]) if est is not None else None, 'status':status,
                        'parent_present':est is not None}
                siblings = [{'bit':b, 'cell':ch.tolist(), 'gt':int(tuple(ch) in truth[uid][d]),
                             'estimate':float(est[b]) if est is not None else None}
                            for b,ch in enumerate(par*2+offs)]
                flat.append(base)
                for s in siblings:
                    sibflat.append({'uid':uid, 'depth':d, 'target_cell':c, 'parent':par.tolist(),
                                    'steps':p['steps'], 'seed':p['seed'], 'parent_present':est is not None, **s})
                observations.append({**base, 'siblings':siblings})
            results.append({'uid':uid, 'depth':d, 'cell':c, 'parent':par.tolist(), 'bit':bit,
                            'gt':gt, 'error_type':typ, 'error_count_20_steps':n,
                            'observations':observations})
for filename, data in [('recurrence_cells.tsv',flat),('recurrence_siblings.tsv',sibflat)]:
    with (ROOT/filename).open('w') as f:
        writer=csv.DictWriter(f, fieldnames=list(data[0]), delimiter='\t')
        writer.writeheader()
        writer.writerows({k:('parent absent' if v is None else json.dumps(v) if isinstance(v,list) else v)
                         for k,v in row.items()} for row in data)
out={'definition':'Every missing/extra cell occurring in at least 2 of the 10 twenty-step trees; includes propagated descendants. Each gets all 12 seed/step observations.',
     'recurrence_source_sha256':hashlib.sha256((ROOT/'recurrence.json').read_bytes()).hexdigest(),
     'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
     'cells':results}
(ROOT/'recurrence_cells.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
lines=['# Recurring cells: per-seed appendix','','Cells recurring in at least 2/10 twenty-step trees. TSV files include all 12 observations and all sibling estimates.','',
       '| UID | Depth | Cell | GT | Twenty-step errors | Type / propagation |','|---|---:|---|---:|---:|---|']
for c in results:
    kinds=Counter(x['status'] for x in c['observations'] if x['steps']==20 and x['status'] != 'correct')
    lines.append(f"| {c['uid']} | {c['depth']} | {tuple(c['cell'])} | {c['gt']} | {c['error_count_20_steps']}/10 | {dict(kinds)} |")
lines += ['', '## Stable new errors (10/10 at 20 steps)', '',
          '| UID / cell | Steps | Seed | Estimate | Tree pass |','|---|---:|---:|---:|---|']
for c in results:
    if c['error_count_20_steps'] != 10 or not any(x['status'].startswith('direct_') for x in c['observations']):
        continue
    for x in c['observations']:
        lines.append(f"| {c['uid']} d{c['depth']} {tuple(c['cell'])} | {x['steps']} | {x['seed']} | {x['estimate']:.10g} | {x['tree_pass']} |")
(ROOT/'recurrence_cells.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({'status':'RECURRENCE_APPENDIX_OK','global_recurring_cells':len(results),'cell_observations':len(flat),'sibling_observations':len(sibflat)}))
