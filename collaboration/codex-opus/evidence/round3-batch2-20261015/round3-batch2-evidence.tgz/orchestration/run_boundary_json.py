"""CPU fallback for the frozen boundary CLI's NoneType formatting exception only."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import time

SOURCE_SHA256 = 'c7516437482fd1de70ad4c5e663bd4b93103a4b289afd23b9ff073204d5b940d'
ERROR = 'TypeError: unsupported format string passed to NoneType.__format__'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def calculate(source, folders):
    assert sha(source) == SOURCE_SHA256, 'Frozen boundary source differs'
    os.environ['CUDA_VISIBLE_DEVICES'] = ''
    spec = importlib.util.spec_from_file_location('frozen_boundary_analysis', source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    labels = module.load_labels()
    return [module.analyze(folder, labels) for folder in folders]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True, type=Path)
    parser.add_argument('--eval-dir', required=True, action='append', type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--original-log', required=True, type=Path)
    args = parser.parse_args()
    started = time.time()
    source = args.source.resolve(strict=True)
    original_log = args.original_log.read_text()
    traced_sources = [Path(name).resolve() for name in re.findall(r'File "([^"]+)", line \d+', original_log)]
    assert ERROR in original_log and source in traced_sources, 'Expected frozen CLI formatting failure is absent'
    assert not args.output.exists(), 'Preserve existing boundary output'
    original_hash = sha(args.original_log)
    reports = calculate(source, args.eval_dir)
    text = json.dumps(reports, indent=2) + '\n'
    with args.output.open('x') as stream:
        stream.write(text)
    assert sha(args.original_log) == original_hash, 'Original failure log changed'
    receipt = {'state': 'complete', 'reason': ERROR, 'change': 'Bypass console formatting only; original load_labels/analyze and JSON serialization retained',
               'command': [sys.executable, *sys.argv], 'source': str(source), 'source_sha256': SOURCE_SHA256,
               'adapter_sha256': sha(Path(__file__)), 'original_log': str(args.original_log), 'original_log_sha256': original_hash,
               'output': str(args.output), 'output_sha256': sha(args.output), 'eval_dirs': [str(path) for path in args.eval_dir],
               'started_unix': started, 'ended_unix': time.time(), 'gpu_calls': 0}
    with args.output.with_suffix('.fallback.receipt.json').open('x') as stream:
        stream.write(json.dumps(receipt, indent=2) + '\n')
    print(text, end='')
    print('BOUNDARY_JSON_FALLBACK_COMPLETE', flush=True)


if __name__ == '__main__':
    main()
