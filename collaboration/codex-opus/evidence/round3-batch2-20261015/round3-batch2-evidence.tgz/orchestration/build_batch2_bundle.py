"""Collect completed Batch2 Part A JSON results and failure evidence; CPU/files only."""
import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile

COMMIT = 'e7e3a326a65bc550be695104ae69e0d3435bd446'
SEEDS = list(range(97029000, 97029010))
STEPS = {2, 3, 4, 5, 6, 8}


def encode(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def sha(content):
    return hashlib.sha256(content).hexdigest()


def summarize(rows):
    depths = []
    for depth in range(1, 10):
        lv = [row["levels"][depth - 1] for row in rows]
        tp = sum(x["global_cells_tp"] for x in lv)
        fp = sum(x["global_cells_fp"] for x in lv)
        fn = sum(x["global_cells_fn"] for x in lv)
        depths.append({"depth": depth, "full_level_exact": sum(x["exact"] for x in lv),
                       "global_cells_tp": tp, "global_cells_fp": fp, "global_cells_fn": fn,
                       "global_cells_f1": 2 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else 1.0})
    first = {}
    for row in rows:
        key = str(row["first_mismatch_depth"])
        first[key] = first.get(key, 0) + 1
    by_size = {}
    for low, high in ((0, 300), (300, 700), (700, 1200), (1200, 10**9)):
        bucket = [r for r in rows if low <= r["target_n"] < high]
        label = f"{low}-{high}" if high < 10**9 else f"{low}+"
        by_size[label] = {"trees": len(bucket), "exact": sum(r["all_levels_exact"] for r in bucket)}
    ratios = [row["d9_gt_xyz"].get("spacing_ratio") for row in rows]
    teacher_rule = sum(1 for row, r in zip(rows, ratios) if row["count_correct"] and r is not None and r < 0.1)
    return {"trees": len(rows), "full_trees_exact": sum(r["all_levels_exact"] for r in rows),
            "native_final_sets_exact": sum(r["native_final_set_exact"] for r in rows),
            "capacity_abort_trees": sum(r["status"] == "capacity_abort" for r in rows),
            "count_accuracy": sum(r["count_correct"] for r in rows) / max(len(rows), 1),
            "teacher_rule_vs_d9_gt_pass": teacher_rule,
            "first_mismatch_depth_histogram": first, "exact_by_vertex_count": by_size, "per_depth": depths}


def split_metrics(rows):
    groups = {'official': [r for r in rows if r['seed'] in SEEDS[:2]],
              'extra': [r for r in rows if r['seed'] in SEEDS[2:]], 'all': rows}
    assert [len(groups[k]) for k in ('official', 'extra', 'all')] == [100, 400, 500]
    return {key: summarize(value) for key, value in groups.items()}


def build(root, source):
    output = root / 'publication/batch2'
    payload = output / 'payload'
    payload.mkdir(parents=True, exist_ok=True)
    assert not any(payload.iterdir()), 'Existing payload retained; do not overwrite publication'
    files, provenance, missing = {}, [], []

    def add(path, name, required=False):
        if not path.exists():
            if required:
                missing.append(str(path))
            return None
        assert path.is_file() and not path.is_symlink(), str(path)
        assert path.suffix in ('.json', '.jsonl', '.log', '.py', '.md'), str(path)
        before = path.stat()
        content = path.read_bytes()
        after = path.stat()
        assert (before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns), f'Changing file: {path}'
        raw = content
        if path.suffix in ('.log', '.jsonl') and len(content) > 1 << 20:
            content, name = gzip.compress(content, mtime=0), name + '.gz'
        assert name not in files and len(content) < 25 << 20, name
        files[name] = content
        provenance.append({'path': name, 'source': str(path), 'source_bytes': len(raw),
                           'source_sha256': sha(raw), 'bytes': len(content), 'sha256': sha(content),
                           'source_mtime_ns': before.st_mtime_ns})
        return raw

    for name in ('WRAPPER_LAUNCH.json', 'WRAPPER_EXIT.json', 'WRAPPER_STATUS.json',
                 'PIPELINE_EXIT.json', 'queue.log', 'pipeline.log', 'CPU_GATE_RESULT.json',
                 'cpu_gate_server.log', 'cpu_gate.log', 'EXACT_BLOB_MANIFEST.json',
                 'boundary_adapter_fixture.json', 'PUBLISHER_FIXTURE.json'):
        add(root / name, 'run/' + name)
    for name in ('checkpoint_identity.json', 'cpu_gate.log', 'CPU_GATE_RESULT.json', 'cpu_gate_result.json'):
        add(root / 'audit' / name, 'audit/' + name, required=name in ('checkpoint_identity.json', 'cpu_gate.log'))
    for name in ('launch_batch2_part_a.py', 'collect_publish_batch2.py', 'build_batch2_bundle.py',
                 'publish_batch2.py', 'run_boundary_json.py', 'test_publish_batch2_offline.py'):
        add(root / name, 'orchestration/' + name)
    work = source / 'vertex/dense_overfit50_20261009'
    for name in ('evaluate.py', 'common.py', 'samplers.py', 'analyze_boundary.py', 'analyze_cascade.py',
                 'tests/test_cpu.py', 'CODEX_PROMPT_ROUND2C.md'):
        add(work / name, 'source/' + name, required=True)
    manifest_bytes = add(work / 'data/prepared_d9/manifest.json', 'source/data_manifest.json', required=True)
    uids = json.loads(manifest_bytes)['train_uids'] if manifest_bytes else []
    assert not uids or len(uids) == len(set(uids)) == 50, 'Source cohort must contain 50 unique UIDs'
    actual = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=source, capture_output=True, text=True)
    code = {'expected_commit': COMMIT, 'actual_commit': actual.stdout.strip() if actual.returncode == 0 else None,
            'git_error': actual.stderr.strip() if actual.returncode else None,
            'source_file_hashes': {r['path']: r['source_sha256'] for r in provenance if r['path'].startswith('source/')}}
    code['commit_verified'] = code['actual_commit'] == COMMIT
    files['CODE_IDENTITY.json'] = encode(code)
    run = root / 'round3_sweep'
    state_bytes = add(run / 'status.json', 'run/status.json', required=True)
    add(run / 'launch_commands.json', 'run/launch_commands.json')
    add(run / 'source_hashes.json', 'run/source_hashes.json')
    add(run / 'selection.json', 'run/selection.json', required=True)
    state = json.loads(state_bytes) if state_bytes else {'status': 'launcher_status_missing', 'jobs': []}
    files['CHECKPOINT_IDENTITY.json'] = files.get('audit/checkpoint_identity.json', encode(state.get('checkpoint_identity', {})))
    records = []
    for job in state.get('jobs', []):
        label = job['id']
        assert Path(label).name == label and label not in ('', '.', '..')
        destination = run / label
        assert Path(job['output']).resolve() == destination.resolve(), 'Job output outside expected queue root'
        add(run / 'logs' / (label + '.log'), 'logs/' + label + '.log')
        for name in ('boundary.log', 'boundary.fallback.log', 'boundary.fallback.receipt.json', 'cascade.log', 'progress.json'):
            add(destination / name, 'evaluations/' + label + '/' + name)
        record = {k: job[k] for k in ('id', 'name', 'status', 'weights', 'steps', 'seeds', 'gpu',
                  'started_utc', 'ended_utc', 'eval_exit_code', 'analysis_exit_codes', 'analysis_original_exit_codes',
                  'boundary_fallback', 'boundary_fallback_exit_code', 'recovered_without_regeneration',
                  'adopted_exit_status_unavailable', 'adopted_pid', 'error') if k in job}
        record['metrics_complete'] = False
        record['analysis_complete_after_fallback'] = False
        try:
            exit_unknown = job.get('eval_exit_code') is None and (
                job.get('recovered_without_regeneration') is True or job.get('adopted_exit_status_unavailable') is True)
            assert job.get('eval_exit_code') == 0 or exit_unknown, 'No successful evaluator exit or documented recovered/adopted process'
            if exit_unknown:
                assert 'EVALUATION_COMPLETE' in (run / 'logs' / (label + '.log')).read_text()[-8192:], 'Completion marker missing for unknown exit status'
            record['evaluator_exit_status'] = 'unknown' if exit_unknown else 0
            assert len(uids) == 50, 'Source cohort missing'
            summary = json.loads((destination / 'summary.json').read_text())
            evaluation = json.loads((destination / 'evaluation.json').read_text())
            rows = evaluation['rows']
            seeds = job['seeds']
            assert seeds == SEEDS and job['steps'] in STEPS and job['weights'] == 'ema'
            assert summary['trees'] == evaluation['trees'] == len(rows) == 500, 'Incomplete denominator'
            assert {(r['uid'], r['seed']) for r in rows} == {(u, s) for u in uids for s in seeds}, 'UID/seed mismatch'
            assert sorted(summary['seeds']) == sorted(evaluation['seeds']) == sorted(seeds)
            assert summary['steps_per_depth'] == evaluation['steps_per_depth'] == job['steps']
            assert summary['weights'] == evaluation['weights'] == 'ema'
            assert summary['sampler'] == evaluation['sampler'] == 'euler'
            exact = sum(bool(r['all_levels_exact']) for r in rows)
            assert summary['full_trees_exact'] == evaluation['full_trees_exact'] == exact
            for name in ('summary.json', 'evaluation.json', 'generation_manifest.json'):
                add(destination / name, 'evaluations/' + label + '/' + name, required=True)
            splits = split_metrics(rows)
            for key, value in splits['all'].items():
                assert summary[key] == evaluation[key] == value, f'Aggregate mismatch: {key}'
            split_bytes = add(destination / 'split_metrics.json', 'evaluations/' + label + '/split_metrics.json', required=True)
            if split_bytes:
                saved_split = json.loads(split_bytes)
                for subset in ('official', 'extra', 'all'):
                    assert saved_split[subset]['trees'] == splits[subset]['trees']
                    assert saved_split[subset]['full_trees_exact'] == splits[subset]['full_trees_exact']
            files['evaluations/' + label + '/split_metrics_recomputed.json'] = encode(splits)
            record.update(metrics_complete=True, trees=500, full_trees_exact=exact, split_metrics=splits,
                          completion_evidence='500 unique UID/seed pairs and consistent summary counts' + (' plus original EVALUATION_COMPLETE log; exit code unavailable' if exit_unknown else ' plus evaluator exit 0'),
                          per_depth_full_level_exact=[r['full_level_exact'] for r in summary['per_depth']],
                          official_subset_seeds=SEEDS[:2], extra_subset_seeds=SEEDS[2:])
            boundary_log = destination / 'boundary.log'
            fallback_log = destination / 'boundary.fallback.log'
            fallback_receipt = destination / 'boundary.fallback.receipt.json'
            known_failure = ('TypeError: unsupported format string passed to NoneType.__format__' in boundary_log.read_text()
                             if boundary_log.is_file() else False)
            original_boundary_exit = job.get('analysis_original_exit_codes', {}).get('boundary', job.get('analysis_exit_codes', {}).get('boundary'))
            if known_failure and original_boundary_exit != 0:
                if not (destination / 'boundary.json').exists() and not fallback_log.exists():
                    command = [sys.executable, str(root / 'run_boundary_json.py'), '--source', str(work / 'analyze_boundary.py'),
                               '--eval-dir', str(destination), '--output', str(destination / 'boundary.json'),
                               '--original-log', str(boundary_log)]
                    with fallback_log.open('x') as stream:
                        repaired = subprocess.run(command, env=os.environ | {'CUDA_VISIBLE_DEVICES': ''}, stdin=subprocess.DEVNULL,
                                                  stdout=stream, stderr=subprocess.STDOUT)
                    record['boundary_fallback_exit_code'] = repaired.returncode
                if fallback_receipt.is_file():
                    receipt = json.loads(fallback_receipt.read_text())
                    record['boundary_fallback'] = {'original_exit_code': original_boundary_exit,
                        'state': receipt['state'], 'output_sha256_valid': receipt['output_sha256'] == sha((destination / 'boundary.json').read_bytes()),
                        'original_log_sha256_valid': receipt['original_log_sha256'] == sha(boundary_log.read_bytes()),
                        'source_sha256_valid': receipt['source_sha256'] == sha((work / 'analyze_boundary.py').read_bytes()),
                        'adapter_sha256_valid': receipt['adapter_sha256'] == sha((root / 'run_boundary_json.py').read_bytes())}
                for path in (fallback_log, fallback_receipt):
                    name = 'evaluations/' + label + '/' + path.name
                    if path.is_file() and name not in files:
                        add(path, name)
            valid_analyses = set()
            for kind in ('boundary', 'cascade'):
                analysis = destination / (kind + '.json')
                if analysis.is_file():
                    try:
                        json.loads(analysis.read_text())
                        add(analysis, 'evaluations/' + label + '/' + kind + '.json')
                        valid_analyses.add(kind)
                    except (ValueError, OSError) as error:
                        record.setdefault('analysis_validation_errors', {})[kind] = str(error)
            fallback = record.get('boundary_fallback', {})
            fallback_valid = fallback.get('state') == 'complete' and all(fallback.get(key) is True for key in (
                'output_sha256_valid', 'original_log_sha256_valid', 'source_sha256_valid', 'adapter_sha256_valid'))
            record['boundary_fallback_success'] = fallback_valid
            exits = job.get('analysis_exit_codes', {})
            record['analysis_complete_after_fallback'] = valid_analyses == {'boundary', 'cascade'} and exits.get('cascade') == 0 and ((original_boundary_exit == 0 and exits.get('boundary') == 0) or fallback_valid)
        except (AssertionError, KeyError, ValueError, OSError) as error:
            record['validation_error'] = str(error)
        records.append(record)
    # Include orphan logs from launcher failures without treating them as evaluated cases.
    for path in sorted((run / 'logs').glob('*.log')):
        if 'logs/' + path.name not in files and 'logs/' + path.name + '.gz' not in files:
            add(path, 'logs/' + path.name)
    status = {'scope': 'Frozen evaluation evidence only; collector does not execute models or load checkpoint tensors',
              'collected_utc': datetime.now(timezone.utc).isoformat(), 'source_commit': code,
              'queue_status': state.get('status'), 'completed_evaluations': sum(r['metrics_complete'] for r in records),
              'scheduled_evaluations': len(records), 'jobs': records, 'missing_evidence': missing,
              'evaluation_complete': len(records) == 6 and {r.get('steps') for r in records} == STEPS and all(r['metrics_complete'] for r in records),
              'analysis_complete_after_fallback': bool(records) and all(r['analysis_complete_after_fallback'] for r in records),
              'checkpoint_hash_boundary': 'No checkpoint was opened or rehashed by this collection. Saved identities are included.',
              'excluded': ['checkpoint tensors', 'prediction arrays', 'predictions folders', 'credentials']}
    if status['evaluation_complete']:
        ranking = sorted(records, key=lambda r: (-r['split_metrics']['extra']['full_trees_exact'], r['steps']))
        status['step_selection_recomputed'] = {'chosen_steps': ranking[0]['steps'],
            'criterion': 'Extra 400 full-tree exact, ties to fewer steps; no training is launched',
            'ranking': [{'steps': r['steps'], 'extra_exact': r['split_metrics']['extra']['full_trees_exact'],
                         'extra_trees': 400} for r in ranking]}
    status['delivery_complete'] = status['evaluation_complete'] and status['analysis_complete_after_fallback'] and code['commit_verified'] and not missing
    status['complete'] = status['delivery_complete']
    rows_text = '\n'.join('| ' + ' | '.join([r['id'], r.get('status', 'unknown'),
                  str(r.get('evaluator_exit_status', r.get('eval_exit_code', 'unknown'))),
                  f"{r['split_metrics']['official']['full_trees_exact']}/100" if r['metrics_complete'] else 'Not validated',
                  f"{r['split_metrics']['extra']['full_trees_exact']}/400" if r['metrics_complete'] else 'Not validated',
                  f"{r['full_trees_exact']}/500" if r['metrics_complete'] else 'Not validated',
                  str(r.get('analysis_exit_codes', {})), str(r.get('boundary_fallback_success', False)),
                  r.get('validation_error', '').replace('|', '/')]) + ' |' for r in records)
    report = ('# Round 3 Batch 2 Part A frozen evaluation\n\n'
              f"- Queue status: `{status['queue_status']}`; complete delivery: `{status['complete']}`.\n"
              f"- GPU evaluation complete: `{status['evaluation_complete']}`; analysis complete after any formatting fallback: `{status['analysis_complete_after_fallback']}`. Original queue status is retained.\n"
              f"- Validated complete evaluations: {status['completed_evaluations']}/{len(records)} scheduled cases. Each complete case has 500 trees: original 100 and extra 400 are reported separately.\n"
              '- Additional seeds estimate fixed-object robustness; they are separate from the official acceptance seed pair.\n'
              '- Frozen evaluator console `/100` and `acceptance.passed` are oriented to the official seed pair; ten-seed results use validated per-tree coverage of 500, split into official 100 and extra 400.\n'
              '- This collection validates saved JSON coverage and counts. No model forward, training, or checkpoint hashing was performed.\n\n'
              '| Case | Original queue state | Evaluator exit | Original 100 | Extra 400 | Total 500 | Original analysis exits | Boundary fallback succeeded | Validation issue |\n|---|---|---|---|---|---|---|---|---|\n' + rows_text + '\n\n'
              '## Evidence\n\n'
              '- The compressed archive contains completed evaluation JSON, available analysis and failure logs, exact commands, CPU gate, source files and code/checkpoint identities. Incomplete evaluations are not reported as completed metrics.\n'
              '- `STATUS.json` records missing evidence and per-case validation errors. A missing launcher status is a failure boundary, not an empty successful batch.\n'
              '- Recovered/adopted process exits remain unknown when unavailable. Their completed metrics require the original EVALUATION_COMPLETE log marker plus exactly 500 UID/seed pairs and consistent summary counts; no exit code is invented.\n'
              '- A boundary CLI NoneType formatting failure can be recovered by a separate CPU adapter calling the unchanged frozen calculation functions. Original failure logs and exit codes remain; adapter output and provenance are separate. Such a formatting failure does not mean GPU generation failed.\n'
              '- Checkpoint identity includes the saved update/step and whether a hash was recomputed; this collector does not strengthen that evidence.\n'
              '- Step selection uses extra-400 full-tree exact only; ties select the lower step count. Part B training is outside this queue.\n')
    files['REPORT.md'], files['STATUS.json'] = report.encode(), encode(status)
    files['FILE_PROVENANCE.json'] = encode(provenance)
    archive_manifest = [{'path': name, 'bytes': len(content), 'sha256': sha(content)} for name, content in sorted(files.items())]
    with tarfile.open(payload / 'round3-batch2-evidence.tgz', 'w:gz', compresslevel=6) as archive:
        for name, content in sorted(files.items()):
            info = tarfile.TarInfo(name)
            info.size, info.mtime, info.mode = len(content), 0, 0o644
            archive.addfile(info, io.BytesIO(content))
    (payload / 'REPORT.md').write_bytes(files['REPORT.md'])
    (payload / 'STATUS.json').write_bytes(files['STATUS.json'])
    (payload / 'FILE_MANIFEST.json').write_bytes(encode(archive_manifest))
    uploads = [{'path': p.name, 'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())} for p in sorted(payload.iterdir())]
    (output / 'UPLOAD_MANIFEST.json').write_bytes(encode(uploads))
    print(json.dumps({'bundle': str(output), 'complete': status['complete'], 'completed_evaluations': status['completed_evaluations'],
                      'scheduled_evaluations': len(records), 'bytes': sum(r['bytes'] for r in uploads)}))
    return status


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--source', type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    build(root, (args.source or root / 'repo').resolve())


if __name__ == '__main__':
    main()
