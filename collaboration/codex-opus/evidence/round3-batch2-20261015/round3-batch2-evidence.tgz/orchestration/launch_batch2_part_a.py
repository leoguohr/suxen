"""Round 3 Batch 2 Part A only: six frozen EMA evaluations, no training."""
from pathlib import Path
import argparse
import concurrent.futures
import datetime
import hashlib
import json
import os
import queue
import subprocess
import sys
import threading
import time

COMMIT = 'e7e3a326a65bc550be695104ae69e0d3435bd446'
SEEDS = list(range(97029000, 97029010))
STEPS = [8, 6, 5, 4, 3, 2]
FORMAT_ERROR = 'TypeError: unsupported format string passed to NoneType.__format__'


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, data):
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(data, indent=2) + '\n')
    tmp.replace(path)


def output(cmd, **kw):
    return subprocess.check_output(cmd, text=True, **kw).strip()


def gpu_free(gpu):
    fields = output(['nvidia-smi', '-i', str(gpu), '--query-gpu=index,uuid,memory.used,memory.total',
                     '--format=csv,noheader,nounits']).split(',')
    processes = output(['nvidia-smi', '--query-compute-apps=gpu_uuid,pid', '--format=csv,noheader,nounits'])
    assert not any(line.split(',')[0].strip() == fields[1].strip() for line in processes.splitlines()), f'GPU {gpu} busy'
    assert int(fields[2]) < 1024, f'GPU {gpu} has unexpected memory use'
    return {'index': gpu, 'uuid': fields[1].strip(), 'memory_used_mib': int(fields[2]), 'memory_total_mib': int(fields[3])}


def validate_split(job, uids, log):
    destination = Path(job['output'])
    summary = json.loads((destination / 'summary.json').read_text())
    evaluation = json.loads((destination / 'evaluation.json').read_text())
    rows = evaluation['rows']
    expected = {(uid, seed) for uid in uids for seed in SEEDS}
    assert len(rows) == 500 and {(r['uid'], r['seed']) for r in rows} == expected, 'must contain all 50 UID x 10 seeds exactly once'
    assert summary['trees'] == evaluation['trees'] == 500
    assert summary['seeds'] == SEEDS and evaluation['seeds'] == SEEDS
    assert summary['steps_per_depth'] == evaluation['steps_per_depth'] == job['steps']
    assert summary['weights'] == evaluation['weights'] == 'ema'
    assert summary['sampler'] == evaluation['sampler'] == 'euler'
    assert 'EVALUATION_COMPLETE' in log.read_text()[-8192:]
    def metrics(group):
        return {'trees': len(group), 'full_trees_exact': sum(bool(r['all_levels_exact']) for r in group),
                'full_tree_accuracy': sum(bool(r['all_levels_exact']) for r in group) / len(group)}
    splits = {'all': metrics(rows), 'official': metrics([r for r in rows if r['seed'] in SEEDS[:2]]),
              'extra': metrics([r for r in rows if r['seed'] in SEEDS[2:]])}
    assert (splits['official']['trees'], splits['extra']['trees']) == (100, 400)
    assert splits['all']['full_trees_exact'] == summary['full_trees_exact'] == evaluation['full_trees_exact']
    return {'steps': job['steps'], 'official_seeds': SEEDS[:2], 'extra_seeds': SEEDS[2:], **splits}


def select(splits):
    assert len(splits) == 6 and {r['steps'] for r in splits} == set(STEPS)
    ranked = sorted(splits, key=lambda r: (-r['extra']['full_trees_exact'], r['steps']))
    return {'criterion': 'extra 400 full_trees_exact only; ties choose smaller steps',
            'selected_steps': ranked[0]['steps'], 'ranking': ranked,
            'training_authorized': False, 'training_started': False}


def run(args):
    work = args.source / 'vertex/dense_overfit50_20261009'
    assert output(['git', 'rev-parse', 'HEAD'], cwd=args.source) == COMMIT
    assert not output(['git', 'status', '--porcelain'], cwd=args.source)
    assert args.cpu_gate.read_text().strip().splitlines()[-1].startswith('ALL CPU TESTS PASSED')
    identity = json.loads(args.checkpoint_identity.read_text())
    checkpoint = Path(identity['path'])
    stat = checkpoint.stat()
    assert stat.st_size == identity['bytes'] and stat.st_mtime_ns == identity['mtime_ns']
    assert identity['sha256'] == '4abd3a09d80bd4ffc6b1557681ef84d2a182b1bf101e429a995e83c959d24f58'
    gpus = [int(x) for x in args.gpus.split(',')]
    assert len(gpus) == len(set(gpus)) == 4
    cards = [gpu_free(g) for g in gpus]
    assert not args.output.exists(), 'output root must be new; do not overwrite or restart'
    args.output.mkdir(parents=True)
    logs = args.output / 'logs'
    logs.mkdir()
    manifest = json.loads((work / 'data/prepared_d9/manifest.json').read_text())
    uids = manifest['train_uids']
    assert len(uids) == len(set(uids)) == 50
    tracked = output(['git', 'ls-files', 'vertex/dense_overfit50_20261009'], cwd=args.source).splitlines()
    source_hashes = {name: sha(args.source / name) for name in tracked}
    write_json(args.output / 'source_hashes.json', {'commit': COMMIT, 'files': source_hashes})
    env = dict(os.environ, CUDA_VISIBLE_DEVICES='', PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION='python',
               OMP_NUM_THREADS='8', MKL_NUM_THREADS='8')
    jobs = []
    for steps in STEPS:
        label = f'steps{steps:02}_ema'
        destination = args.output / label
        command = [args.python, str(work / 'evaluate.py'), '--checkpoint', str(checkpoint), '--weights', 'ema',
                   '--steps', str(steps), '--sampler', 'euler', '--seeds', ','.join(map(str, SEEDS)),
                   '--variant', 'S0', '--output', str(destination)]
        analyses = [[args.python, str(work / f'analyze_{kind}.py'), '--eval-dir', str(destination),
                     '--output', str(destination / f'{kind}.json')] for kind in ('boundary', 'cascade')]
        jobs.append({'id': label, 'name': 'J5', 'seeds': SEEDS, 'weights': 'ema', 'steps': steps, 'output': str(destination), 'status': 'pending',
                     'command': command, 'analysis_commands': analyses})
    state = {'task': 'Round3 Batch2 Part A only', 'commit': COMMIT, 'queue_pid': os.getpid(), 'started_utc': now(),
             'status': 'running', 'checkpoint_identity': identity, 'gpu_precheck': cards, 'jobs': jobs,
             'cpu_gate_sha256': sha(args.cpu_gate), 'gpu_errors': {}, 'seeds': SEEDS, 'train_uids': uids,
             'expected_trees_per_job': 500, 'official_trees': 100, 'extra_trees': 400,
             'training_authorized': False, 'training_started': False}
    write_json(args.output / 'launch_commands.json', {'source': str(args.source), 'commit': COMMIT, 'gpus': gpus,
                                                     'seed_order': SEEDS, 'uid_order': uids, 'jobs': jobs})
    lock = threading.Lock()
    def save():
        write_json(args.output / 'status.json', state)
    save()
    pending = queue.Queue()
    for job in jobs:
        pending.put(job)
    def worker(gpu):
        while True:
            try:
                job = pending.get_nowait()
            except queue.Empty:
                return
            try:
                gpu_free(gpu)
                with lock:
                    job.update(status='evaluating', gpu=gpu, started_utc=now())
                    save()
                logpath = logs / f'{job["id"]}.log'
                started = time.monotonic()
                with logpath.open('x') as log:
                    proc = subprocess.Popen(job['command'], cwd=work, env=dict(env, CUDA_VISIBLE_DEVICES=str(gpu)),
                                            stdout=log, stderr=subprocess.STDOUT)
                    with lock:
                        job['pid'] = proc.pid
                        save()
                    code = proc.wait()
                with lock:
                    job.update(eval_exit_code=code, evaluation_seconds=time.monotonic() - started)
                assert code == 0, f'evaluation failed: {code}'
                split = validate_split(job, uids, logpath)
                destination = Path(job['output'])
                write_json(destination / 'split_metrics.json', split)
                with lock:
                    job.update(status='analyzing', split_metrics=split, analysis_exit_codes={}, analysis_original_exit_codes={})
                    save()
                for kind, command in zip(('boundary', 'cascade'), job['analysis_commands']):
                    original_log = destination / f'{kind}.log'
                    with original_log.open('x') as log:
                        result = subprocess.run(command, cwd=work, env=env, stdout=log, stderr=subprocess.STDOUT)
                    with lock:
                        job['analysis_exit_codes'][kind] = result.returncode
                        job['analysis_original_exit_codes'][kind] = result.returncode
                        save()
                    if kind == 'boundary' and result.returncode and FORMAT_ERROR in original_log.read_text():
                        fallback = [args.python, str(Path(__file__).with_name('run_boundary_json.py')),
                                    '--source', str(work / 'analyze_boundary.py'), '--eval-dir', str(destination),
                                    '--output', str(destination / 'boundary.json'), '--original-log', str(original_log)]
                        with (destination / 'boundary.fallback.log').open('x') as log:
                            recovered = subprocess.run(fallback, cwd=work, env=env, stdout=log, stderr=subprocess.STDOUT)
                        with lock:
                            job['boundary_fallback'] = {'command': fallback, 'exit_code': recovered.returncode,
                                                       'fallback_success': recovered.returncode == 0,
                                                       'receipt': str(destination / 'boundary.fallback.receipt.json')}
                            job['boundary_fallback_exit_code'] = recovered.returncode
                            save()
                    if result.returncode == 0:
                        json.loads((destination / f'{kind}.json').read_text())
                with lock:
                    passed = all(code == 0 or (kind == 'boundary' and job.get('boundary_fallback', {}).get('exit_code') == 0)
                                 for kind, code in job['analysis_exit_codes'].items())
                    job.update(status='complete' if passed else 'evaluation_complete_analysis_failed', ended_utc=now())
                    save()
                print(job['id'], job['status'], split, flush=True)
            except Exception as exc:
                with lock:
                    job.update(status='failed', error=str(exc), ended_utc=now())
                    state['gpu_errors'][str(gpu)] = str(exc)
                    save()
                return
            finally:
                pending.task_done()
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        list(pool.map(worker, gpus))
    if all('split_metrics' in job for job in jobs):
        write_json(args.output / 'selection.json', select([job['split_metrics'] for job in jobs]))
    state['ended_utc'] = now()
    state['status'] = 'complete' if all(job['status'] == 'complete' for job in jobs) else 'incomplete_or_analysis_failed'
    save()
    print('BATCH2_PART_A_FINISHED', state['status'], flush=True)
    return 0 if state['status'] == 'complete' else 1


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source', required=True, type=Path)
    p.add_argument('--python', default=sys.executable)
    p.add_argument('--gpus', default='0,1,2,3')
    p.add_argument('--output', required=True, type=Path)
    p.add_argument('--cpu-gate', required=True, type=Path)
    p.add_argument('--checkpoint-identity', required=True, type=Path)
    return run(p.parse_args())


if __name__ == '__main__':
    raise SystemExit(main())
