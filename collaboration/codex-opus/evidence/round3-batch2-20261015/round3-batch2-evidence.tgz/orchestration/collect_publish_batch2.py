"""Launch Batch2 evaluation once; collect and publish on completion; token only via stdin."""
import argparse
import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/guohaoran/tmp/nexus_vertex_round3_batch2A_eval_20261015')
PYTHON = '/guohaoran/envs/nexus-algo/bin/python'


def write(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--source', type=Path)
    parser.add_argument('--python', default=PYTHON)
    parser.add_argument('--gpus', default='0,1,2,3')
    parser.add_argument('--cpu-gate', type=Path)
    parser.add_argument('--checkpoint-identity', type=Path)
    parser.add_argument('--run', action='store_true', help=argparse.SUPPRESS)
    args = parser.parse_args()
    root = args.root.resolve()
    source = (args.source or root / 'repo').resolve()
    gate = (args.cpu_gate or root / 'audit/cpu_gate.log').resolve()
    identity = (args.checkpoint_identity or root / 'audit/checkpoint_identity.json').resolve()
    assert len(args.gpus.split(',')) == len(set(args.gpus.split(','))) == 4
    token = json.load(sys.stdin)['token']
    assert isinstance(token, str) and len(token) >= 20 and not any(c.isspace() for c in token)
    root.mkdir(parents=True, exist_ok=True)
    if not args.run:
        with (root / '.wrapper_start.lock').open('a') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            assert not (root / 'WRAPPER_LAUNCH.json').exists(), 'Batch2 already launched'
            command = [args.python, '-u', str(Path(__file__).resolve()), '--run', '--root', str(root),
                       '--source', str(source), '--python', args.python, '--gpus', args.gpus,
                       '--cpu-gate', str(gate), '--checkpoint-identity', str(identity)]
            with (root / 'pipeline.log').open('x') as log:
                process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=log,
                                           stderr=subprocess.STDOUT, start_new_session=True)
            process.stdin.write(json.dumps({'token': token}).encode())
            process.stdin.close()
            launch = {'pid': process.pid, 'hostname': os.uname().nodename, 'started_unix': time.time(),
                      'command': command, 'max_per_gpu': 1, 'omp_threads': 8,
                      'scope': 'Part A frozen evaluation only; single completion callback; no training or schedule'}
            write(root / 'WRAPPER_LAUNCH.json', launch)
            print(json.dumps(launch), flush=True)
        return
    with (root / '.wrapper_running.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        env = os.environ | {'PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION': 'python', 'OMP_NUM_THREADS': '8'}
        command = [args.python, '-u', str(root / 'launch_batch2_part_a.py'), '--source', str(source),
                   '--python', args.python, '--gpus', args.gpus, '--cpu-gate', str(gate),
                   '--output', str(root / 'round3_sweep'), '--checkpoint-identity', str(identity)]
        outcome = {'state': 'evaluating', 'command': command, 'started_unix': time.time()}
        write(root / 'WRAPPER_STATUS.json', outcome)
        try:
            with (root / 'queue.log').open('x') as log:
                result = subprocess.run(command, env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
            outcome.update(state='collecting', evaluation_return_code=result.returncode, evaluation_ended_unix=time.time())
            write(root / 'WRAPPER_EXIT.json', outcome)
            write(root / 'WRAPPER_STATUS.json', outcome)
            cpu_env = env | {'CUDA_VISIBLE_DEVICES': ''}
            build = [args.python, '-u', str(root / 'build_batch2_bundle.py'), '--root', str(root), '--source', str(source)]
            with (root / 'collect.log').open('x') as log:
                subprocess.run(build, env=cpu_env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, check=True)
            bundle = root / 'publication/batch2'
            outcome['delivery_complete'] = json.loads((bundle / 'payload/STATUS.json').read_text())['delivery_complete']
            outcome['state'] = 'publishing'
            write(root / 'WRAPPER_STATUS.json', outcome)
            publish = [args.python, '-u', str(root / 'publish_batch2.py'), '--bundle-dir', str(bundle)]
            with (root / 'publish.log').open('x') as log:
                subprocess.run(publish, input=json.dumps({'token': token}).encode(), env=cpu_env,
                               stdout=log, stderr=subprocess.STDOUT, check=True)
            receipt = json.loads((bundle / 'GITHUB_PUBLISH.json').read_text())
            outcome.update(state='published' if outcome['delivery_complete'] else 'partial_or_failure_published',
                           commit=receipt['commit'], message_url=receipt['message_url'], public_readback_verified=True)
        except Exception as error:
            outcome.update(state='failed', error_type=type(error).__name__, error=str(error))
            pending = root / 'publication/batch2/GITHUB_COMMIT_PENDING_READBACK.json'
            if pending.exists():
                outcome.update(state='publication_readback_failed', committed=json.loads(pending.read_text()))
            raise
        finally:
            outcome['ended_unix'] = time.time()
            write(root / 'WRAPPER_STATUS.json', outcome)
            write(root / 'PIPELINE_EXIT.json', outcome)
        print('BATCH2_PIPELINE_FINISHED', outcome['state'], flush=True)


if __name__ == '__main__':
    main()
