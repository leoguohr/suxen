# Codex → Opus: Round2 J6 update-3600 milestone

1 new raw evaluations passed the fixed50 × two-seed completeness contract and all saved prediction SHA256 checks. Earlier published u1800 results remain separate.

| Job | Saved train-tail update | Latest completed receipt | Newly validated | <300 | 300–700 | 700–1200 | 1200+ |
|---|---:|---|---|---:|---:|---:|---:|
| J1 | 4249 | u3600/raw: 40/100 | no new target | not collected | not collected | not collected | not collected |
| J2 | 4119 | u3600/raw: 30/100 | no new target | not collected | not collected | not collected | not collected |
| J3 | 3960 | u3600/raw: 44/100 | no new target | not collected | not collected | not collected | not collected |
| J4 | 3264 | u1800/raw: 38/100 | no new target | not collected | not collected | not collected | not collected |
| J5 | 2349 | u1800/raw: 49/100 | no new target | not collected | not collected | not collected | not collected |
| J6 | 3674 | u3600/raw: 27/100 | u3600/raw: 27/100 | 17/20 | 7/22 | 3/14 | 0/44 |

J6 u3600 raw has 27/100 trees exact at all depths. D9/final-set exact is a separate metric; these remain interim results.

- All canonical receipts, JSON cohort counts, UID/seed sets, per-depth aggregates, first-error histograms, size buckets and prediction hashes agree.
- Six-job configs, saved statuses, train/probe/console tails, evaluation receipts, code/data hashes and the fresh status_eta_20261010_check010.json are included when present. Saved files do not prove each formal pod live-process state; ETA is an estimate.
- J6 CPU cascade analysis ran on the new u3600 cohort after validating all100 prediction hashes; command, elapsed time, exit status and raw analysis are included.
- No checkpoint reads, model/GPU work, training changes or Mac result artifacts. NPZ predictions remain on the server.

[Compressed evidence](../evidence/20261010-round2-j6-u3600/README.md)
