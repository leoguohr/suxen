"""Publish server evidence through memory; running this script publishes a commit."""
import base64
from concurrent.futures import ThreadPoolExecutor
import hashlib
import importlib.util
import io
import json
from pathlib import PurePosixPath
import re
import shlex
import subprocess
import tarfile
import urllib.request

HELPER = '/Users/luthier/Documents/sophomore/output/github_nexus_20261008/tools/publish_github.py'
spec = importlib.util.spec_from_file_location('publisher', HELPER)
p = importlib.util.module_from_spec(spec)
spec.loader.exec_module(p)
API = '/repos/leoguohr/suxen'
BRANCH = 'codex-opus-exchange'
PREFIX = 'collaboration/codex-opus/'
REMOTE = '/guohaoran/tmp/nexus_vertex_dense_round2_20261009/opus_j6u3600_handoff_20261010'
NAME = 'round2-j6-u3600'
MESSAGE = '20261010-010-codex-round2-j6-u3600.md'
EVIDENCE = PREFIX + 'evidence/20261010-round2-j6-u3600/'
SSH = ['ssh', '-S', '/tmp/nexus_status_31548_20261010.sock', '-o', 'BatchMode=yes',
       '-p', '31548', 'root@172.16.78.10']


def remote(code, data=None):
    return subprocess.run(SSH + ['python3 -c ' + shlex.quote(code)], input=data, capture_output=True, check=True).stdout


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    token = p.token()
    names = [NAME + '.tgz', 'PACKAGE.json', 'README.md', MESSAGE]
    raw = remote('from pathlib import Path;import json,base64;root=Path(' + repr(REMOTE) + ');'
                 'print(json.dumps({n:base64.b64encode((root/n).read_bytes()).decode() for n in ' + repr(names) + '}))')
    files = {name: base64.b64decode(value) for name, value in json.loads(raw).items()}
    package = json.loads(files['PACKAGE.json'])
    assert len(files[names[0]]) == package['bytes'] and sha(files[names[0]]) == package['sha256']
    inner = {}
    with tarfile.open(fileobj=io.BytesIO(files[names[0]]), mode='r:gz') as archive:
        for member in archive.getmembers():
            path = PurePosixPath(member.name)
            assert member.isfile() and not path.is_absolute() and '..' not in path.parts
            assert path.parts[0] == NAME and path.suffix not in {'.pt', '.npz'} and 'predictions' not in path.parts
            assert str(path) not in inner, 'Duplicate archive member'
            inner[str(path)] = archive.extractfile(member).read()
    assert len(inner) == package['files']
    listed = set()
    for line in inner[NAME + '/SHA256SUMS'].decode().splitlines():
        digest, name = line.split('  ', 1)
        assert sha(inner[NAME + '/' + name]) == digest
        listed.add(NAME + '/' + name)
    assert listed == set(inner) - {NAME + '/SHA256SUMS'}
    forbidden = re.compile(rb'gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|Authorization:\s*(?:Bearer|Basic)\s+[A-Za-z0-9+/=]{16,}')
    for name, content in list(inner.items()) + [(name, files[name]) for name in names[1:]]:
        assert token.encode() not in content and not forbidden.search(content), 'Secret pattern in ' + name
    head = p.api(API + '/git/ref/heads/' + BRANCH, token)['object']['sha']
    payload = {EVIDENCE + name: files[name] for name in names[:3]}
    payload[PREFIX + 'messages/' + MESSAGE] = files[MESSAGE]
    existing = p.api(API + '/contents/' + PREFIX + 'README.md?ref=' + head, token)
    readme = base64.b64decode(existing['content']).decode()
    if 'messages/' + MESSAGE not in readme:
        readme += '\n- [Codex: Round2 J6 u3600 milestone](messages/' + MESSAGE + ')\n'
        readme += '- [Compressed milestone evidence](evidence/20261010-round2-j6-u3600/README.md)\n'
    payload[PREFIX + 'README.md'] = readme.encode()

    def blob(item):
        path, content = item
        data = p.api(API + '/git/blobs', token, {'encoding': 'base64', 'content': base64.b64encode(content).decode()})
        return {'path': path, 'mode': '100644', 'type': 'blob', 'sha': data['sha']}

    with ThreadPoolExecutor(max_workers=2) as pool:
        entries = list(pool.map(blob, payload.items()))
    parent = p.api(API + '/git/commits/' + head, token)
    tree = p.api(API + '/git/trees', token, {'base_tree': parent['tree']['sha'], 'tree': entries})
    commit = p.api(API + '/git/commits', token, {
        'message': 'Report validated J6 u3600 evaluation and CPU cascade',
        'tree': tree['sha'], 'parents': [head]})
    p.api(API + '/git/refs/heads/' + BRANCH, token, {'sha': commit['sha'], 'force': False}, method='PATCH')
    assert p.api(API + '/git/ref/heads/' + BRANCH, token)['object']['sha'] == commit['sha']
    for path, content in payload.items():
        url = f"https://raw.githubusercontent.com/leoguohr/suxen/{commit['sha']}/{path}"
        with urllib.request.urlopen(url, timeout=60) as response:
            assert sha(response.read()) == sha(content), path
    receipt = {'commit': commit['sha'], 'parent': head, 'branch': BRANCH, 'package': package,
               'public_readback_verified': True, 'transit': 'memory only; no local result artifact files',
               'message_url': 'https://github.com/leoguohr/suxen/blob/' + BRANCH + '/' + PREFIX + 'messages/' + MESSAGE}
    remote('from pathlib import Path;import sys;Path(' + repr(REMOTE + '/GITHUB_PUBLISH.json') + ').write_bytes(sys.stdin.buffer.read())', json.dumps(receipt, indent=2).encode())
    print('PUBLISH_VERIFIED', json.dumps(receipt), flush=True)


if __name__ == '__main__':
    main()
